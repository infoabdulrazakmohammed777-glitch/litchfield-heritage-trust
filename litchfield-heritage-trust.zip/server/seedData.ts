import { DatabaseSchema, TransactionRecord, Beneficiary, NotificationItem, AuditLogEntry } from '../src/types';

// Generate ~100 realistic demonstration transactions spanning Jan 2020 through Nov 2026
function generateTransactions(): TransactionRecord[] {
  const transactions: TransactionRecord[] = [];

  // Fictional 5-6 key withdrawals
  const designatedWithdrawals: TransactionRecord[] = [
    {
      id: 'tx-w1',
      date: '2026-09-18',
      reference: 'LHT-WD-2026-0914',
      description: 'Philanthropic Educational Endowment Discretionary Grant',
      type: 'withdrawal',
      amount: 150000.00,
      currency: 'USD',
      status: 'Completed',
      category: 'Philanthropy & Grants',
      counterparty: 'Litchfield Academic Heritage Foundation',
      notes: 'Demonstration fiduciary educational endowment allocation'
    },
    {
      id: 'tx-w2',
      date: '2025-11-04',
      reference: 'LHT-WD-2025-8812',
      description: 'Professional Fiduciary Legal Advisory & Trust Retainer',
      type: 'withdrawal',
      amount: 145000.00,
      currency: 'USD',
      status: 'Completed',
      category: 'Legal & Advisory',
      counterparty: 'Cromwell, Sterling & Vance LLP',
      notes: 'Demonstration legal counsel and fiduciary documentation services'
    },
    {
      id: 'tx-w3',
      date: '2024-07-22',
      reference: 'LHT-WD-2024-5102',
      description: 'Architectural Preservation & Heritage Estate Advisory',
      type: 'withdrawal',
      amount: 82500.00,
      currency: 'USD',
      status: 'Completed',
      category: 'Estate Architecture',
      counterparty: 'Palladian Heritage Conservation Partners',
      notes: 'Demonstration architectural survey and conservation retainers'
    },
    {
      id: 'tx-w4',
      date: '2023-10-15',
      reference: 'LHT-WD-2023-3941',
      description: 'Annual Independent Institutional Compliance & Audit Review',
      type: 'withdrawal',
      amount: 64200.00,
      currency: 'USD',
      status: 'Completed',
      category: 'Compliance & Audit',
      counterparty: 'Kensington Fiduciary Audit Syndicate',
      notes: 'Demonstration institutional oversight fee'
    },
    {
      id: 'tx-w5',
      date: '2022-04-19',
      reference: 'LHT-WD-2022-2180',
      description: 'Fiduciary Trust Administration Honorarium & Custodial Retainer',
      type: 'withdrawal',
      amount: 95000.00,
      currency: 'USD',
      status: 'Completed',
      category: 'Administrative Honorarium',
      counterparty: 'Sterling Global Trust Consortium',
      notes: 'Demonstration statutory administrative retainer'
    },
    {
      id: 'tx-w6',
      date: '2021-08-11',
      reference: 'LHT-WD-2021-1405',
      description: 'International Custodial Vault Security & Archival Fees',
      type: 'withdrawal',
      amount: 38750.00,
      currency: 'USD',
      status: 'Completed',
      category: 'Vault & Custody',
      counterparty: 'Zurich Depository Fiduciary Services AG',
      notes: 'Demonstration secure archival facility maintenance'
    }
  ];

  transactions.push(...designatedWithdrawals);

  // Generate 94 additional consistent transactions (deposits, transfers in/out, payments, adjustments)
  // spanning 2020 through Nov 2026, none exceeding $300,000
  const descriptions = [
    { desc: 'Sovereign Treasury Liquidity Distribution', cat: 'Treasury Yield', type: 'deposit' as const, base: 185000 },
    { desc: 'Global Multi-Asset Dividend Settlement', cat: 'Dividends', type: 'deposit' as const, base: 142000 },
    { desc: 'Discretionary Capital Allocation Settlement', cat: 'Capital Inflow', type: 'deposit' as const, base: 260000 },
    { desc: 'Fixed Income Coupon Distribution - Serie A', cat: 'Fixed Income', type: 'deposit' as const, base: 112500 },
    { desc: 'Private Equity Co-Investment Yield', cat: 'Private Placement', type: 'deposit' as const, base: 245000 },
    { desc: 'Heritage Commercial Real Estate Rental Inflow', cat: 'Real Estate Income', type: 'deposit' as const, base: 89000 },
    { desc: 'Corporate Bond Tranche Settlement Q1', cat: 'Bonds', type: 'deposit' as const, base: 175000 },
    { desc: 'Structured Term Note Maturity Yield', cat: 'Structured Note', type: 'deposit' as const, base: 220000 },
    { desc: 'Institutional Sweep Facility Adjustment', cat: 'Sweep Account', type: 'adjustment' as const, base: 55000 },
    { desc: 'Inter-Vault Internal Reserve Transfer', cat: 'Internal Transfer', type: 'transfer_in' as const, base: 130000 },
    { desc: 'Secondary Portfolio Cash Rebalancing Credit', cat: 'Portfolio Management', type: 'transfer_in' as const, base: 195000 },
    { desc: 'High-Yield Municipal Fiduciary Distribution', cat: 'Municipal Fund', type: 'deposit' as const, base: 78000 },
    { desc: 'Precious Metals Custodial Lending Fee Credit', cat: 'Custodial Income', type: 'deposit' as const, base: 45000 },
    { desc: 'Fiduciary Settlement Adjustment Credit', cat: 'Ledger Balancing', type: 'adjustment' as const, base: 62000 },
    { desc: 'London Clearing House Cleared Settlement', cat: 'Clearing Settlement', type: 'deposit' as const, base: 280000 },
    { desc: 'Zurich Fiduciary Inter-Account Settlement', cat: 'Inter-Account', type: 'transfer_in' as const, base: 168000 },
    { desc: 'Discretionary Liquidity Top-Up Allocation', cat: 'Liquidity Reserve', type: 'deposit' as const, base: 210000 },
    { desc: 'Institutional Securities Lending Revenue', cat: 'Securities Revenue', type: 'deposit' as const, base: 53400 },
    { desc: 'Quarterly Trust Yield Disbursement Settlement', cat: 'Trust Yield', type: 'deposit' as const, base: 198000 },
    { desc: 'Government Sovereign Bond Maturity Credit', cat: 'Sovereign Debt', type: 'deposit' as const, base: 275000 }
  ];

  // Dates spread from Jan 2020 to Nov 2026
  const startTimestamp = new Date('2020-01-15').getTime();
  const endTimestamp = new Date('2026-10-28').getTime();
  const timeStep = (endTimestamp - startTimestamp) / 95;

  for (let i = 0; i < 94; i++) {
    const itemDate = new Date(startTimestamp + i * timeStep);
    const dateStr = itemDate.toISOString().split('T')[0];
    const template = descriptions[i % descriptions.length];
    
    // Slight deterministic variance in amount (keeping under $300,000)
    const variance = ((i * 37) % 50000) - 25000;
    let finalAmount = Math.max(15000, Math.min(295000, template.base + variance));
    finalAmount = Math.round(finalAmount * 100) / 100;

    const refNumber = `LHT-TXN-${itemDate.getFullYear()}-${String(1000 + i * 29).padStart(5, '0')}`;

    transactions.push({
      id: `tx-gen-${i + 1}`,
      date: dateStr,
      reference: refNumber,
      description: template.desc,
      type: template.type,
      amount: finalAmount,
      currency: 'USD',
      status: 'Completed',
      category: template.cat,
      counterparty: 'Litchfield Institutional Clearing Depository',
      notes: `Demonstration transaction record for internal ledger demonstration #${i + 1}`
    });
  }

  // Sort descending by date (most recent first)
  transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return transactions;
}

export const initialDatabaseData: DatabaseSchema = {
  profile: {
    accountHolderName: 'Aurelian House Heritage Trust & Private Advisory',
    accountNumber: 'LHT-9048-2819-0192',
    accountType: 'Private Reserve & Discretionary Wealth Trust',
    accountDescription: 'Institutional demonstration multi-currency wealth management repository with active discretionary liquidity facility.',
    currency: 'USD',
    status: 'Active / Verified Demonstration',
    routingNumber: 'LHT-US-021000089',
    swiftBic: 'LHTRUS33XXX',
    establishedNotice: 'Demonstration repository established for institutional architecture and evaluation',
    presentationTheme: 'heritage-gold'
  },
  balances: {
    currentBalance: 14850240.00,
    availableDiscretionaryLiquidity: 6200000.00,
    currency: 'USD',
    lastUpdated: new Date().toISOString(),
    updatedBy: 'Litchfield Institutional Fiduciary Administrator'
  },
  transactions: generateTransactions(),
  auditLogs: [
    {
      id: 'audit-001',
      action: 'INITIALIZE_INSTITUTIONAL_LEDGER',
      administrator: 'Master Fiduciary Officer (777000)',
      timestamp: '2026-11-01T09:00:00Z',
      previousValue: 'Uninitialized',
      newValue: 'Ledger Established with Current Balance: $14,850,240.00, Liquidity: $6,200,000.00',
      reason: 'Platform initialization and technical demonstration benchmark calibration',
      category: 'system'
    },
    {
      id: 'audit-002',
      action: 'UPDATE_DISCRETIONARY_LIQUIDITY',
      administrator: 'Master Fiduciary Officer (777000)',
      timestamp: '2026-11-02T14:30:00Z',
      previousValue: '$5,800,000.00',
      newValue: '$6,200,000.00',
      reason: 'Discretionary liquidity facility periodic adjustment demonstration',
      category: 'balance'
    }
  ],
  beneficiaries: [
    {
      id: 'ben-01',
      fullName: 'Aurelian International Fiduciary Ltd',
      bankName: 'First Abu Dhabi Bank (FAB)',
      bankAddress: 'FAB Building, Khalifa Business Park, Abu Dhabi, UAE',
      accountNumberOrIban: 'AE070331234567890123456',
      swiftBic: 'FABAAEADXXX',
      country: 'United Arab Emirates',
      currency: 'AED',
      notes: 'Designated corporate fiduciary beneficiary in the UAE',
      createdAt: '2024-03-12'
    },
    {
      id: 'ben-02',
      fullName: 'Geneva Private Wealth Depository S.A.',
      bankName: 'UBS Switzerland AG',
      bankAddress: 'Bahnhofstrasse 45, 8001 Zurich, Switzerland',
      accountNumberOrIban: 'CH9300240240123456789',
      swiftBic: 'UBSWCHZHXXX',
      country: 'Switzerland',
      currency: 'USD',
      notes: 'European custodial repository account',
      createdAt: '2023-08-20'
    },
    {
      id: 'ben-03',
      fullName: 'Coutts Fiduciary Estate Trustees',
      bankName: 'Coutts & Company',
      bankAddress: '440 Strand, London WC2R 0QS, United Kingdom',
      accountNumberOrIban: 'GB29COUT18000212345678',
      swiftBic: 'COUTGB22XXX',
      country: 'United Kingdom',
      currency: 'GBP',
      notes: 'Heritage estate advisory council',
      createdAt: '2022-11-05'
    },
    {
      id: 'ben-04',
      fullName: 'Riyadh Sovereign Advisory Partners',
      bankName: 'The Saudi National Bank (SNB)',
      bankAddress: 'King Fahd Road, Riyadh 11564, Kingdom of Saudi Arabia',
      accountNumberOrIban: 'SA0310000001234567890123',
      swiftBic: 'NCBKSARXXXX',
      country: 'Saudi Arabia',
      currency: 'SAR',
      notes: 'Strategic Middle Eastern consultative reserve',
      createdAt: '2025-01-14'
    }
  ],
  notifications: [
    {
      id: 'notif-01',
      title: 'Institutional Platform Verification Complete',
      message: 'All demonstration balances and transaction ledgers are synchronized across central institutional storage. Remember that all figures are simulated.',
      date: '2026-11-02T10:00:00Z',
      isRead: false,
      priority: 'institutional',
      sender: 'Administrator Directorate'
    },
    {
      id: 'notif-02',
      title: 'Discretionary Liquidity Schedule Notice',
      message: 'Available Discretionary Liquidity has been recalibrated to $6,200,000.00 USD under administrative fiduciary review.',
      date: '2026-11-01T15:20:00Z',
      isRead: false,
      priority: 'advisory',
      sender: 'Treasury & Risk Desk'
    },
    {
      id: 'notif-03',
      title: 'Demonstration Transfer Protocol Notice',
      message: 'For security and compliance reasons, all outbound domestic and international wire transfer requests in this environment will simulate review and terminate with simulated status.',
      date: '2026-10-30T08:45:00Z',
      isRead: true,
      priority: 'routine',
      sender: 'Compliance Directorate'
    }
  ]
};
