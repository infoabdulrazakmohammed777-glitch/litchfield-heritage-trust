import fs from 'fs';
import path from 'path';
import { DatabaseSchema, AccountBalances, AccountProfile, TransactionRecord, Beneficiary, NotificationItem, AuditLogEntry } from '../src/types';
import { initialDatabaseData } from './seedData';

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DB_DIR, 'database.json');

// In-memory active cache synced to disk
let currentDb: DatabaseSchema = JSON.parse(JSON.stringify(initialDatabaseData));

export function initDatabase(): void {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(fileContent);
      // Validate that crucial sections exist
      if (parsed.profile && parsed.balances && Array.isArray(parsed.transactions)) {
        currentDb = parsed;
        console.log(`[Database] Loaded persistent data with ${currentDb.transactions.length} transactions.`);
        return;
      }
    }

    // Otherwise write initial seed
    saveDatabaseSync();
    console.log(`[Database] Initialized new database with seed data.`);
  } catch (err) {
    console.error('[Database] Failed to load database file, using in-memory seed:', err);
  }
}

function saveDatabaseSync(): void {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(currentDb, null, 2), 'utf-8');
  } catch (err) {
    console.error('[Database] Failed to write database to disk:', err);
  }
}

export const dbService = {
  getSnapshot(): DatabaseSchema {
    return JSON.parse(JSON.stringify(currentDb));
  },

  getProfile(): AccountProfile {
    return { ...currentDb.profile };
  },

  updateProfile(profileUpdate: Partial<AccountProfile>, adminName: string): AccountProfile {
    const prev = JSON.stringify(currentDb.profile);
    currentDb.profile = { ...currentDb.profile, ...profileUpdate };
    
    // Log audit
    this.addAuditLog({
      action: 'UPDATE_ACCOUNT_PROFILE',
      administrator: adminName || 'Master Administrator (777000)',
      previousValue: prev,
      newValue: JSON.stringify(currentDb.profile),
      reason: 'Administrative profile update across synchronized dashboards',
      category: 'profile'
    });

    saveDatabaseSync();
    return { ...currentDb.profile };
  },

  getBalances(): AccountBalances {
    return { ...currentDb.balances };
  },

  updateBalances(
    newCurrent: number,
    newLiquidity: number,
    justification: string,
    adminName: string
  ): AccountBalances {
    const prevStr = `Current: $${currentDb.balances.currentBalance.toLocaleString()}, Liquidity: $${currentDb.balances.availableDiscretionaryLiquidity.toLocaleString()}`;
    const newStr = `Current: $${newCurrent.toLocaleString()}, Liquidity: $${newLiquidity.toLocaleString()}`;

    currentDb.balances = {
      ...currentDb.balances,
      currentBalance: Number(newCurrent),
      availableDiscretionaryLiquidity: Number(newLiquidity),
      lastUpdated: new Date().toISOString(),
      updatedBy: adminName || 'Master Administrator (777000)'
    };

    this.addAuditLog({
      action: 'CALIBRATE_DEMONSTRATION_BALANCES',
      administrator: adminName || 'Master Administrator (777000)',
      previousValue: prevStr,
      newValue: newStr,
      reason: justification || 'Mandatory administrative ledger demonstration recalibration',
      category: 'balance'
    });

    saveDatabaseSync();
    return { ...currentDb.balances };
  },

  getTransactions(params?: {
    search?: string;
    type?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
  }): { items: TransactionRecord[]; total: number } {
    let list = [...currentDb.transactions];

    if (params?.search) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(
        t =>
          t.description.toLowerCase().includes(q) ||
          t.reference.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          (t.counterparty && t.counterparty.toLowerCase().includes(q))
      );
    }

    if (params?.type && params.type !== 'all') {
      list = list.filter(t => t.type === params.type);
    }

    if (params?.status && params.status !== 'all') {
      list = list.filter(t => t.status === params.status);
    }

    if (params?.startDate) {
      list = list.filter(t => t.date >= params.startDate!);
    }

    if (params?.endDate) {
      list = list.filter(t => t.date <= params.endDate!);
    }

    const total = list.length;
    const offset = params?.offset || 0;
    const limit = params?.limit || 20;

    const items = list.slice(offset, offset + limit);
    return { items, total };
  },

  getAllTransactions(): TransactionRecord[] {
    return [...currentDb.transactions];
  },

  createTransaction(tx: Omit<TransactionRecord, 'id'>, adminName: string): TransactionRecord {
    const newTx: TransactionRecord = {
      ...tx,
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`
    };

    currentDb.transactions.unshift(newTx);

    this.addAuditLog({
      action: 'CREATE_DEMONSTRATION_TRANSACTION',
      administrator: adminName || 'Master Administrator (777000)',
      previousValue: 'None',
      newValue: `${newTx.reference}: ${newTx.description} ($${newTx.amount.toLocaleString()} ${newTx.currency})`,
      reason: 'Administrative demonstration transaction insertion',
      category: 'transaction'
    });

    saveDatabaseSync();
    return newTx;
  },

  updateTransaction(id: string, update: Partial<TransactionRecord>, adminName: string): TransactionRecord | null {
    const index = currentDb.transactions.findIndex(t => t.id === id);
    if (index === -1) return null;

    const prev = JSON.stringify(currentDb.transactions[index]);
    currentDb.transactions[index] = { ...currentDb.transactions[index], ...update };
    const next = JSON.stringify(currentDb.transactions[index]);

    this.addAuditLog({
      action: 'UPDATE_DEMONSTRATION_TRANSACTION',
      administrator: adminName || 'Master Administrator (777000)',
      previousValue: prev,
      newValue: next,
      reason: 'Administrative demonstration transaction record amendment',
      category: 'transaction'
    });

    saveDatabaseSync();
    return currentDb.transactions[index];
  },

  deleteTransaction(id: string, adminName: string): boolean {
    const index = currentDb.transactions.findIndex(t => t.id === id);
    if (index === -1) return false;

    const removed = currentDb.transactions[index];
    currentDb.transactions.splice(index, 1);

    this.addAuditLog({
      action: 'DELETE_DEMONSTRATION_TRANSACTION',
      administrator: adminName || 'Master Administrator (777000)',
      previousValue: `${removed.reference}: ${removed.description} ($${removed.amount})`,
      newValue: 'DELETED',
      reason: 'Administrative demonstration transaction removal',
      category: 'transaction'
    });

    saveDatabaseSync();
    return true;
  },

  getAuditLogs(): AuditLogEntry[] {
    return [...currentDb.auditLogs];
  },

  addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): AuditLogEntry {
    const logItem: AuditLogEntry = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      ...entry
    };
    currentDb.auditLogs.unshift(logItem);
    return logItem;
  },

  getBeneficiaries(): Beneficiary[] {
    return [...currentDb.beneficiaries];
  },

  addBeneficiary(ben: Omit<Beneficiary, 'id' | 'createdAt'>): Beneficiary {
    const newBen: Beneficiary = {
      ...ben,
      id: `ben-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    currentDb.beneficiaries.unshift(newBen);
    saveDatabaseSync();
    return newBen;
  },

  updateBeneficiary(id: string, update: Partial<Beneficiary>): Beneficiary | null {
    const index = currentDb.beneficiaries.findIndex(b => b.id === id);
    if (index === -1) return null;
    currentDb.beneficiaries[index] = { ...currentDb.beneficiaries[index], ...update };
    saveDatabaseSync();
    return currentDb.beneficiaries[index];
  },

  deleteBeneficiary(id: string): boolean {
    const index = currentDb.beneficiaries.findIndex(b => b.id === id);
    if (index === -1) return false;
    currentDb.beneficiaries.splice(index, 1);
    saveDatabaseSync();
    return true;
  },

  getNotifications(): NotificationItem[] {
    return [...currentDb.notifications];
  },

  addNotification(notif: Omit<NotificationItem, 'id' | 'date' | 'isRead'>, adminName: string): NotificationItem {
    const item: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}`,
      date: new Date().toISOString(),
      isRead: false
    };
    currentDb.notifications.unshift(item);

    this.addAuditLog({
      action: 'BROADCAST_INSTITUTIONAL_ANNOUNCEMENT',
      administrator: adminName || 'Master Administrator (777000)',
      previousValue: 'None',
      newValue: item.title,
      reason: 'Broadcast announcement to visitor dashboard',
      category: 'announcement'
    });

    saveDatabaseSync();
    return item;
  },

  markNotificationRead(id: string): boolean {
    const index = currentDb.notifications.findIndex(n => n.id === id);
    if (index === -1) return false;
    currentDb.notifications[index].isRead = true;
    saveDatabaseSync();
    return true;
  }
};
