// server.ts
import express from "express";
import path2 from "path";
import { fileURLToPath } from "url";

// server/db.ts
import fs from "fs";
import path from "path";

// server/seedData.ts
function generateTransactions() {
  const transactions = [];
  const designatedWithdrawals = [
    {
      id: "tx-w1",
      date: "2026-09-18",
      reference: "LHT-WD-2026-0914",
      description: "Philanthropic Educational Endowment Discretionary Grant",
      type: "withdrawal",
      amount: 15e4,
      currency: "USD",
      status: "Completed",
      category: "Philanthropy & Grants",
      counterparty: "Litchfield Academic Heritage Foundation",
      notes: "Demonstration fiduciary educational endowment allocation"
    },
    {
      id: "tx-w2",
      date: "2025-11-04",
      reference: "LHT-WD-2025-8812",
      description: "Professional Fiduciary Legal Advisory & Trust Retainer",
      type: "withdrawal",
      amount: 145e3,
      currency: "USD",
      status: "Completed",
      category: "Legal & Advisory",
      counterparty: "Cromwell, Sterling & Vance LLP",
      notes: "Demonstration legal counsel and fiduciary documentation services"
    },
    {
      id: "tx-w3",
      date: "2024-07-22",
      reference: "LHT-WD-2024-5102",
      description: "Architectural Preservation & Heritage Estate Advisory",
      type: "withdrawal",
      amount: 82500,
      currency: "USD",
      status: "Completed",
      category: "Estate Architecture",
      counterparty: "Palladian Heritage Conservation Partners",
      notes: "Demonstration architectural survey and conservation retainers"
    },
    {
      id: "tx-w4",
      date: "2023-10-15",
      reference: "LHT-WD-2023-3941",
      description: "Annual Independent Institutional Compliance & Audit Review",
      type: "withdrawal",
      amount: 64200,
      currency: "USD",
      status: "Completed",
      category: "Compliance & Audit",
      counterparty: "Kensington Fiduciary Audit Syndicate",
      notes: "Demonstration institutional oversight fee"
    },
    {
      id: "tx-w5",
      date: "2022-04-19",
      reference: "LHT-WD-2022-2180",
      description: "Fiduciary Trust Administration Honorarium & Custodial Retainer",
      type: "withdrawal",
      amount: 95e3,
      currency: "USD",
      status: "Completed",
      category: "Administrative Honorarium",
      counterparty: "Sterling Global Trust Consortium",
      notes: "Demonstration statutory administrative retainer"
    },
    {
      id: "tx-w6",
      date: "2021-08-11",
      reference: "LHT-WD-2021-1405",
      description: "International Custodial Vault Security & Archival Fees",
      type: "withdrawal",
      amount: 38750,
      currency: "USD",
      status: "Completed",
      category: "Vault & Custody",
      counterparty: "Zurich Depository Fiduciary Services AG",
      notes: "Demonstration secure archival facility maintenance"
    }
  ];
  transactions.push(...designatedWithdrawals);
  const descriptions = [
    { desc: "Sovereign Treasury Liquidity Distribution", cat: "Treasury Yield", type: "deposit", base: 185e3 },
    { desc: "Global Multi-Asset Dividend Settlement", cat: "Dividends", type: "deposit", base: 142e3 },
    { desc: "Discretionary Capital Allocation Settlement", cat: "Capital Inflow", type: "deposit", base: 26e4 },
    { desc: "Fixed Income Coupon Distribution - Serie A", cat: "Fixed Income", type: "deposit", base: 112500 },
    { desc: "Private Equity Co-Investment Yield", cat: "Private Placement", type: "deposit", base: 245e3 },
    { desc: "Heritage Commercial Real Estate Rental Inflow", cat: "Real Estate Income", type: "deposit", base: 89e3 },
    { desc: "Corporate Bond Tranche Settlement Q1", cat: "Bonds", type: "deposit", base: 175e3 },
    { desc: "Structured Term Note Maturity Yield", cat: "Structured Note", type: "deposit", base: 22e4 },
    { desc: "Institutional Sweep Facility Adjustment", cat: "Sweep Account", type: "adjustment", base: 55e3 },
    { desc: "Inter-Vault Internal Reserve Transfer", cat: "Internal Transfer", type: "transfer_in", base: 13e4 },
    { desc: "Secondary Portfolio Cash Rebalancing Credit", cat: "Portfolio Management", type: "transfer_in", base: 195e3 },
    { desc: "High-Yield Municipal Fiduciary Distribution", cat: "Municipal Fund", type: "deposit", base: 78e3 },
    { desc: "Precious Metals Custodial Lending Fee Credit", cat: "Custodial Income", type: "deposit", base: 45e3 },
    { desc: "Fiduciary Settlement Adjustment Credit", cat: "Ledger Balancing", type: "adjustment", base: 62e3 },
    { desc: "London Clearing House Cleared Settlement", cat: "Clearing Settlement", type: "deposit", base: 28e4 },
    { desc: "Zurich Fiduciary Inter-Account Settlement", cat: "Inter-Account", type: "transfer_in", base: 168e3 },
    { desc: "Discretionary Liquidity Top-Up Allocation", cat: "Liquidity Reserve", type: "deposit", base: 21e4 },
    { desc: "Institutional Securities Lending Revenue", cat: "Securities Revenue", type: "deposit", base: 53400 },
    { desc: "Quarterly Trust Yield Disbursement Settlement", cat: "Trust Yield", type: "deposit", base: 198e3 },
    { desc: "Government Sovereign Bond Maturity Credit", cat: "Sovereign Debt", type: "deposit", base: 275e3 }
  ];
  const startTimestamp = (/* @__PURE__ */ new Date("2020-01-15")).getTime();
  const endTimestamp = (/* @__PURE__ */ new Date("2026-10-28")).getTime();
  const timeStep = (endTimestamp - startTimestamp) / 95;
  for (let i = 0; i < 94; i++) {
    const itemDate = new Date(startTimestamp + i * timeStep);
    const dateStr = itemDate.toISOString().split("T")[0];
    const template = descriptions[i % descriptions.length];
    const variance = i * 37 % 5e4 - 25e3;
    let finalAmount = Math.max(15e3, Math.min(295e3, template.base + variance));
    finalAmount = Math.round(finalAmount * 100) / 100;
    const refNumber = `LHT-TXN-${itemDate.getFullYear()}-${String(1e3 + i * 29).padStart(5, "0")}`;
    transactions.push({
      id: `tx-gen-${i + 1}`,
      date: dateStr,
      reference: refNumber,
      description: template.desc,
      type: template.type,
      amount: finalAmount,
      currency: "USD",
      status: "Completed",
      category: template.cat,
      counterparty: "Litchfield Institutional Clearing Depository",
      notes: `Demonstration transaction record for internal ledger demonstration #${i + 1}`
    });
  }
  transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  return transactions;
}
var initialDatabaseData = {
  profile: {
    accountHolderName: "Aurelian House Heritage Trust & Private Advisory",
    accountNumber: "LHT-9048-2819-0192",
    accountType: "Private Reserve & Discretionary Wealth Trust",
    accountDescription: "Institutional demonstration multi-currency wealth management repository with active discretionary liquidity facility.",
    currency: "USD",
    status: "Active / Verified Demonstration",
    routingNumber: "LHT-US-021000089",
    swiftBic: "LHTRUS33XXX",
    establishedNotice: "Demonstration repository established for institutional architecture and evaluation",
    presentationTheme: "heritage-gold"
  },
  balances: {
    currentBalance: 14850240,
    availableDiscretionaryLiquidity: 62e5,
    currency: "USD",
    lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
    updatedBy: "Litchfield Institutional Fiduciary Administrator"
  },
  transactions: generateTransactions(),
  auditLogs: [
    {
      id: "audit-001",
      action: "INITIALIZE_INSTITUTIONAL_LEDGER",
      administrator: "Master Fiduciary Officer (777000)",
      timestamp: "2026-11-01T09:00:00Z",
      previousValue: "Uninitialized",
      newValue: "Ledger Established with Current Balance: $14,850,240.00, Liquidity: $6,200,000.00",
      reason: "Platform initialization and technical demonstration benchmark calibration",
      category: "system"
    },
    {
      id: "audit-002",
      action: "UPDATE_DISCRETIONARY_LIQUIDITY",
      administrator: "Master Fiduciary Officer (777000)",
      timestamp: "2026-11-02T14:30:00Z",
      previousValue: "$5,800,000.00",
      newValue: "$6,200,000.00",
      reason: "Discretionary liquidity facility periodic adjustment demonstration",
      category: "balance"
    }
  ],
  beneficiaries: [
    {
      id: "ben-01",
      fullName: "Aurelian International Fiduciary Ltd",
      bankName: "First Abu Dhabi Bank (FAB)",
      bankAddress: "FAB Building, Khalifa Business Park, Abu Dhabi, UAE",
      accountNumberOrIban: "AE070331234567890123456",
      swiftBic: "FABAAEADXXX",
      country: "United Arab Emirates",
      currency: "AED",
      notes: "Designated corporate fiduciary beneficiary in the UAE",
      createdAt: "2024-03-12"
    },
    {
      id: "ben-02",
      fullName: "Geneva Private Wealth Depository S.A.",
      bankName: "UBS Switzerland AG",
      bankAddress: "Bahnhofstrasse 45, 8001 Zurich, Switzerland",
      accountNumberOrIban: "CH9300240240123456789",
      swiftBic: "UBSWCHZHXXX",
      country: "Switzerland",
      currency: "USD",
      notes: "European custodial repository account",
      createdAt: "2023-08-20"
    },
    {
      id: "ben-03",
      fullName: "Coutts Fiduciary Estate Trustees",
      bankName: "Coutts & Company",
      bankAddress: "440 Strand, London WC2R 0QS, United Kingdom",
      accountNumberOrIban: "GB29COUT18000212345678",
      swiftBic: "COUTGB22XXX",
      country: "United Kingdom",
      currency: "GBP",
      notes: "Heritage estate advisory council",
      createdAt: "2022-11-05"
    },
    {
      id: "ben-04",
      fullName: "Riyadh Sovereign Advisory Partners",
      bankName: "The Saudi National Bank (SNB)",
      bankAddress: "King Fahd Road, Riyadh 11564, Kingdom of Saudi Arabia",
      accountNumberOrIban: "SA0310000001234567890123",
      swiftBic: "NCBKSARXXXX",
      country: "Saudi Arabia",
      currency: "SAR",
      notes: "Strategic Middle Eastern consultative reserve",
      createdAt: "2025-01-14"
    }
  ],
  notifications: [
    {
      id: "notif-01",
      title: "Institutional Platform Verification Complete",
      message: "All demonstration balances and transaction ledgers are synchronized across central institutional storage. Remember that all figures are simulated.",
      date: "2026-11-02T10:00:00Z",
      isRead: false,
      priority: "institutional",
      sender: "Administrator Directorate"
    },
    {
      id: "notif-02",
      title: "Discretionary Liquidity Schedule Notice",
      message: "Available Discretionary Liquidity has been recalibrated to $6,200,000.00 USD under administrative fiduciary review.",
      date: "2026-11-01T15:20:00Z",
      isRead: false,
      priority: "advisory",
      sender: "Treasury & Risk Desk"
    },
    {
      id: "notif-03",
      title: "Demonstration Transfer Protocol Notice",
      message: "For security and compliance reasons, all outbound domestic and international wire transfer requests in this environment will simulate review and terminate with simulated status.",
      date: "2026-10-30T08:45:00Z",
      isRead: true,
      priority: "routine",
      sender: "Compliance Directorate"
    }
  ]
};

// server/db.ts
var DB_DIR = path.resolve(process.cwd(), "data");
var DB_FILE = path.resolve(DB_DIR, "database.json");
var currentDb = JSON.parse(JSON.stringify(initialDatabaseData));
function initDatabase() {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    if (fs.existsSync(DB_FILE)) {
      const fileContent = fs.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(fileContent);
      if (parsed.profile && parsed.balances && Array.isArray(parsed.transactions)) {
        currentDb = parsed;
        console.log(`[Database] Loaded persistent data with ${currentDb.transactions.length} transactions.`);
        return;
      }
    }
    saveDatabaseSync();
    console.log(`[Database] Initialized new database with seed data.`);
  } catch (err) {
    console.error("[Database] Failed to load database file, using in-memory seed:", err);
  }
}
function saveDatabaseSync() {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(currentDb, null, 2), "utf-8");
  } catch (err) {
    console.error("[Database] Failed to write database to disk:", err);
  }
}
var dbService = {
  getSnapshot() {
    return JSON.parse(JSON.stringify(currentDb));
  },
  getProfile() {
    return { ...currentDb.profile };
  },
  updateProfile(profileUpdate, adminName) {
    const prev = JSON.stringify(currentDb.profile);
    currentDb.profile = { ...currentDb.profile, ...profileUpdate };
    this.addAuditLog({
      action: "UPDATE_ACCOUNT_PROFILE",
      administrator: adminName || "Master Administrator (777000)",
      previousValue: prev,
      newValue: JSON.stringify(currentDb.profile),
      reason: "Administrative profile update across synchronized dashboards",
      category: "profile"
    });
    saveDatabaseSync();
    return { ...currentDb.profile };
  },
  getBalances() {
    return { ...currentDb.balances };
  },
  updateBalances(newCurrent, newLiquidity, justification, adminName) {
    const prevStr = `Current: $${currentDb.balances.currentBalance.toLocaleString()}, Liquidity: $${currentDb.balances.availableDiscretionaryLiquidity.toLocaleString()}`;
    const newStr = `Current: $${newCurrent.toLocaleString()}, Liquidity: $${newLiquidity.toLocaleString()}`;
    currentDb.balances = {
      ...currentDb.balances,
      currentBalance: Number(newCurrent),
      availableDiscretionaryLiquidity: Number(newLiquidity),
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString(),
      updatedBy: adminName || "Master Administrator (777000)"
    };
    this.addAuditLog({
      action: "CALIBRATE_DEMONSTRATION_BALANCES",
      administrator: adminName || "Master Administrator (777000)",
      previousValue: prevStr,
      newValue: newStr,
      reason: justification || "Mandatory administrative ledger demonstration recalibration",
      category: "balance"
    });
    saveDatabaseSync();
    return { ...currentDb.balances };
  },
  getTransactions(params) {
    let list = [...currentDb.transactions];
    if (params?.search) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(
        (t) => t.description.toLowerCase().includes(q) || t.reference.toLowerCase().includes(q) || t.category.toLowerCase().includes(q) || t.counterparty && t.counterparty.toLowerCase().includes(q)
      );
    }
    if (params?.type && params.type !== "all") {
      list = list.filter((t) => t.type === params.type);
    }
    if (params?.status && params.status !== "all") {
      list = list.filter((t) => t.status === params.status);
    }
    if (params?.startDate) {
      list = list.filter((t) => t.date >= params.startDate);
    }
    if (params?.endDate) {
      list = list.filter((t) => t.date <= params.endDate);
    }
    const total = list.length;
    const offset = params?.offset || 0;
    const limit = params?.limit || 20;
    const items = list.slice(offset, offset + limit);
    return { items, total };
  },
  getAllTransactions() {
    return [...currentDb.transactions];
  },
  createTransaction(tx, adminName) {
    const newTx = {
      ...tx,
      id: `tx-${Date.now()}-${Math.floor(Math.random() * 1e3)}`
    };
    currentDb.transactions.unshift(newTx);
    this.addAuditLog({
      action: "CREATE_DEMONSTRATION_TRANSACTION",
      administrator: adminName || "Master Administrator (777000)",
      previousValue: "None",
      newValue: `${newTx.reference}: ${newTx.description} ($${newTx.amount.toLocaleString()} ${newTx.currency})`,
      reason: "Administrative demonstration transaction insertion",
      category: "transaction"
    });
    saveDatabaseSync();
    return newTx;
  },
  updateTransaction(id, update, adminName) {
    const index = currentDb.transactions.findIndex((t) => t.id === id);
    if (index === -1) return null;
    const prev = JSON.stringify(currentDb.transactions[index]);
    currentDb.transactions[index] = { ...currentDb.transactions[index], ...update };
    const next = JSON.stringify(currentDb.transactions[index]);
    this.addAuditLog({
      action: "UPDATE_DEMONSTRATION_TRANSACTION",
      administrator: adminName || "Master Administrator (777000)",
      previousValue: prev,
      newValue: next,
      reason: "Administrative demonstration transaction record amendment",
      category: "transaction"
    });
    saveDatabaseSync();
    return currentDb.transactions[index];
  },
  deleteTransaction(id, adminName) {
    const index = currentDb.transactions.findIndex((t) => t.id === id);
    if (index === -1) return false;
    const removed = currentDb.transactions[index];
    currentDb.transactions.splice(index, 1);
    this.addAuditLog({
      action: "DELETE_DEMONSTRATION_TRANSACTION",
      administrator: adminName || "Master Administrator (777000)",
      previousValue: `${removed.reference}: ${removed.description} ($${removed.amount})`,
      newValue: "DELETED",
      reason: "Administrative demonstration transaction removal",
      category: "transaction"
    });
    saveDatabaseSync();
    return true;
  },
  getAuditLogs() {
    return [...currentDb.auditLogs];
  },
  addAuditLog(entry) {
    const logItem = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ...entry
    };
    currentDb.auditLogs.unshift(logItem);
    return logItem;
  },
  getBeneficiaries() {
    return [...currentDb.beneficiaries];
  },
  addBeneficiary(ben) {
    const newBen = {
      ...ben,
      id: `ben-${Date.now()}`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
    };
    currentDb.beneficiaries.unshift(newBen);
    saveDatabaseSync();
    return newBen;
  },
  updateBeneficiary(id, update) {
    const index = currentDb.beneficiaries.findIndex((b) => b.id === id);
    if (index === -1) return null;
    currentDb.beneficiaries[index] = { ...currentDb.beneficiaries[index], ...update };
    saveDatabaseSync();
    return currentDb.beneficiaries[index];
  },
  deleteBeneficiary(id) {
    const index = currentDb.beneficiaries.findIndex((b) => b.id === id);
    if (index === -1) return false;
    currentDb.beneficiaries.splice(index, 1);
    saveDatabaseSync();
    return true;
  },
  getNotifications() {
    return [...currentDb.notifications];
  },
  addNotification(notif, adminName) {
    const item = {
      ...notif,
      id: `notif-${Date.now()}`,
      date: (/* @__PURE__ */ new Date()).toISOString(),
      isRead: false
    };
    currentDb.notifications.unshift(item);
    this.addAuditLog({
      action: "BROADCAST_INSTITUTIONAL_ANNOUNCEMENT",
      administrator: adminName || "Master Administrator (777000)",
      previousValue: "None",
      newValue: item.title,
      reason: "Broadcast announcement to visitor dashboard",
      category: "announcement"
    });
    saveDatabaseSync();
    return item;
  },
  markNotificationRead(id) {
    const index = currentDb.notifications.findIndex((n) => n.id === id);
    if (index === -1) return false;
    currentDb.notifications[index].isRead = true;
    saveDatabaseSync();
    return true;
  }
};

// server.ts
var __filename = fileURLToPath(import.meta.url);
var __dirname = path2.dirname(__filename);
initDatabase();
var app = express();
var PORT = process.env.PORT || 3e3;
app.use(express.json());
var activeSessions = /* @__PURE__ */ new Map();
var failedAttempts = /* @__PURE__ */ new Map();
function requireAuth(allowedRoles) {
  return (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "Authentication required" });
      return;
    }
    const token = authHeader.substring(7);
    const session = activeSessions.get(token);
    if (!session || session.expiresAt < Date.now()) {
      res.status(401).json({ error: "Session expired or invalid" });
      return;
    }
    if (allowedRoles && !allowedRoles.includes(session.role)) {
      res.status(403).json({ error: "Access denied: insufficient administrative privileges" });
      return;
    }
    req.user = session;
    next();
  };
}
app.post("/api/auth/verify-email", (req, res) => {
  const { email } = req.body;
  const normalized = (email || "").toLowerCase().trim();
  const attempts = failedAttempts.get(normalized);
  if (attempts?.lockedUntil && attempts.lockedUntil > Date.now()) {
    const remainingSecs = Math.ceil((attempts.lockedUntil - Date.now()) / 1e3);
    res.status(429).json({
      error: `Too many failed attempts. Security lock active. Please wait ${remainingSecs} seconds.`
    });
    return;
  }
  const AUTHORIZED_EMAIL = "aurelianhouse777@gmail.com";
  if (normalized !== AUTHORIZED_EMAIL) {
    res.status(400).json({
      error: "Unrecognized institutional access email. Please check your credentials."
    });
    return;
  }
  res.json({
    success: true,
    message: "Authorized institutional account verified. Simulated dispatch code ready."
  });
});
app.post("/api/auth/verify-code", (req, res) => {
  const { email, code } = req.body;
  const normalizedEmail = (email || "").toLowerCase().trim();
  const trimmedCode = (code || "").trim();
  const attemptsKey = normalizedEmail || "default";
  const currentAttempts = failedAttempts.get(attemptsKey) || { count: 0 };
  if (currentAttempts.lockedUntil && currentAttempts.lockedUntil > Date.now()) {
    const remainingSecs = Math.ceil((currentAttempts.lockedUntil - Date.now()) / 1e3);
    res.status(429).json({
      error: `Security cool-down period active. Please retry in ${remainingSecs} seconds.`
    });
    return;
  }
  const AUTHORIZED_EMAIL = "aurelianhouse777@gmail.com";
  const ADMIN_CODE = "777000";
  const VISITOR_CODE = "EBSN98765";
  if (normalizedEmail !== AUTHORIZED_EMAIL) {
    res.status(401).json({
      error: "Invalid access code. Please verify your access credentials and try again."
    });
    return;
  }
  let role = null;
  if (trimmedCode === ADMIN_CODE) {
    role = "administrator";
  } else if (trimmedCode === VISITOR_CODE) {
    role = "visitor";
  }
  if (!role) {
    currentAttempts.count += 1;
    if (currentAttempts.count >= 5) {
      currentAttempts.lockedUntil = Date.now() + 6e4;
    }
    failedAttempts.set(attemptsKey, currentAttempts);
    res.status(401).json({
      error: "Invalid access code. Please verify your access credentials and try again."
    });
    return;
  }
  failedAttempts.delete(attemptsKey);
  const token = `lht_token_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
  const session = {
    token,
    role,
    email: normalizedEmail,
    expiresAt: Date.now() + 1e3 * 60 * 60 * 12
    // 12 hours
  };
  activeSessions.set(token, session);
  dbService.addAuditLog({
    action: "AUTHENTICATION_SUCCESS",
    administrator: role === "administrator" ? "Master Fiduciary (777000)" : "Designated Visitor (EBSN98765)",
    previousValue: "Session Inactive",
    newValue: `Session Established [Role: ${role.toUpperCase()}]`,
    reason: "Authorized prototype access handshake",
    category: "system"
  });
  res.json({
    success: true,
    token,
    role,
    email: normalizedEmail
  });
});
app.post("/api/auth/logout", requireAuth(), (req, res) => {
  const token = req.user.token;
  activeSessions.delete(token);
  res.json({ success: true, message: "Session terminated" });
});
app.get("/api/auth/me", requireAuth(), (req, res) => {
  res.json({ user: req.user });
});
app.get("/api/account", (req, res) => {
  const profile = dbService.getProfile();
  const balances = dbService.getBalances();
  res.json({ profile, balances });
});
app.put("/api/account/profile", requireAuth(["administrator"]), (req, res) => {
  const update = req.body;
  const adminEmail = req.user.email;
  const updatedProfile = dbService.updateProfile(update, adminEmail);
  res.json({ success: true, profile: updatedProfile });
});
app.put("/api/account/balances", requireAuth(["administrator"]), (req, res) => {
  const { currentBalance, availableDiscretionaryLiquidity, justification } = req.body;
  if (currentBalance === void 0 || availableDiscretionaryLiquidity === void 0) {
    res.status(400).json({ error: "Both Current Balance and Available Discretionary Liquidity must be specified." });
    return;
  }
  if (!justification || justification.trim().length < 5) {
    res.status(400).json({ error: "A mandatory justification of at least 5 characters is required for institutional audit compliance." });
    return;
  }
  const adminEmail = req.user.email;
  const balances = dbService.updateBalances(
    Number(currentBalance),
    Number(availableDiscretionaryLiquidity),
    justification.trim(),
    adminEmail
  );
  res.json({ success: true, balances });
});
app.get("/api/transactions", (req, res) => {
  const { search, type, status, startDate, endDate, limit, offset } = req.query;
  const result = dbService.getTransactions({
    search,
    type,
    status,
    startDate,
    endDate,
    limit: limit ? parseInt(limit, 10) : void 0,
    offset: offset ? parseInt(offset, 10) : void 0
  });
  res.json(result);
});
app.get("/api/transactions/all", (req, res) => {
  const all = dbService.getAllTransactions();
  res.json({ items: all, total: all.length });
});
app.post("/api/transactions", requireAuth(["administrator"]), (req, res) => {
  const txData = req.body;
  if (!txData.description || txData.amount === void 0 || !txData.type) {
    res.status(400).json({ error: "Missing required transaction fields" });
    return;
  }
  const adminEmail = req.user.email;
  const created = dbService.createTransaction(txData, adminEmail);
  res.status(201).json({ success: true, transaction: created });
});
app.put("/api/transactions/:id", requireAuth(["administrator"]), (req, res) => {
  const { id } = req.params;
  const adminEmail = req.user.email;
  const updated = dbService.updateTransaction(id, req.body, adminEmail);
  if (!updated) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  res.json({ success: true, transaction: updated });
});
app.delete("/api/transactions/:id", requireAuth(["administrator"]), (req, res) => {
  const { id } = req.params;
  const adminEmail = req.user.email;
  const deleted = dbService.deleteTransaction(id, adminEmail);
  if (!deleted) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  res.json({ success: true });
});
app.get("/api/audit-logs", requireAuth(["administrator"]), (req, res) => {
  const logs = dbService.getAuditLogs();
  res.json({ items: logs, total: logs.length });
});
app.get("/api/beneficiaries", (req, res) => {
  res.json({ items: dbService.getBeneficiaries() });
});
app.post("/api/beneficiaries", requireAuth(), (req, res) => {
  const data = req.body;
  if (!data.fullName || !data.bankName || !data.accountNumberOrIban) {
    res.status(400).json({ error: "Missing mandatory beneficiary fields" });
    return;
  }
  const created = dbService.addBeneficiary(data);
  res.status(201).json({ success: true, beneficiary: created });
});
app.put("/api/beneficiaries/:id", requireAuth(), (req, res) => {
  const { id } = req.params;
  const updated = dbService.updateBeneficiary(id, req.body);
  if (!updated) {
    res.status(404).json({ error: "Beneficiary not found" });
    return;
  }
  res.json({ success: true, beneficiary: updated });
});
app.delete("/api/beneficiaries/:id", requireAuth(), (req, res) => {
  const { id } = req.params;
  const deleted = dbService.deleteBeneficiary(id);
  if (!deleted) {
    res.status(404).json({ error: "Beneficiary not found" });
    return;
  }
  res.json({ success: true });
});
app.get("/api/notifications", (req, res) => {
  res.json({ items: dbService.getNotifications() });
});
app.post("/api/notifications", requireAuth(["administrator"]), (req, res) => {
  const { title, message, priority, sender } = req.body;
  if (!title || !message) {
    res.status(400).json({ error: "Title and message are required" });
    return;
  }
  const adminEmail = req.user.email;
  const created = dbService.addNotification(
    {
      title,
      message,
      priority: priority || "institutional",
      sender: sender || "Administrator Directorate"
    },
    adminEmail
  );
  res.status(201).json({ success: true, notification: created });
});
app.patch("/api/notifications/:id/read", (req, res) => {
  const { id } = req.params;
  const ok = dbService.markNotificationRead(id);
  res.json({ success: ok });
});
app.post("/api/transfers/domestic", requireAuth(), (req, res) => {
  const { recipientName, recipientAccount, receivingInstitution, amount, currency } = req.body;
  if (!recipientName || !recipientAccount || !amount || !receivingInstitution) {
    res.status(400).json({ error: "Missing required transfer details" });
    return;
  }
  res.status(400).json({
    status: "Transaction Failed",
    message: "Your transfer could not be completed in this demonstration environment. No funds have been transferred or deducted from your displayed account balance.",
    reference: `LHT-FAIL-${Date.now().toString().slice(-6)}`,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.post("/api/transfers/international", requireAuth(), (req, res) => {
  const { beneficiaryName, bankName, accountNumberOrIban, swiftBic, destinationCountry, amount, currency } = req.body;
  if (!beneficiaryName || !bankName || !accountNumberOrIban || !swiftBic || !destinationCountry || !amount) {
    res.status(400).json({ error: "Missing mandatory international wire fields" });
    return;
  }
  res.status(400).json({
    status: "Transaction Failed",
    message: "Your transfer could not be completed in this demonstration environment. No funds have been transferred or deducted from your displayed account balance.",
    reference: `LHT-WIRE-FAIL-${Date.now().toString().slice(-6)}`,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.post("/api/contact", (req, res) => {
  const { fullName, email, subject, message } = req.body;
  if (!fullName || !email || !message) {
    res.status(400).json({ error: "Please provide full name, email, and message." });
    return;
  }
  res.json({
    success: true,
    message: "Demonstration inquiry received. Please note that Litchfield Heritage Trust is an institutional platform under development; no automated messages or live mail dispatch occurs in this demonstration."
  });
});
async function startServer() {
  const isProd = process.env.NODE_ENV === "production";
  if (!isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path2.resolve(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path2.resolve(__dirname, "dist", "index.html"));
    });
  }
  app.listen(PORT, () => {
    console.log(`[LHT Server] Running on http://localhost:${PORT}`);
  });
}
startServer();
