import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dbService, initDatabase } from './server/db';
import { AuthSession, UserRole } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize DB
initDatabase();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Session store
const activeSessions = new Map<string, AuthSession>();

// Failed attempts tracker for rate limiting
const failedAttempts = new Map<string, { count: number; lockedUntil?: number }>();

// Helper auth middleware
function requireAuth(allowedRoles?: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    const token = authHeader.substring(7);
    const session = activeSessions.get(token);

    if (!session || session.expiresAt < Date.now()) {
      res.status(401).json({ error: 'Session expired or invalid' });
      return;
    }

    if (allowedRoles && !allowedRoles.includes(session.role)) {
      res.status(403).json({ error: 'Access denied: insufficient administrative privileges' });
      return;
    }

    (req as any).user = session;
    next();
  };
}

// 1. AUTHENTICATION ENDPOINTS
// Stage 1: Validate Email
app.post('/api/auth/verify-email', (req: Request, res: Response) => {
  const { email } = req.body;
  const normalized = (email || '').toLowerCase().trim();

  // Rate limiting check
  const attempts = failedAttempts.get(normalized);
  if (attempts?.lockedUntil && attempts.lockedUntil > Date.now()) {
    const remainingSecs = Math.ceil((attempts.lockedUntil - Date.now()) / 1000);
    res.status(429).json({
      error: `Too many failed attempts. Security lock active. Please wait ${remainingSecs} seconds.`
    });
    return;
  }

  const AUTHORIZED_EMAIL = 'aurelianhouse777@gmail.com';
  if (normalized !== AUTHORIZED_EMAIL) {
    res.status(400).json({
      error: 'Unrecognized institutional access email. Please check your credentials.'
    });
    return;
  }

  res.json({
    success: true,
    message: 'Authorized institutional account verified. Simulated dispatch code ready.'
  });
});

// Stage 3: Verify Access Code
app.post('/api/auth/verify-code', (req: Request, res: Response) => {
  const { email, code } = req.body;
  const normalizedEmail = (email || '').toLowerCase().trim();
  const trimmedCode = (code || '').trim();

  const attemptsKey = normalizedEmail || 'default';
  const currentAttempts = failedAttempts.get(attemptsKey) || { count: 0 };

  if (currentAttempts.lockedUntil && currentAttempts.lockedUntil > Date.now()) {
    const remainingSecs = Math.ceil((currentAttempts.lockedUntil - Date.now()) / 1000);
    res.status(429).json({
      error: `Security cool-down period active. Please retry in ${remainingSecs} seconds.`
    });
    return;
  }

  const AUTHORIZED_EMAIL = 'aurelianhouse777@gmail.com';
  const ADMIN_CODE = '777000';
  const VISITOR_CODE = 'EBSN98765';

  if (normalizedEmail !== AUTHORIZED_EMAIL) {
    res.status(401).json({
      error: 'Invalid access code. Please verify your access credentials and try again.'
    });
    return;
  }

  let role: UserRole | null = null;
  if (trimmedCode === ADMIN_CODE) {
    role = 'administrator';
  } else if (trimmedCode === VISITOR_CODE) {
    role = 'visitor';
  }

  if (!role) {
    currentAttempts.count += 1;
    if (currentAttempts.count >= 5) {
      currentAttempts.lockedUntil = Date.now() + 60000; // 1 min lock
    }
    failedAttempts.set(attemptsKey, currentAttempts);

    res.status(401).json({
      error: 'Invalid access code. Please verify your access credentials and try again.'
    });
    return;
  }

  // Reset failed attempts on success
  failedAttempts.delete(attemptsKey);

  const token = `lht_token_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
  const session: AuthSession = {
    token,
    role,
    email: normalizedEmail,
    expiresAt: Date.now() + 1000 * 60 * 60 * 12 // 12 hours
  };

  activeSessions.set(token, session);

  // Add audit record
  dbService.addAuditLog({
    action: 'AUTHENTICATION_SUCCESS',
    administrator: role === 'administrator' ? 'Master Fiduciary (777000)' : 'Designated Visitor (EBSN98765)',
    previousValue: 'Session Inactive',
    newValue: `Session Established [Role: ${role.toUpperCase()}]`,
    reason: 'Authorized prototype access handshake',
    category: 'system'
  });

  res.json({
    success: true,
    token,
    role,
    email: normalizedEmail
  });
});

app.post('/api/auth/logout', requireAuth(), (req: Request, res: Response) => {
  const token = (req as any).user.token;
  activeSessions.delete(token);
  res.json({ success: true, message: 'Session terminated' });
});

app.get('/api/auth/me', requireAuth(), (req: Request, res: Response) => {
  res.json({ user: (req as any).user });
});

// 2. ACCOUNT PROFILE & BALANCES
app.get('/api/account', (req: Request, res: Response) => {
  // Publicly readable for demo or visitor/admin
  const profile = dbService.getProfile();
  const balances = dbService.getBalances();
  res.json({ profile, balances });
});

// Administrator Profile Update
app.put('/api/account/profile', requireAuth(['administrator']), (req: Request, res: Response) => {
  const update = req.body;
  const adminEmail = (req as any).user.email;
  const updatedProfile = dbService.updateProfile(update, adminEmail);
  res.json({ success: true, profile: updatedProfile });
});

// Administrator Balance Calibration
app.put('/api/account/balances', requireAuth(['administrator']), (req: Request, res: Response) => {
  const { currentBalance, availableDiscretionaryLiquidity, justification } = req.body;

  if (currentBalance === undefined || availableDiscretionaryLiquidity === undefined) {
    res.status(400).json({ error: 'Both Current Balance and Available Discretionary Liquidity must be specified.' });
    return;
  }

  if (!justification || justification.trim().length < 5) {
    res.status(400).json({ error: 'A mandatory justification of at least 5 characters is required for institutional audit compliance.' });
    return;
  }

  const adminEmail = (req as any).user.email;
  const balances = dbService.updateBalances(
    Number(currentBalance),
    Number(availableDiscretionaryLiquidity),
    justification.trim(),
    adminEmail
  );

  res.json({ success: true, balances });
});

// 3. TRANSACTIONS
app.get('/api/transactions', (req: Request, res: Response) => {
  const { search, type, status, startDate, endDate, limit, offset } = req.query;
  const result = dbService.getTransactions({
    search: search as string,
    type: type as string,
    status: status as string,
    startDate: startDate as string,
    endDate: endDate as string,
    limit: limit ? parseInt(limit as string, 10) : undefined,
    offset: offset ? parseInt(offset as string, 10) : undefined
  });
  res.json(result);
});

app.get('/api/transactions/all', (req: Request, res: Response) => {
  const all = dbService.getAllTransactions();
  res.json({ items: all, total: all.length });
});

app.post('/api/transactions', requireAuth(['administrator']), (req: Request, res: Response) => {
  const txData = req.body;
  if (!txData.description || txData.amount === undefined || !txData.type) {
    res.status(400).json({ error: 'Missing required transaction fields' });
    return;
  }
  const adminEmail = (req as any).user.email;
  const created = dbService.createTransaction(txData, adminEmail);
  res.status(201).json({ success: true, transaction: created });
});

app.put('/api/transactions/:id', requireAuth(['administrator']), (req: Request, res: Response) => {
  const { id } = req.params;
  const adminEmail = (req as any).user.email;
  const updated = dbService.updateTransaction(id, req.body, adminEmail);
  if (!updated) {
    res.status(404).json({ error: 'Transaction not found' });
    return;
  }
  res.json({ success: true, transaction: updated });
});

app.delete('/api/transactions/:id', requireAuth(['administrator']), (req: Request, res: Response) => {
  const { id } = req.params;
  const adminEmail = (req as any).user.email;
  const deleted = dbService.deleteTransaction(id, adminEmail);
  if (!deleted) {
    res.status(404).json({ error: 'Transaction not found' });
    return;
  }
  res.json({ success: true });
});

// 4. AUDIT LOGS (Admin only)
app.get('/api/audit-logs', requireAuth(['administrator']), (req: Request, res: Response) => {
  const logs = dbService.getAuditLogs();
  res.json({ items: logs, total: logs.length });
});

// 5. BENEFICIARIES
app.get('/api/beneficiaries', (req: Request, res: Response) => {
  res.json({ items: dbService.getBeneficiaries() });
});

app.post('/api/beneficiaries', requireAuth(), (req: Request, res: Response) => {
  const data = req.body;
  if (!data.fullName || !data.bankName || !data.accountNumberOrIban) {
    res.status(400).json({ error: 'Missing mandatory beneficiary fields' });
    return;
  }
  const created = dbService.addBeneficiary(data);
  res.status(201).json({ success: true, beneficiary: created });
});

app.put('/api/beneficiaries/:id', requireAuth(), (req: Request, res: Response) => {
  const { id } = req.params;
  const updated = dbService.updateBeneficiary(id, req.body);
  if (!updated) {
    res.status(404).json({ error: 'Beneficiary not found' });
    return;
  }
  res.json({ success: true, beneficiary: updated });
});

app.delete('/api/beneficiaries/:id', requireAuth(), (req: Request, res: Response) => {
  const { id } = req.params;
  const deleted = dbService.deleteBeneficiary(id);
  if (!deleted) {
    res.status(404).json({ error: 'Beneficiary not found' });
    return;
  }
  res.json({ success: true });
});

// 6. NOTIFICATIONS
app.get('/api/notifications', (req: Request, res: Response) => {
  res.json({ items: dbService.getNotifications() });
});

app.post('/api/notifications', requireAuth(['administrator']), (req: Request, res: Response) => {
  const { title, message, priority, sender } = req.body;
  if (!title || !message) {
    res.status(400).json({ error: 'Title and message are required' });
    return;
  }
  const adminEmail = (req as any).user.email;
  const created = dbService.addNotification(
    {
      title,
      message,
      priority: priority || 'institutional',
      sender: sender || 'Administrator Directorate'
    },
    adminEmail
  );
  res.status(201).json({ success: true, notification: created });
});

app.patch('/api/notifications/:id/read', (req: Request, res: Response) => {
  const { id } = req.params;
  const ok = dbService.markNotificationRead(id);
  res.json({ success: ok });
});

// 7. SIMULATED TRANSFERS (STRICT DEMONSTRATION CONTRACT: ALWAYS FAILS)
app.post('/api/transfers/domestic', requireAuth(), (req: Request, res: Response) => {
  const { recipientName, recipientAccount, receivingInstitution, amount, currency } = req.body;

  if (!recipientName || !recipientAccount || !amount || !receivingInstitution) {
    res.status(400).json({ error: 'Missing required transfer details' });
    return;
  }

  // Demonstration requirement: All transfers terminate with Transaction Failed
  res.status(400).json({
    status: 'Transaction Failed',
    message: 'Your transfer could not be completed in this demonstration environment. No funds have been transferred or deducted from your displayed account balance.',
    reference: `LHT-FAIL-${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toISOString()
  });
});

app.post('/api/transfers/international', requireAuth(), (req: Request, res: Response) => {
  const { beneficiaryName, bankName, accountNumberOrIban, swiftBic, destinationCountry, amount, currency } = req.body;

  if (!beneficiaryName || !bankName || !accountNumberOrIban || !swiftBic || !destinationCountry || !amount) {
    res.status(400).json({ error: 'Missing mandatory international wire fields' });
    return;
  }

  res.status(400).json({
    status: 'Transaction Failed',
    message: 'Your transfer could not be completed in this demonstration environment. No funds have been transferred or deducted from your displayed account balance.',
    reference: `LHT-WIRE-FAIL-${Date.now().toString().slice(-6)}`,
    timestamp: new Date().toISOString()
  });
});

// 8. CONTACT FORM DEMONSTRATION
app.post('/api/contact', (req: Request, res: Response) => {
  const { fullName, email, subject, message } = req.body;
  if (!fullName || !email || !message) {
    res.status(400).json({ error: 'Please provide full name, email, and message.' });
    return;
  }

  res.json({
    success: true,
    message: 'Demonstration inquiry received. Please note that Litchfield Heritage Trust is an institutional platform under development; no automated messages or live mail dispatch occurs in this demonstration.'
  });
});

// 9. VITE DEV SERVER OR STATIC PRODUCTION
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[LHT Server] Running on http://localhost:${PORT}`);
  });
}

startServer();
