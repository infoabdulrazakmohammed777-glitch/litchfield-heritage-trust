import { AccountBalances, AccountProfile, AuditLogEntry, Beneficiary, NotificationItem, TransactionRecord, UserRole } from './types';

const TOKEN_KEY = 'lht_auth_token';
const ROLE_KEY = 'lht_auth_role';
const EMAIL_KEY = 'lht_auth_email';

export const authStorage = {
  getToken: () => localStorage.getItem(TOKEN_KEY),
  getRole: () => (localStorage.getItem(ROLE_KEY) as UserRole) || null,
  getEmail: () => localStorage.getItem(EMAIL_KEY),
  setSession: (token: string, role: UserRole, email: string) => {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(ROLE_KEY, role);
    localStorage.setItem(EMAIL_KEY, email);
  },
  clearSession: () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(ROLE_KEY);
    localStorage.removeItem(EMAIL_KEY);
  }
};

async function apiRequest<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = authStorage.getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>)
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || data.message || `Request failed with status ${response.status}`);
  }

  return data as T;
}

export const api = {
  // Auth
  verifyEmail: (email: string) =>
    apiRequest<{ success: boolean; message: string }>('/api/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify({ email })
    }),

  verifyCode: (email: string, code: string) =>
    apiRequest<{ success: boolean; token: string; role: UserRole; email: string }>('/api/auth/verify-code', {
      method: 'POST',
      body: JSON.stringify({ email, code })
    }),

  logout: async () => {
    try {
      await apiRequest('/api/auth/logout', { method: 'POST' });
    } catch (e) {
      // Continue client cleanup even if network fails
    } finally {
      authStorage.clearSession();
    }
  },

  // Account
  getAccount: () =>
    apiRequest<{ profile: AccountProfile; balances: AccountBalances }>('/api/account'),

  updateProfile: (profile: Partial<AccountProfile>) =>
    apiRequest<{ success: boolean; profile: AccountProfile }>('/api/account/profile', {
      method: 'PUT',
      body: JSON.stringify(profile)
    }),

  updateBalances: (currentBalance: number, availableDiscretionaryLiquidity: number, justification: string) =>
    apiRequest<{ success: boolean; balances: AccountBalances }>('/api/account/balances', {
      method: 'PUT',
      body: JSON.stringify({ currentBalance, availableDiscretionaryLiquidity, justification })
    }),

  // Transactions
  getTransactions: (params?: {
    search?: string;
    type?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    limit?: number;
    offset?: number;
  }) => {
    const searchParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, val]) => {
        if (val !== undefined && val !== '') {
          searchParams.append(key, String(val));
        }
      });
    }
    const query = searchParams.toString();
    return apiRequest<{ items: TransactionRecord[]; total: number }>(`/api/transactions${query ? `?${query}` : ''}`);
  },

  getAllTransactions: () =>
    apiRequest<{ items: TransactionRecord[]; total: number }>('/api/transactions/all'),

  createTransaction: (data: Omit<TransactionRecord, 'id'>) =>
    apiRequest<{ success: boolean; transaction: TransactionRecord }>('/api/transactions', {
      method: 'POST',
      body: JSON.stringify(data)
    }),

  updateTransaction: (id: string, data: Partial<TransactionRecord>) =>
    apiRequest<{ success: boolean; transaction: TransactionRecord }>(`/api/transactions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    }),

  deleteTransaction: (id: string) =>
    apiRequest<{ success: boolean }>(`/api/transactions/${id}`, {
      method: 'DELETE'
    }),

  // Audit Logs (Admin only)
  getAuditLogs: () =>
    apiRequest<{ items: AuditLogEntry[]; total: number }>('/api/audit-logs'),

  // Beneficiaries
  getBeneficiaries: () =>
    apiRequest<{ items: Beneficiary[] }>('/api/beneficiaries'),

  addBeneficiary: (data: Omit<Beneficiary, 'id' | 'createdAt'>) =>
    apiRequest<{ success: boolean; beneficiary: Beneficiary }>('/api/beneficiaries', {
      method: 'POST',
      body: JSON.stringify(data)
    }),

  updateBeneficiary: (id: string, data: Partial<Beneficiary>) =>
    apiRequest<{ success: boolean; beneficiary: Beneficiary }>(`/api/beneficiaries/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    }),

  deleteBeneficiary: (id: string) =>
    apiRequest<{ success: boolean }>(`/api/beneficiaries/${id}`, {
      method: 'DELETE'
    }),

  // Notifications
  getNotifications: () =>
    apiRequest<{ items: NotificationItem[] }>('/api/notifications'),

  createNotification: (data: { title: string; message: string; priority?: string; sender?: string }) =>
    apiRequest<{ success: boolean; notification: NotificationItem }>('/api/notifications', {
      method: 'POST',
      body: JSON.stringify(data)
    }),

  markNotificationRead: (id: string) =>
    apiRequest<{ success: boolean }>(`/api/notifications/${id}/read`, {
      method: 'PATCH'
    }),

  // Transfers
  submitDomesticTransfer: (data: any) =>
    apiRequest<{ status: string; message: string; reference: string }>('/api/transfers/domestic', {
      method: 'POST',
      body: JSON.stringify(data)
    }),

  submitInternationalTransfer: (data: any) =>
    apiRequest<{ status: string; message: string; reference: string }>('/api/transfers/international', {
      method: 'POST',
      body: JSON.stringify(data)
    }),

  submitContact: (data: { fullName: string; email: string; subject: string; message: string }) =>
    apiRequest<{ success: boolean; message: string }>('/api/contact', {
      method: 'POST',
      body: JSON.stringify(data)
    })
};
