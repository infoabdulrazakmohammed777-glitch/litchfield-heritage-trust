import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { PublicWebsite } from './components/PublicWebsite';
import { AuthFlow } from './components/AuthFlow';
import { AdminDashboard } from './components/AdminDashboard';
import { VisitorDashboard } from './components/VisitorDashboard';
import { authStorage, api } from './api';
import { UserRole } from './types';
import { BRAND_ASSETS } from './assets';
import { Lock } from 'lucide-react';

export function App() {
  const [currentView, setCurrentView] = useState<'public' | 'auth' | 'admin' | 'visitor'>('public');
  const [activeNavSection, setActiveNavSection] = useState('hero');
  const [loggingOut, setLoggingOut] = useState(false);

  // Check if existing token on mount
  useEffect(() => {
    const token = authStorage.getToken();
    const role = authStorage.getRole();
    if (token && role) {
      if (role === 'administrator') {
        setCurrentView('admin');
      } else if (role === 'visitor') {
        setCurrentView('visitor');
      }
    }
  }, []);

  const handleOpenSignIn = () => {
    setCurrentView('auth');
  };

  const handleAuthSuccess = (role: UserRole) => {
    if (role === 'administrator') {
      setCurrentView('admin');
    } else {
      setCurrentView('visitor');
    }
  };

  const handleLogout = async () => {
    setLoggingOut(true);
    await api.logout();

    // Shorter branded logout screen (~1.5 seconds)
    setTimeout(() => {
      setLoggingOut(false);
      setCurrentView('public');
    }, 1500);
  };

  const handleNavigateSection = (sectionId: string) => {
    setActiveNavSection(sectionId);
    if (currentView !== 'public') {
      setCurrentView('public');
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(sectionId);
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Shorter branded logout transition
  if (loggingOut) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#08142C] text-white">
        <div className="text-center space-y-6 max-w-sm px-4">
          <img
            src={BRAND_ASSETS.logo}
            alt="LHT"
            className="h-16 w-auto mx-auto bg-white/10 p-2 rounded border border-[#C5A059]/30"
          />
          <div className="relative flex items-center justify-center">
            <div className="w-12 h-12 rounded-full border-2 border-stone-700 border-t-[#C5A059] animate-spin" />
            <Lock className="w-4 h-4 text-[#DFC076] absolute" />
          </div>
          <div className="space-y-1">
            <h3 className="font-serif text-lg font-medium text-[#DFC076]">
              Terminating Secure Session
            </h3>
            <p className="text-xs text-stone-400">
              Clearing client cryptographic tokens and returning to public gateway...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#0D192B] flex flex-col font-sans">
      {/* View Switcher */}
      {currentView === 'public' && (
        <PublicWebsite
          onOpenSignIn={handleOpenSignIn}
          onNavigateSection={handleNavigateSection}
        />
      )}

      {currentView === 'auth' && (
        <>
          <PublicWebsite
            onOpenSignIn={handleOpenSignIn}
            onNavigateSection={handleNavigateSection}
          />
          <AuthFlow
            onSuccess={handleAuthSuccess}
            onCancel={() => setCurrentView('public')}
          />
        </>
      )}

      {currentView === 'admin' && (
        <AdminDashboard onLogout={handleLogout} />
      )}

      {currentView === 'visitor' && (
        <VisitorDashboard onLogout={handleLogout} />
      )}
    </div>
  );
}

export default App;
