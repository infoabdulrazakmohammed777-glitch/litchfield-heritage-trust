export type UserRole = 'administrator' | 'visitor';

export interface AuthSession {
  token: string;
  role: UserRole;
  email: string;
  expiresAt: number;
}

export interface AccountProfile {
  accountHolderName: string;
  accountNumber: string;
  accountType: string;
  accountDescription: string;
  currency: string;
  status: string;
  routingNumber: string;
  swiftBic: string;
  establishedNotice: string;
  presentationTheme: 'heritage-gold' | 'midnight-navy' | 'classic-stone';
}

export interface AccountBalances {
  currentBalance: number;
  availableDiscretionaryLiquidity: number;
  currency: string;
  lastUpdated: string;
  updatedBy: string;
}

export type TransactionType =
  | 'deposit'
  | 'withdrawal'
  | 'transfer_in'
  | 'transfer_out'
  | 'payment'
  | 'adjustment';

export type TransactionStatus = 'Completed' | 'Settled' | 'Processed' | 'Cleared';

export interface TransactionRecord {
  id: string;
  date: string;
  reference: string;
  description: string;
  type: TransactionType;
  amount: number;
  currency: string;
  status: TransactionStatus;
  category: string;
  counterparty?: string;
  notes?: string;
}

export interface AuditLogEntry {
  id: string;
  action: string;
  administrator: string;
  timestamp: string;
  previousValue: string;
  newValue: string;
  reason: string;
  category: 'balance' | 'profile' | 'transaction' | 'system' | 'announcement';
}

export interface Beneficiary {
  id: string;
  fullName: string;
  bankName: string;
  bankAddress: string;
  accountNumberOrIban: string;
  swiftBic: string;
  routingNumber?: string;
  country: string;
  currency: string;
  notes?: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  isRead: boolean;
  priority: 'routine' | 'advisory' | 'institutional';
  sender: string;
}

export interface DatabaseSchema {
  profile: AccountProfile;
  balances: AccountBalances;
  transactions: TransactionRecord[];
  auditLogs: AuditLogEntry[];
  beneficiaries: Beneficiary[];
  notifications: NotificationItem[];
}
