import React, { useState, useEffect } from 'react';
import { BRAND_ASSETS } from '../assets';
import { Lock, Mail, ArrowLeft, ArrowRight, ShieldCheck, AlertCircle, FastForward, CheckCircle2 } from 'lucide-react';
import { api, authStorage } from '../api';
import { UserRole } from '../types';

interface AuthFlowProps {
  onSuccess: (role: UserRole) => void;
  onCancel: () => void;
}

type AuthStage = 'email' | 'confirmation' | 'code' | 'loading';

export const AuthFlow: React.FC<AuthFlowProps> = ({ onSuccess, onCancel }) => {
  const [stage, setStage] = useState<AuthStage>('email');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [authenticatedRole, setAuthenticatedRole] = useState<UserRole | null>(null);

  // 60-second transition timer state
  const [secondsRemaining, setSecondsRemaining] = useState(60);
  const [loadingStepText, setLoadingStepText] = useState('Initializing Institutional Handshake...');

  // Stage 1: Validate Email
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await api.verifyEmail(email);
      setStage('confirmation');
    } catch (err: any) {
      setError(err.message || 'Invalid email credentials');
    } finally {
      setLoading(false);
    }
  };

  // Stage 2: Continue from simulated notification confirmation
  const handleConfirmationContinue = () => {
    setStage('code');
    setError(null);
  };

  // Stage 3: Verify Access Code
  const handleCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.verifyCode(email, code);
      authStorage.setSession(res.token, res.role, res.email);
      setAuthenticatedRole(res.role);
      setStage('loading');
      setSecondsRemaining(60);
    } catch (err: any) {
      // Must display exact error message:
      // "Invalid access code. Please verify your access credentials and try again."
      setError('Invalid access code. Please verify your access credentials and try again.');
    } finally {
      setLoading(false);
    }
  };

  // 60-Second Loading Screen Countdown & Step Progression
  useEffect(() => {
    if (stage !== 'loading' || !authenticatedRole) return;

    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onSuccess(authenticatedRole);
          return 0;
        }

        // Realistic progression messages through the 60s
        const remaining = prev - 1;
        if (remaining > 50) {
          setLoadingStepText('Initializing Encrypted Institutional Session...');
        } else if (remaining > 40) {
          setLoadingStepText('Establishing Fiduciary TLS Tunnel & Key Exchange...');
        } else if (remaining > 30) {
          setLoadingStepText('Verifying Cryptographic Entitlements & Signature Tokens...');
        } else if (remaining > 20) {
          setLoadingStepText('Retrieving Segregated Ledger & Account Records...');
        } else if (remaining > 10) {
          setLoadingStepText('Synchronizing Discretionary Reserve & Vault States...');
        } else {
          setLoadingStepText('Finalizing Secure Dashboard Presentation Environment...');
        }

        return remaining;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [stage, authenticatedRole, onSuccess]);

  // Fast forward button for evaluators
  const handleFastForward = () => {
    if (authenticatedRole) {
      onSuccess(authenticatedRole);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#08142C]/90 backdrop-blur-md px-4 py-8 overflow-y-auto">
      {/* 60-SECOND CIRCULAR LOADING SCREEN */}
      {stage === 'loading' ? (
        <div className="w-full max-w-lg bg-[#0B1B3D] border border-[#C5A059]/40 rounded-xl p-8 sm:p-12 text-center text-white shadow-2xl space-y-8 animate-fadeIn">
          {/* Official Logo */}
          <div className="flex justify-center">
            <img
              src={BRAND_ASSETS.logo}
              alt="Litchfield Heritage Trust"
              className="h-16 w-auto object-contain bg-white/5 p-2 rounded border border-[#C5A059]/30"
            />
          </div>

          {/* Welcome Message */}
          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-serif text-[#DFC076] tracking-tight">
              Welcome to Litchfield Heritage Trust
            </h2>
            <p className="text-xs text-stone-300 font-light tracking-wide">
              Secure Private Wealth & Fiduciary Access Portal
            </p>
          </div>

          {/* Circular Rotating Indicator - No numbers inside animated dots */}
          <div className="relative flex items-center justify-center my-6">
            <div className="w-28 h-28 rounded-full border-4 border-stone-700/50 border-t-[#C5A059] border-r-[#DFC076] animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-20 h-20 rounded-full border-2 border-[#C5A059]/20 border-b-[#C5A059] animate-spin [animation-direction:reverse] [animation-duration:3s]" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <Lock className="w-6 h-6 text-[#DFC076] drop-shadow-md" />
            </div>
          </div>

          {/* Elegant Circular Dots Animation */}
          <div className="flex items-center justify-center gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-[#C5A059] animate-bounce [animation-delay:0ms]" />
            <div className="w-2.5 h-2.5 rounded-full bg-[#DFC076] animate-bounce [animation-delay:150ms]" />
            <div className="w-2.5 h-2.5 rounded-full bg-[#C5A059] animate-bounce [animation-delay:300ms]" />
            <div className="w-2.5 h-2.5 rounded-full bg-stone-400 animate-bounce [animation-delay:450ms]" />
          </div>

          {/* Loading status text & timer notice */}
          <div className="space-y-3 pt-2">
            <p className="text-sm font-medium text-stone-200 tracking-wide font-sans">
              {loadingStepText}
            </p>
            <div className="text-[11px] text-stone-400">
              Presentation verification sequence: <span className="text-[#DFC076] font-mono tabular-nums">{secondsRemaining}s</span> remaining
            </div>
          </div>

          {/* Presentation feature fast-forward option for evaluator convenience */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-center">
            <button
              onClick={handleFastForward}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-[#DFC076] text-[11px] font-medium rounded transition-colors cursor-pointer"
            >
              <FastForward className="w-3.5 h-3.5" />
              <span>Fast-Forward Presentation Delay</span>
            </button>
          </div>
        </div>
      ) : (
        /* 3-STAGE UNIFIED AUTHENTICATION CARD */
        <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-stone-200 overflow-hidden text-[#0D192B] animate-fadeIn">
          {/* Card Header with Official Logo */}
          <div className="bg-[#0B1B3D] px-8 pt-8 pb-6 text-center border-b border-[#C5A059]/30">
            <div className="flex justify-center mb-4">
              <img
                src={BRAND_ASSETS.logo}
                alt="Litchfield Heritage Trust Logo"
                className="h-14 w-auto object-contain bg-white/10 p-1.5 rounded border border-[#C5A059]/20"
              />
            </div>
            <h2 className="text-xl sm:text-2xl font-serif text-white tracking-tight">
              {stage === 'code' ? 'Verify Your Access' : 'Welcome to Litchfield Heritage Trust'}
            </h2>
            <p className="text-xs text-stone-300 font-light mt-1">
              {stage === 'code'
                ? 'Please enter your access code to continue.'
                : 'Private Wealth & Fiduciary Demonstration Access'}
            </p>
          </div>

          <div className="p-8 space-y-6">
            {/* Error Banner */}
            {error && (
              <div className="p-3.5 rounded bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2.5 animate-fadeIn">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{error}</span>
              </div>
            )}

            {/* STAGE ONE: EMAIL ENTRY */}
            {stage === 'email' && (
              <form onSubmit={handleEmailSubmit} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-700 tracking-wide uppercase">
                    Institutional Email Address
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. aurelianhouse777@gmail.com"
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none transition-colors"
                    />
                    <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                  </div>
                  <p className="text-[11px] text-stone-500 pt-1">
                    Authorized prototype account: <strong className="text-stone-700">aurelianhouse777@gmail.com</strong>
                  </p>
                </div>

                <div className="pt-2 space-y-3">
                  <button
                    type="submit"
                    disabled={loading || !email.trim()}
                    className="w-full py-3 px-4 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-[0.15em] rounded transition-all duration-200 shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <span>{loading ? 'Verifying...' : 'Continue'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={onCancel}
                    className="w-full py-2.5 px-4 text-stone-500 hover:text-stone-800 text-xs font-medium transition-colors cursor-pointer text-center"
                  >
                    Return to Public Website
                  </button>
                </div>

                <div className="pt-4 border-t border-stone-100 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setEmail('aurelianhouse777@gmail.com');
                      setError(null);
                    }}
                    className="text-[11px] text-[#B88D36] hover:underline cursor-pointer"
                  >
                    Forgot email assistance? Populate authorized prototype account
                  </button>
                </div>
              </form>
            )}

            {/* STAGE TWO: EMAIL CONFIRMATION */}
            {stage === 'confirmation' && (
              <div className="space-y-6">
                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded text-center space-y-2">
                  <CheckCircle2 className="w-6 h-6 text-[#B88D36] mx-auto" />
                  <h3 className="font-serif text-base font-semibold text-stone-800">
                    Check your email for the access code.
                  </h3>
                  <p className="text-xs text-stone-600 leading-relaxed">
                    For the prototype, this is clearly identified as a <strong>simulated notification</strong>.
                    No actual external mail delivery occurs in this demonstration environment.
                  </p>
                </div>

                <div className="p-4 bg-stone-50 rounded border border-stone-200 text-xs text-stone-600 space-y-2">
                  <div className="font-semibold text-stone-800 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#B88D36]" />
                    <span>Prototype Credential Notice:</span>
                  </div>
                  <p>
                    Your designated prototype access credentials have been registered for{' '}
                    <span className="font-mono text-stone-800 font-medium">{email}</span>.
                  </p>
                  <p className="text-[11px] text-stone-500 italic">
                    (Prototype verification codes: <span className="font-mono font-medium">777000</span> for Administrator Mode, or{' '}
                    <span className="font-mono font-medium">EBSN98765</span> for Visitor Mode).
                  </p>
                </div>

                <div className="space-y-3">
                  <button
                    type="button"
                    onClick={handleConfirmationContinue}
                    className="w-full py-3 px-4 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-[0.15em] rounded transition-all duration-200 shadow-md cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>Continue</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setStage('email')}
                    className="w-full py-2 text-stone-500 hover:text-stone-800 text-xs font-medium cursor-pointer"
                  >
                    Back to Email Entry
                  </button>
                </div>
              </div>
            )}

            {/* STAGE THREE: ACCESS VERIFICATION (NO ROLE NAMES DISCLOSED) */}
            {stage === 'code' && (
              <form onSubmit={handleCodeSubmit} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-700 tracking-wide uppercase">
                    Access Code
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      autoFocus
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder="Enter designated access code"
                      className="w-full pl-10 pr-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none transition-colors font-mono tracking-widest uppercase"
                    />
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                  </div>
                  <p className="text-[11px] text-stone-500">
                    Enter the access code associated with your account authorization.
                  </p>
                </div>

                <div className="pt-2 space-y-3">
                  <button
                    type="submit"
                    disabled={loading || !code.trim()}
                    className="w-full py-3 px-4 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-[0.15em] rounded transition-all duration-200 shadow-md cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <span>{loading ? 'Verifying Code...' : 'Continue'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setStage('email');
                      setError(null);
                    }}
                    className="w-full py-2.5 px-4 text-stone-500 hover:text-stone-800 text-xs font-medium transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
