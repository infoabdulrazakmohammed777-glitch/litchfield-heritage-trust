import React, { useState, useMemo } from 'react';
import { BRAND_ASSETS } from '../assets';
import {
  Landmark,
  ShieldCheck,
  TrendingUp,
  ArrowRight,
  ArrowUpRight,
  ChevronRight,
  ChevronDown,
  Download,
  Search,
  RefreshCw,
  Radio,
  Lock,
  User,
  ExternalLink,
  House,
  ArrowRightLeft,
  CircleCheck,
  KeyRound,
  FileText,
  Sliders,
  X,
  Sparkles,
  Building
} from 'lucide-react';

interface PublicWebsiteProps {
  onOpenSignIn: () => void;
  onNavigateSection?: (sectionId: string) => void;
}

// Full Historical Settlements Dataset (2019 - 2026)
interface SettlementRecord {
  id: string;
  year: number;
  date: string;
  reference: string;
  title: string;
  category: string;
  hub: string;
  rail: string;
  amountFormatted: string;
  currency: string;
  status: 'Settled & Cleared' | 'Audit Verified' | 'Vault Escrow Cleared';
  statusColor: 'emerald' | 'blue' | 'amber';
  hash: string;
  clearingBank: string;
  signatories: string[];
}

const SETTLEMENT_RECORDS: SettlementRecord[] = [
  {
    id: 'st-01',
    year: 2026,
    date: '2026-10-24',
    reference: 'FW-2026-9920141',
    title: 'Sovereign Green Infrastructure Syndication',
    category: 'Infrastructure',
    hub: 'United States · New York Hub',
    rail: 'Fedwire Funds',
    amountFormatted: '$125,000,000.00',
    currency: 'USD',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x8f2b7a91c0e4d6f83b1299c5e1d4f7289b43aa10d',
    clearingBank: 'Federal Reserve Bank of New York (FRBNY)',
    signatories: ['Fiduciary Desk NYC', 'Syndicate Trustee London']
  },
  {
    id: 'st-02',
    year: 2026,
    date: '2026-10-18',
    reference: 'T2-2026-4410982',
    title: 'European Private Equity Secondary Mandate',
    category: 'Private Equity',
    hub: 'Luxembourg · Frankfurt Rail',
    rail: 'TARGET2 Instant',
    amountFormatted: '€84,500,000.00',
    currency: 'EUR',
    status: 'Audit Verified',
    statusColor: 'blue',
    hash: '0x3c99021aef45b88190d7f21e89b4412c98d63a021',
    clearingBank: 'Deutsche Bundesbank Clearing Depository',
    signatories: ['Frankfurt Institutional Treasury', 'Luxembourg Custodial SA']
  },
  {
    id: 'st-03',
    year: 2026,
    date: '2026-10-02',
    reference: 'RP-2026-8812490',
    title: 'Federal Reserve Primary Dealer Overnight Repo Sweep',
    category: 'Fedwire Repo',
    hub: 'United States · Federal Reserve Board',
    rail: 'Direct Treasury Repo',
    amountFormatted: '$95,000,000.00',
    currency: 'USD',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x71e88290fae412c98b6720d189ca445e9981290bb',
    clearingBank: 'The Depository Trust & Clearing Corporation (DTCC)',
    signatories: ['Tri-Party Fiduciary Agent', 'Desk Supervisor NYC']
  },
  {
    id: 'st-04',
    year: 2026,
    date: '2026-09-14',
    reference: 'CH-2026-1029481',
    title: 'London Prime Commercial Real Estate Refinancing',
    category: 'Commercial Real Estate',
    hub: 'United Kingdom · City of London',
    rail: 'CHAPS London',
    amountFormatted: '£62,000,000.00',
    currency: 'GBP',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x4981d09eaf223910c8b740e11899a7210db4431ae',
    clearingBank: 'Bank of England RTGS',
    signatories: ['City of London Fiduciary Trustee', 'Lead Fiduciary Solicitor']
  },
  {
    id: 'st-05',
    year: 2026,
    date: '2026-08-29',
    reference: 'SIC-2026-3829104',
    title: 'Allocated Sovereign Physical Bullion Custody Transfer',
    category: 'Bullion Custody',
    hub: 'Switzerland · Zurich Free-Zone',
    rail: 'Swiss SIC',
    amountFormatted: 'CHF 48,200,000.00',
    currency: 'CHF',
    status: 'Vault Escrow Cleared',
    statusColor: 'amber',
    hash: '0x992b84e11a0c84f90d1829bb4810e4892c99318fa',
    clearingBank: 'SIX Interbank Clearing Zurich',
    signatories: ['Swiss Gold Archival Fiduciary', 'Custodial Inspector']
  },
  // Historical Records (2025 - 2019)
  {
    id: 'st-06',
    year: 2025,
    date: '2025-11-12',
    reference: 'FW-2025-7719201',
    title: 'Sovereign Debt Tranche Redemption - Series 25-A',
    category: 'Sovereign Debt',
    hub: 'United States · New York Hub',
    rail: 'Fedwire Funds',
    amountFormatted: '$110,000,000.00',
    currency: 'USD',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x12a9e884b02948c9918293e00184b8109d77412e',
    clearingBank: 'Federal Reserve Bank of New York',
    signatories: ['Treasury Desk NYC', 'Sovereign Agent']
  },
  {
    id: 'st-07',
    year: 2024,
    date: '2024-06-19',
    reference: 'T2-2024-5510291',
    title: 'Trans-European Energy Grid Infrastructure Bond',
    category: 'Infrastructure',
    hub: 'France · Paris Hub',
    rail: 'TARGET2 Instant',
    amountFormatted: '€72,000,000.00',
    currency: 'EUR',
    status: 'Audit Verified',
    statusColor: 'blue',
    hash: '0x904b8219c0e447a118928374d991b82093e8471a',
    clearingBank: 'Banque de France Clearing Depository',
    signatories: ['European Energy Trust', 'Paris Fiduciary Board']
  },
  {
    id: 'st-08',
    year: 2023,
    date: '2023-09-08',
    reference: 'SIC-2023-2201948',
    title: 'Geneva Private Family Trust Multi-Currency Liquidity',
    category: 'Family Office',
    hub: 'Switzerland · Geneva Division',
    rail: 'Swiss SIC',
    amountFormatted: 'CHF 55,000,000.00',
    currency: 'CHF',
    status: 'Vault Escrow Cleared',
    statusColor: 'amber',
    hash: '0x772b9419c8e104b9018274d9910c847291a0034e',
    clearingBank: 'Swiss National Bank (SNB)',
    signatories: ['Geneva Trust Protector', 'Senior Fiduciary Director']
  },
  {
    id: 'st-09',
    year: 2022,
    date: '2022-04-14',
    reference: 'FW-2022-3891029',
    title: 'Institutional US Treasury Inflation-Protected Securities (TIPS)',
    category: 'Treasury Yield',
    hub: 'United States · New York Hub',
    rail: 'Fedwire Funds',
    amountFormatted: '$85,000,000.00',
    currency: 'USD',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x4481c0029b8192847a001928374b881920d88192',
    clearingBank: 'Federal Reserve Bank of New York',
    signatories: ['TIPS Portfolio Syndicate', 'Treasury Risk Desk']
  },
  {
    id: 'st-10',
    year: 2021,
    date: '2021-12-03',
    reference: 'CH-2021-8849102',
    title: 'Heritage Maritime & Port Facility Financing Tranche',
    category: 'Commercial Debt',
    hub: 'United Kingdom · City of London',
    rail: 'CHAPS London',
    amountFormatted: '£50,000,000.00',
    currency: 'GBP',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x228b9910c847291a0034e772b9419c8e104b9018',
    clearingBank: 'Bank of England RTGS',
    signatories: ['Maritime Consortium Lead', 'Fiduciary Counsel']
  },
  {
    id: 'st-11',
    year: 2020,
    date: '2020-05-20',
    reference: 'FW-2020-1102948',
    title: 'Liquidity Preservation Syndicate Primary Injection',
    category: 'Capital Inflow',
    hub: 'United States · New York Hub',
    rail: 'Fedwire Funds',
    amountFormatted: '$140,000,000.00',
    currency: 'USD',
    status: 'Settled & Cleared',
    statusColor: 'emerald',
    hash: '0x661b092847a001928374b881920d881924481c00',
    clearingBank: 'Federal Reserve Bank of New York',
    signatories: ['Executive Fiduciary Directorate', 'Lead Reserve Agent']
  },
  {
    id: 'st-12',
    year: 2019,
    date: '2019-10-15',
    reference: 'T2-2019-0948192',
    title: 'Inaugural European Custodial Vault Reserve Settlement',
    category: 'Custodial Reserve',
    hub: 'Germany · Frankfurt Rail',
    rail: 'TARGET2 Instant',
    amountFormatted: '€60,000,000.00',
    currency: 'EUR',
    status: 'Audit Verified',
    statusColor: 'blue',
    hash: '0x551a0034e772b9419c8e104b9018228b9910c847',
    clearingBank: 'Deutsche Bundesbank',
    signatories: ['Frankfurt Vault Custodian', 'Trustee General']
  }
];

export const PublicWebsite: React.FC<PublicWebsiteProps> = ({ onOpenSignIn }) => {
  // 1. Live Treasury Yield Estimator (Hero Section)
  const [heroDepositBalance, setHeroDepositBalance] = useState(250000);

  // 2. Precision Financial Modeling Calculator Tabs
  const [calculatorTab, setCalculatorTab] = useState<'treasury' | 'mortgage' | 'fx'>('treasury');

  // Calculator 1: Treasury Simulator
  const [treasuryPrincipal, setTreasuryPrincipal] = useState(100000);
  const [treasuryMonthly, setTreasuryMonthly] = useState(2500);
  const [treasuryYears, setTreasuryYears] = useState(5);

  // Calculator 2: Private Mortgage Estimator
  const [mortgagePropertyValue, setMortgagePropertyValue] = useState(3500000);
  const [mortgageDownPercent, setMortgageDownPercent] = useState(25);
  const [mortgageTermYears, setMortgageTermYears] = useState(30);

  // Calculator 3: Wholesale FX Converter
  const [fxAmount, setFxAmount] = useState('100000');
  const [fxFrom, setFxFrom] = useState('USD');
  const [fxTo, setFxTo] = useState('EUR');

  // 3. Macro Surveillance Feed & Filters
  const [selectedInsightCategory, setSelectedInsightCategory] = useState('All');
  const [insightSearch, setInsightSearch] = useState('');
  const [expandedInsight, setExpandedInsight] = useState<string | null>(null);

  // 4. Settlement Ledger Filters & Inspection
  const [settlementYearFilter, setSettlementYearFilter] = useState<'top5' | 'all' | number>('top5');
  const [settlementSearch, setSettlementSearch] = useState('');
  const [inspectedSettlement, setInspectedSettlement] = useState<SettlementRecord | null>(null);

  // 5. Membership Application Modal
  const [membershipModalOpen, setMembershipModalOpen] = useState(false);
  const [memberFullName, setMemberFullName] = useState('');
  const [memberEmail, setMemberEmail] = useState('');
  const [memberEntityType, setMemberEntityType] = useState('Private Principal / Family Office');
  const [memberLiquidity, setMemberLiquidity] = useState('$1,000,000 - $5,000,000');
  const [membershipSubmitted, setMembershipSubmitted] = useState(false);

  // Card Controls Preview Modal
  const [cardControlsOpen, setCardControlsOpen] = useState(false);

  // Treasury Yield Math for Hero
  const heroAnnualYield = Math.round(heroDepositBalance * 0.0525);
  const heroMonthlyYield = Math.round(heroAnnualYield / 12);
  const heroBankAdvantage = Math.round(heroDepositBalance * (0.0525 - 0.0045));

  // Comprehensive Compound Interest Math for Calculator Tab 1
  const { projectedValue, totalContributed, interestEarned, legacyInterest, wealthAdvantage } = useMemo(() => {
    const P = treasuryPrincipal;
    const PMT = treasuryMonthly;
    const r = 0.0525;
    const n = 12;
    const t = treasuryYears;
    const legacyRate = 0.0045;

    // Compound Interest with Regular Monthly Additions
    const compoundP = P * Math.pow(1 + r / n, n * t);
    const compoundPMT = PMT * ((Math.pow(1 + r / n, n * t) - 1) / (r / n));
    const total = Math.round(compoundP + compoundPMT);

    const legacyP = P * Math.pow(1 + legacyRate / n, n * t);
    const legacyPMT = PMT * ((Math.pow(1 + legacyRate / n, n * t) - 1) / (legacyRate / n));
    const legacyTotal = Math.round(legacyP + legacyPMT);

    const contributed = P + PMT * 12 * t;
    const earned = total - contributed;
    const legEarned = legacyTotal - contributed;
    const advantage = total - legacyTotal;

    return {
      projectedValue: total,
      totalContributed: contributed,
      interestEarned: earned,
      legacyInterest: legEarned,
      wealthAdvantage: advantage
    };
  }, [treasuryPrincipal, treasuryMonthly, treasuryYears]);

  // Mortgage Calculator Math
  const { loanAmount, monthlyMortgagePayment, ltvRatio } = useMemo(() => {
    const downAmount = mortgagePropertyValue * (mortgageDownPercent / 100);
    const loan = mortgagePropertyValue - downAmount;
    const annualRate = 0.0575; // 5.75% private jumbo mortgage
    const monthlyRate = annualRate / 12;
    const totalMonths = mortgageTermYears * 12;
    const payment = Math.round(
      (loan * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths))) /
        (Math.pow(1 + monthlyRate, totalMonths) - 1)
    );
    const ltv = 100 - mortgageDownPercent;
    return {
      loanAmount: loan,
      monthlyMortgagePayment: payment,
      ltvRatio: ltv
    };
  }, [mortgagePropertyValue, mortgageDownPercent, mortgageTermYears]);

  // FX Conversion Rates (Mock Wholesale Mid-Market)
  const fxRates: Record<string, number> = {
    USD: 1.0,
    EUR: 0.9238,
    GBP: 0.7714,
    CHF: 0.8672,
    AED: 3.6725,
    SAR: 3.7510,
    SGD: 1.3210,
    JPY: 152.45
  };

  const convertedFx = useMemo(() => {
    const amt = parseFloat(fxAmount) || 0;
    const inUsd = amt / (fxRates[fxFrom] || 1.0);
    const out = inUsd * (fxRates[fxTo] || 1.0);
    return out.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }, [fxAmount, fxFrom, fxTo]);

  // Market Insights Dataset
  const insightsData = [
    {
      id: 'ins-1',
      category: 'Central Banks & Rates',
      source: 'Financial Times Capital Markets',
      time: '14m ago',
      metric: '$240B RRP Level',
      title: 'Federal Reserve Rebalances Reverse Repo Facility Amid Heightened Treasury Bill Issuance',
      summary:
        'The Federal Reserve overnight reverse repo program (RRP) saw aggregate balances normalize to $240B as money-market funds reallocated liquidity directly into front-end Treasury bills yielding above 4.85%.',
      impact: 'Liquidity Expansion in Front-End Sovereign Debt',
      impactColor: 'text-emerald-400',
      deepAnalysis:
        'The normalization of the RRP facility signals robust organic absorption of short-term government debt without draining private bank reserves. Litchfield Heritage Trust clients positioned in our 5.25% automated overnight treasury sweep benefit directly from sustained elevated repo collateral yields.'
    },
    {
      id: 'ins-2',
      category: 'Sovereign Debt & T-Bills',
      source: 'Bloomberg Terminal Macro Desk',
      time: '28m ago',
      metric: '$125B Total Offering',
      title: 'US Treasury Announces $125 Billion Quarterly Refunding with Stable Long-Bond Auction Sizes',
      summary:
        'The Office of Debt Management confirmed coupon issuance will remain unchanged across 10-year notes and 30-year bonds for the upcoming quarter, alleviating market concerns over long-end supply saturation.',
      impact: 'Bullish Yield Curve Flattening',
      impactColor: 'text-emerald-400',
      deepAnalysis:
        'By capping longer-maturity supply and continuing to fund via front-end short-duration bills, debt managers ensure that yield curve inversions remain favorable for short-duration cash management strategies.'
    },
    {
      id: 'ins-3',
      category: 'Central Banks & Rates',
      source: 'Reuters Institutional',
      time: '45m ago',
      metric: '3.25% Deposit Rate Target',
      title: 'European Central Bank Signals Measured 25 bps Easing Pace as Eurozone Wage Pressures Abate',
      summary:
        'Governing Council members reiterated that inflation across the Euro area is tracking steadily toward the 2.0% target, reinforcing market expectations for sequential quarter-point rate reductions heading into 2027.',
      impact: 'Moderate EUR Weakness vs USD',
      impactColor: 'text-amber-300',
      deepAnalysis:
        'Divergence between European Central Bank rate trajectory and resilient US interest margins reinforces the strategic value of Litchfield Heritage Trust multi-currency IBANs, allowing treasury clients to hold native balances in higher-yielding jurisdictions.'
    },
    {
      id: 'ins-4',
      category: 'Private Equity & M&A',
      source: 'Wall Street Journal Private Equity',
      time: '1h ago',
      metric: '$18.5B Direct Pipeline',
      title: 'Sovereign Wealth Funds Increase Direct Private Infrastructure & Data Center Co-Investments',
      summary:
        'Institutional allocators in Singapore and Abu Dhabi committed over $18.5B into high-density computing infrastructure and renewable transmission corridors, bypassing syndicated debt for direct bilateral lending.',
      impact: 'Private Credit Spread Compression',
      impactColor: 'text-emerald-400',
      deepAnalysis:
        'Direct co-investment structures allow family offices to participate alongside sovereign entities. Our wealth advisory team facilitates customized SPV trust custody for institutional mandates.'
    },
    {
      id: 'ins-5',
      category: 'Commodities & Energy',
      source: 'World Gold Council Institutional Report',
      time: '2h ago',
      metric: '380 Tons Quarterly Inflow',
      title: 'Global Central Banks Purchase Record 380 Metric Tons of Physical Gold in Portfolio Diversification',
      summary:
        'Emerging market reserve managers and Swiss private banking institutions expanded physical bullion holdings to hedge against multi-jurisdictional currency sanctions and long-term fiscal expansion.',
      impact: 'Structural Support for Bullion Above $2,700',
      impactColor: 'text-emerald-400',
      deepAnalysis:
        'Physical bullion custody in Zurich bonded free-zones offers sovereign diversification. Litchfield Heritage Trust provides allocated, non-fungible depository accounts with physical inspection covenants.'
    },
    {
      id: 'ins-6',
      category: 'Currencies & FX',
      source: 'Nikkei Financial Markets',
      time: '3h ago',
      metric: '152.80 Resistance Level',
      title: 'Bank of Japan Reaffirms Gradual Neutral-Rate Path Amid Japanese Yen Carry Trade Unwinding',
      summary:
        'Governor Ueda indicated monetary authorities remain prepared to adjust policy accommodation if core services inflation holds above 2.2%, providing two-way volatility across G10 foreign exchange crosses.',
      impact: 'Heightened FX Volatility in JPY Crosses',
      impactColor: 'text-amber-300',
      deepAnalysis:
        'Two-way currency volatility underscores the advantage of Litchfield Heritage zero-spread wholesale FX conversion rails, mitigating cross-border execution slippage for international trade and family offices.'
    }
  ];

  const filteredInsights = useMemo(() => {
    return insightsData.filter((item) => {
      const matchesCategory =
        selectedInsightCategory === 'All' || item.category === selectedInsightCategory;
      const matchesSearch =
        !insightSearch ||
        item.title.toLowerCase().includes(insightSearch.toLowerCase()) ||
        item.summary.toLowerCase().includes(insightSearch.toLowerCase()) ||
        item.category.toLowerCase().includes(insightSearch.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedInsightCategory, insightSearch]);

  // Settlement Ledger Filtering
  const filteredSettlements = useMemo(() => {
    let list = [...SETTLEMENT_RECORDS];

    if (settlementYearFilter === 'top5') {
      list = list.slice(0, 5);
    } else if (typeof settlementYearFilter === 'number') {
      list = list.filter((item) => item.year === settlementYearFilter);
    }

    if (settlementSearch.trim()) {
      const q = settlementSearch.toLowerCase();
      list = list.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.reference.toLowerCase().includes(q) ||
          item.rail.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q)
      );
    }

    return list;
  }, [settlementYearFilter, settlementSearch]);

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Year',
      'Date',
      'Reference ID',
      'Institutional Movement',
      'Category',
      'Hub',
      'Settlement Rail',
      'Amount',
      'Currency',
      'Status',
      'Cryptographic Hash',
      'Clearing Bank'
    ];
    const rows = SETTLEMENT_RECORDS.map((s) => [
      s.year,
      s.date,
      s.reference,
      `"${s.title.replace(/"/g, '""')}"`,
      s.category,
      `"${s.hub.replace(/"/g, '""')}"`,
      s.rail,
      `"${s.amountFormatted}"`,
      s.currency,
      s.status,
      s.hash,
      `"${s.clearingBank}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `LHT_Sovereign_Settlements_2019_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleMembershipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setMembershipSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-400/20 selection:text-amber-200">
      {/* TOP HEADER */}
      <header className="sticky top-0 z-40 w-full border-b border-white/[0.08] bg-neutral-950/85 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
          <a href="#top" className="flex items-center gap-3.5 whitespace-nowrap shrink-0 group">
            <div className="h-11 px-2.5 py-1 bg-white rounded-lg flex items-center justify-center shadow-md">
              <img
                alt="Litchfield Heritage Trust"
                className="h-9 w-auto object-contain"
                src={BRAND_ASSETS.logo}
              />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-white group-hover:text-amber-300 transition-colors">
                Litchfield Heritage Trust
              </span>
              <span className="text-[10px] tracking-widest text-amber-300/90 uppercase -mt-0.5 font-mono">
                Your Trust. Our Heritage.
              </span>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-neutral-300">
            <a href="#treasury" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Accounts &amp; Treasury
            </a>
            <a href="#settlements" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Settlement Ledger
            </a>
            <a href="#cards" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Titanium Card
            </a>
            <a href="#insights" className="text-amber-300 hover:text-amber-200 transition-colors whitespace-nowrap shrink-0">
              Market Insights
            </a>
            <a href="#calculators" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Yield &amp; Rates
            </a>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => {
                setMembershipSubmitted(false);
                setMembershipModalOpen(true);
              }}
              className="hidden sm:inline-flex px-4 py-2 text-xs font-semibold text-neutral-300 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Apply for Membership
            </button>
            <button
              onClick={onOpenSignIn}
              className="px-4 py-2 text-xs font-semibold text-neutral-950 bg-gradient-to-r from-amber-200 via-amber-300 to-amber-400 hover:from-amber-100 hover:to-amber-300 rounded-lg shadow-sm transition-all flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer active:scale-[0.98]"
            >
              <User className="w-3.5 h-3.5 text-neutral-950" />
              <span>Client Online Banking</span>
              <ArrowRight className="w-3.5 h-3.5 text-neutral-950" />
            </button>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1">
        {/* HERO SECTION */}
        <section id="top" className="relative pt-8 pb-20 overflow-hidden border-b border-white/[0.08]">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-amber-500/10 blur-[130px] pointer-events-none rounded-full" />
          <div className="absolute top-10 right-10 w-[450px] h-[300px] bg-blue-600/5 blur-[120px] pointer-events-none rounded-full" />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="flex items-center gap-2 text-xs font-medium text-amber-300/90 tracking-wider uppercase font-mono mb-4">
              <span>Private Banking &amp; Treasury</span>
              <span aria-hidden="true" className="text-neutral-600">/</span>
              <span>Member Federal Reserve System</span>
              <span aria-hidden="true" className="text-neutral-600">/</span>
              <span>FDIC Sweep Network to $5,000,000</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <div className="lg:col-span-7 flex flex-col items-start">
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.08] text-balance">
                  Institutional-grade banking engineered for modern capital.
                </h1>
                <p className="mt-6 text-lg sm:text-xl text-neutral-300 font-normal leading-relaxed max-w-2xl">
                  Automated high-yield treasury sweeps yielding 5.25% APY, multi-currency IBANs across 38 global
                  financial centers, and sovereign-grade custody protected by extended FDIC insurance.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-4">
                  <button
                    onClick={onOpenSignIn}
                    className="px-6 py-3.5 text-sm font-semibold text-neutral-950 bg-amber-300 hover:bg-amber-200 transition-all rounded-lg shadow-lg shadow-amber-950/30 flex items-center gap-2.5 active:scale-[0.98] cursor-pointer"
                  >
                    <span>Launch Client Banking Demo</span>
                    <ArrowRight className="w-4 h-4 text-neutral-950" />
                  </button>
                  <button
                    onClick={() => {
                      setMembershipSubmitted(false);
                      setMembershipModalOpen(true);
                    }}
                    className="px-6 py-3.5 text-sm font-semibold text-white bg-neutral-900 hover:bg-neutral-800 border border-white/[0.12] transition-colors rounded-lg flex items-center gap-2 cursor-pointer"
                  >
                    <span>Apply for Private Membership</span>
                  </button>
                </div>

                <div className="mt-12 pt-8 border-t border-white/[0.08] grid grid-cols-3 gap-6 w-full max-w-xl">
                  <div>
                    <p className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums">5.25%</p>
                    <p className="text-xs text-neutral-400 mt-1">High-Yield Treasury APY</p>
                  </div>
                  <div>
                    <p className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums">$5.0M</p>
                    <p className="text-xs text-neutral-400 mt-1">FDIC Sweep Protection</p>
                  </div>
                  <div>
                    <p className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums">38</p>
                    <p className="text-xs text-neutral-400 mt-1">Direct Settlement Currencies</p>
                  </div>
                </div>
              </div>

              {/* Right Column: Visual and Live Treasury Yield Estimator */}
              <div className="lg:col-span-5 flex flex-col gap-5">
                <div className="relative rounded-2xl overflow-hidden border border-white/[0.12] shadow-2xl bg-neutral-900 group">
                  <img
                    alt="Litchfield Heritage Trust Manhattan Private Banking Grand Atrium"
                    className="w-full h-56 object-cover object-center filter brightness-[0.9] group-hover:scale-102 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                    src={BRAND_ASSETS.hero}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs text-neutral-200">
                    <span className="font-medium">Litchfield Heritage Trust Banking Atrium</span>
                    <span className="font-mono text-neutral-400">Geneva · London · New York</span>
                  </div>
                </div>

                {/* Interactive Live Treasury Yield Estimator */}
                <div className="p-6 rounded-2xl bg-neutral-900/90 border border-white/[0.1] backdrop-blur-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-semibold text-white">Live Treasury Yield Estimator</h3>
                      <p className="text-xs text-neutral-400 mt-0.5">Based on overnight US T-Bills repo &amp; federal funds</p>
                    </div>
                    <span className="text-xs font-mono font-bold text-amber-300 bg-amber-400/10 px-2.5 py-1 rounded">
                      5.25% APY
                    </span>
                  </div>

                  <div className="mt-5">
                    <div className="flex justify-between items-center text-xs mb-2">
                      <span className="text-neutral-400">Simulate Deposit Balance</span>
                      <span className="text-white font-mono font-bold text-sm tabular-nums">
                        ${heroDepositBalance.toLocaleString()}
                      </span>
                    </div>
                    <input
                      min="25000"
                      max="2000000"
                      step="25000"
                      className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                      type="range"
                      value={heroDepositBalance}
                      onChange={(e) => setHeroDepositBalance(parseInt(e.target.value, 10))}
                    />
                    <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                      <span>$25,000</span>
                      <span>$1,000,000</span>
                      <span>$2,000,000+</span>
                    </div>
                  </div>

                  <div className="mt-5 p-4 rounded-xl bg-neutral-950/80 border border-white/[0.06] grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-[11px] text-neutral-400 block">Annual Projected Yield</span>
                      <span className="text-lg font-bold font-mono text-amber-300 tabular-nums">
                        +${heroAnnualYield.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-neutral-500 block font-mono mt-0.5">
                        ${heroMonthlyYield.toLocaleString()} / mo
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] text-neutral-400 block">Advantage vs Big Banks</span>
                      <span className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
                        +${heroBankAdvantage.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-neutral-500 block font-mono mt-0.5">
                        vs 0.45% avg legacy savings
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={onOpenSignIn}
                    className="mt-4 w-full py-2.5 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-800 hover:bg-neutral-700/80 border border-white/[0.08] rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>Test Live Transfers in Client Demo</span>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-300" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 01. CORE FINANCIAL ARCHITECTURE */}
        <section id="treasury" className="py-24 border-b border-white/[0.08] relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-mono uppercase tracking-widest text-amber-300">01. Core Financial Architecture</p>
              <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-white tracking-tight text-balance">
                Complete capital sovereignty across accounts, cards, and cross-border rails.
              </h2>
              <p className="mt-4 text-base text-neutral-400 leading-relaxed">
                Eliminate traditional banking frictions. Access institutional liquidity, wholesale exchange rates, and
                private vault custody through unified digital architecture.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
              {/* Card 1: Treasury Sweeps */}
              <div className="lg:col-span-7 rounded-2xl bg-neutral-900 border border-white/[0.08] p-8 flex flex-col justify-between group hover:border-white/[0.15] transition-all">
                <div>
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-300">
                      <Landmark className="w-5 h-5" />
                    </div>
                    <span className="font-mono text-xs text-neutral-400 tracking-wider">TREASURY SWEEP</span>
                  </div>
                  <h3 className="mt-6 text-xl font-bold text-white">5.25% Net APY Overnight Treasury Sweeps</h3>
                  <p className="mt-3 text-sm text-neutral-300 leading-relaxed max-w-xl">
                    Cash balances beyond your configured operating threshold are automatically swept every evening into
                    short-duration US Treasury Bills and repurchase agreements. Earn maximum institutional yield with
                    same-day operating liquidity.
                  </p>
                </div>
                <div className="mt-8 pt-6 border-t border-white/[0.06] grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs text-neutral-400">Sweep Execution</p>
                    <p className="text-sm font-semibold text-white font-mono mt-1">Daily 17:00 EST</p>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-400">Asset Backing</p>
                    <p className="text-sm font-semibold text-white font-mono mt-1">Direct US Treasuries</p>
                  </div>
                  <div>
                    <p className="text-xs text-neutral-400">Liquidity Gate</p>
                    <p className="text-sm font-semibold text-amber-300 font-mono mt-1">T+0 Same-Day</p>
                  </div>
                </div>
              </div>

              {/* Card 2: Titanium Card */}
              <div
                className="lg:col-span-5 rounded-2xl bg-neutral-900 border border-white/[0.08] overflow-hidden flex flex-col group hover:border-white/[0.15] transition-all"
                id="cards"
              >
                <div className="relative h-48 sm:h-52 overflow-hidden bg-neutral-950">
                  <img
                    alt="Litchfield Heritage Trust Titanium Debit Card engraved in solid metal"
                    className="w-full h-full object-cover filter brightness-[0.95] group-hover:scale-103 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    src={BRAND_ASSETS.titaniumCard}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-transparent" />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-white">Titanium Private Debit &amp; Charge</h3>
                      <span className="font-mono text-xs text-amber-300">22.5g Precision Metal</span>
                    </div>
                    <p className="mt-2 text-xs text-neutral-300 leading-relaxed">
                      Forged in aerospace-grade brushed titanium. 2.5% unlimited cashback deposited directly to your
                      treasury vault, zero foreign transaction fees in 140+ countries, and concierge lounge access.
                    </p>
                  </div>
                  <div className="mt-4 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="text-neutral-400">Zero FX Markup Worldwide</span>
                    <button
                      onClick={() => setCardControlsOpen(true)}
                      className="text-amber-300 hover:text-amber-200 font-medium flex items-center gap-1 cursor-pointer"
                    >
                      <span>Inspect Card Controls</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Card 3: Multi-Currency Global IBANs */}
              <div className="lg:col-span-5 rounded-2xl bg-neutral-900 border border-white/[0.08] overflow-hidden flex flex-col group hover:border-white/[0.15] transition-all">
                <div className="relative h-48 sm:h-52 overflow-hidden bg-neutral-950">
                  <img
                    alt="Global Financial Districts skyline at twilight"
                    className="w-full h-full object-cover filter brightness-[0.9] group-hover:scale-103 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    src={BRAND_ASSETS.globalSkyline}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-transparent" />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-white">Multi-Currency Global IBANs</h3>
                      <span className="font-mono text-xs text-neutral-400">38 MARKETS</span>
                    </div>
                    <p className="mt-2 text-xs text-neutral-300 leading-relaxed">
                      Hold, receive, and disburse native balances in USD, EUR, GBP, CHF, SGD, and JPY. Direct rails through
                      FedNow, SEPA Instant, and CHAPS with zero intermediary correspondent hold times.
                    </p>
                  </div>
                  <div className="mt-4 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="text-neutral-400">Real-Time Mid-Market Settlement</span>
                    <span className="font-mono text-emerald-400">0.0% Hidden Spread</span>
                  </div>
                </div>
              </div>

              {/* Card 4: Wealth Advisory & Family Office */}
              <div
                className="lg:col-span-7 rounded-2xl bg-neutral-900 border border-white/[0.08] p-8 flex flex-col justify-between group hover:border-white/[0.15] transition-all"
                id="wealth"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                  <div>
                    <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-300">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <h3 className="mt-4 text-xl font-bold text-white">Private Wealth Advisory &amp; Family Office Mandates</h3>
                    <p className="mt-3 text-sm text-neutral-300 leading-relaxed">
                      Every client with deposits exceeding $1,000,000 is paired with a chartered Private Wealth Director.
                      We coordinate tax-optimized offshore structures, trusts, estate planning, and private venture allocations.
                    </p>
                    <div className="mt-6 flex items-center gap-3">
                      <button
                        onClick={() => {
                          setMembershipSubmitted(false);
                          setMembershipModalOpen(true);
                        }}
                        className="px-4 py-2 text-xs font-semibold text-neutral-900 bg-white hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
                      >
                        Request Advisory Briefing
                      </button>
                      <span className="text-xs text-neutral-400">Minimum Mandate $500k</span>
                    </div>
                  </div>
                  <div className="rounded-xl overflow-hidden border border-white/[0.1] shadow-lg">
                    <img
                      alt="Litchfield Heritage Trust Senior Wealth Advisory Partners in conference"
                      className="w-full h-48 object-cover filter brightness-[0.9]"
                      referrerPolicy="no-referrer"
                      src={BRAND_ASSETS.businessBanking}
                    />
                    <div className="p-3 bg-neutral-950/80 text-[11px] text-neutral-300 flex justify-between font-mono">
                      <span>Advisory Board Geneva &amp; NYC</span>
                      <span className="text-amber-300">Fiduciary Standard</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 02. PRECISION FINANCIAL MODELING */}
        <section id="calculators" className="py-24 border-b border-white/[0.08] relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-mono uppercase tracking-widest text-amber-300">02. Precision Financial Modeling</p>
              <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-white tracking-tight">
                Simulate your capital growth, loan terms, and global conversions.
              </h2>
              <p className="mt-4 text-base text-neutral-400 leading-relaxed">
                Transparent institutional parameters with zero hidden spreads. Test your portfolio potential with
                real-time computational models.
              </p>
            </div>

            {/* Calculator Tabs */}
            <div className="mt-10 flex items-center gap-1.5 p-1 bg-neutral-900 border border-white/[0.08] rounded-xl max-w-fit">
              <button
                onClick={() => setCalculatorTab('treasury')}
                className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
                  calculatorTab === 'treasury'
                    ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>5.25% Treasury Yield Simulator</span>
              </button>
              <button
                onClick={() => setCalculatorTab('mortgage')}
                className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
                  calculatorTab === 'mortgage'
                    ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <House className="w-3.5 h-3.5" />
                <span>Private Mortgage Estimator</span>
              </button>
              <button
                onClick={() => setCalculatorTab('fx')}
                className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-2 cursor-pointer ${
                  calculatorTab === 'fx'
                    ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <ArrowRightLeft className="w-3.5 h-3.5" />
                <span>Wholesale FX Converter</span>
              </button>
            </div>

            {/* Tab 1: Treasury Yield Simulator */}
            {calculatorTab === 'treasury' && (
              <div className="mt-8 rounded-2xl bg-neutral-900/90 border border-white/[0.08] p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center animate-fadeIn">
                <div className="lg:col-span-7 space-y-6">
                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-neutral-300">Initial Principal Deposit</span>
                      <span className="font-mono text-base font-bold text-white tabular-nums">
                        ${treasuryPrincipal.toLocaleString()}
                      </span>
                    </div>
                    <input
                      min="10000"
                      max="3000000"
                      step="10000"
                      className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-300"
                      type="range"
                      value={treasuryPrincipal}
                      onChange={(e) => setTreasuryPrincipal(parseInt(e.target.value, 10))}
                    />
                    <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                      <span>$10,000</span>
                      <span>$1,500,000</span>
                      <span>$3,000,000+</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-neutral-300">Monthly Contribution</span>
                      <span className="font-mono text-base font-bold text-white tabular-nums">
                        ${treasuryMonthly.toLocaleString()} / mo
                      </span>
                    </div>
                    <input
                      min="0"
                      max="50000"
                      step="500"
                      className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-300"
                      type="range"
                      value={treasuryMonthly}
                      onChange={(e) => setTreasuryMonthly(parseInt(e.target.value, 10))}
                    />
                    <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                      <span>$0</span>
                      <span>$25,000</span>
                      <span>$50,000</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-neutral-300">Investment Horizon</span>
                      <span className="font-mono text-base font-bold text-white tabular-nums">
                        {treasuryYears} {treasuryYears === 1 ? 'Year' : 'Years'}
                      </span>
                    </div>
                    <input
                      min="1"
                      max="20"
                      step="1"
                      className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-300"
                      type="range"
                      value={treasuryYears}
                      onChange={(e) => setTreasuryYears(parseInt(e.target.value, 10))}
                    />
                    <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                      <span>1 Year</span>
                      <span>10 Years</span>
                      <span>20 Years</span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs text-neutral-400">
                    <span>Direct Treasury APY: 5.25%</span>
                    <span className="font-mono">Compounded Monthly · T+0 Access</span>
                  </div>
                </div>

                <div className="lg:col-span-5 rounded-xl bg-neutral-950 p-6 border border-white/[0.08] flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-mono text-amber-300 uppercase tracking-wider block">
                      Projected Portfolio Value
                    </span>
                    <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white mt-2 block tabular-nums">
                      ${projectedValue.toLocaleString()}
                    </span>
                    <p className="text-xs text-neutral-400 mt-1">
                      After {treasuryYears} years of automated overnight treasury compound interest
                    </p>
                  </div>

                  <div className="mt-8 space-y-3 pt-6 border-t border-white/[0.08]">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Net Principal Contributed</span>
                      <span className="text-white font-mono tabular-nums">${totalContributed.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">LHT Interest Earned (5.25%)</span>
                      <span className="text-amber-300 font-bold font-mono tabular-nums">+${interestEarned.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Legacy Bank Interest (0.45%)</span>
                      <span className="text-neutral-500 font-mono tabular-nums">${legacyInterest.toLocaleString()}</span>
                    </div>
                    <div className="pt-3 border-t border-white/[0.06] flex justify-between items-center">
                      <span className="text-xs font-semibold text-emerald-400">Your Wealth Advantage</span>
                      <span className="text-base font-bold font-mono text-emerald-400 tabular-nums">
                        +${wealthAdvantage.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Private Mortgage Estimator */}
            {calculatorTab === 'mortgage' && (
              <div className="mt-8 rounded-2xl bg-neutral-900/90 border border-white/[0.08] p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center animate-fadeIn">
                <div className="lg:col-span-7 space-y-6">
                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-neutral-300">Property Valuation</span>
                      <span className="font-mono text-base font-bold text-white tabular-nums">
                        ${mortgagePropertyValue.toLocaleString()}
                      </span>
                    </div>
                    <input
                      min="1000000"
                      max="25000000"
                      step="250000"
                      className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-300"
                      type="range"
                      value={mortgagePropertyValue}
                      onChange={(e) => setMortgagePropertyValue(parseInt(e.target.value, 10))}
                    />
                    <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                      <span>$1,000,000</span>
                      <span>$12,500,000</span>
                      <span>$25,000,000+</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-neutral-300">Down Payment ({mortgageDownPercent}%)</span>
                      <span className="font-mono text-base font-bold text-white tabular-nums">
                        ${((mortgagePropertyValue * mortgageDownPercent) / 100).toLocaleString()}
                      </span>
                    </div>
                    <input
                      min="15"
                      max="60"
                      step="5"
                      className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-300"
                      type="range"
                      value={mortgageDownPercent}
                      onChange={(e) => setMortgageDownPercent(parseInt(e.target.value, 10))}
                    />
                    <div className="flex justify-between text-[11px] text-neutral-500 font-mono mt-1">
                      <span>15%</span>
                      <span>35%</span>
                      <span>60%</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-neutral-300">Loan Duration</span>
                      <span className="font-mono text-base font-bold text-white tabular-nums">
                        {mortgageTermYears} Years Fixed
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      {[15, 20, 30].map((term) => (
                        <button
                          key={term}
                          onClick={() => setMortgageTermYears(term)}
                          className={`flex-1 py-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                            mortgageTermYears === term
                              ? 'bg-amber-300 text-neutral-950 border-amber-300 font-bold'
                              : 'bg-neutral-800 text-neutral-300 border-white/[0.08] hover:text-white'
                          }`}
                        >
                          {term} Years
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs text-neutral-400">
                    <span>Private Jumbo Rate: 5.75% Fixed</span>
                    <span className="font-mono">Zero Points · No Prepayment Penalty</span>
                  </div>
                </div>

                <div className="lg:col-span-5 rounded-xl bg-neutral-950 p-6 border border-white/[0.08] flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-mono text-amber-300 uppercase tracking-wider block">
                      Estimated Monthly Payment
                    </span>
                    <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white mt-2 block tabular-nums">
                      ${monthlyMortgagePayment.toLocaleString()} / mo
                    </span>
                    <p className="text-xs text-neutral-400 mt-1">
                      Principal and interest for ${loanAmount.toLocaleString()} jumbo financing
                    </p>
                  </div>

                  <div className="mt-8 space-y-3 pt-6 border-t border-white/[0.08]">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Loan-To-Value (LTV)</span>
                      <span className="text-white font-mono tabular-nums">{ltvRatio}%</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Total Financed Amount</span>
                      <span className="text-white font-mono tabular-nums">${loanAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Dedicated Underwriting Desk</span>
                      <span className="text-emerald-400 font-medium">T+48h Expedited Approval</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Wholesale FX Converter */}
            {calculatorTab === 'fx' && (
              <div className="mt-8 rounded-2xl bg-neutral-900/90 border border-white/[0.08] p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center animate-fadeIn">
                <div className="lg:col-span-7 space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs text-neutral-300">Amount to Convert</label>
                      <input
                        type="number"
                        value={fxAmount}
                        onChange={(e) => setFxAmount(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-neutral-800 border border-white/[0.1] rounded-lg text-white font-mono text-sm focus:outline-none focus:border-amber-300"
                        placeholder="100000"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs text-neutral-300">From Currency</label>
                      <select
                        value={fxFrom}
                        onChange={(e) => setFxFrom(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-neutral-800 border border-white/[0.1] rounded-lg text-white font-mono text-sm focus:outline-none focus:border-amber-300 cursor-pointer"
                      >
                        {Object.keys(fxRates).map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs text-neutral-300">To Destination Currency</label>
                    <select
                      value={fxTo}
                      onChange={(e) => setFxTo(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-neutral-800 border border-white/[0.1] rounded-lg text-white font-mono text-sm focus:outline-none focus:border-amber-300 cursor-pointer"
                    >
                      {Object.keys(fxRates).map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs text-neutral-400">
                    <span>Institutional Execution Spread: 0.00%</span>
                    <span className="font-mono text-emerald-400">Pure Mid-Market Clearing</span>
                  </div>
                </div>

                <div className="lg:col-span-5 rounded-xl bg-neutral-950 p-6 border border-white/[0.08] flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-mono text-amber-300 uppercase tracking-wider block">
                      Guaranteed Wholesale Settlement
                    </span>
                    <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white mt-2 block tabular-nums">
                      {convertedFx} {fxTo}
                    </span>
                    <p className="text-xs text-neutral-400 mt-1">
                      Direct interbank clearing rate without retail bank markup
                    </p>
                  </div>

                  <div className="mt-8 space-y-3 pt-6 border-t border-white/[0.08]">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Retail Bank Hidden Fee Avoided</span>
                      <span className="text-emerald-400 font-bold font-mono tabular-nums">
                        ~${((parseFloat(fxAmount) || 0) * 0.025).toLocaleString()} USD saved
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-neutral-400">Settlement Rail</span>
                      <span className="text-white font-mono">SEPA / FedNow Instant</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* 03. SOVEREIGN CUSTODY & CRYPTOGRAPHIC SAFEGUARDS */}
        <section id="security" className="py-24 border-b border-white/[0.08] relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <p className="text-xs font-mono uppercase tracking-widest text-amber-300">
                03. Sovereign Custody &amp; Cryptographic Safeguards
              </p>
              <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-white tracking-tight text-balance">
                Fortress-grade architecture built to protect generational wealth.
              </h2>
              <p className="mt-4 text-base text-neutral-400 leading-relaxed">
                Your balances are held in direct sovereign debt and distributed across a network of tier-one FDIC
                chartered institutions.
              </p>
            </div>

            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Card 1 */}
              <div className="rounded-2xl bg-neutral-900 border border-white/[0.08] p-8 flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-300">
                    <Landmark className="w-5 h-5" />
                  </div>
                  <h3 className="mt-6 text-lg font-bold text-white">$5,000,000 FDIC Insured Sweep</h3>
                  <p className="mt-3 text-sm text-neutral-300 leading-relaxed">
                    Rather than capping insurance at standard $250k limits, our smart deposit sweep dynamically routes
                    client deposits across 20+ partner institutions, keeping up to $5,000,000 fully insured.
                  </p>
                </div>
                <div className="mt-8 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs text-neutral-400 font-mono">
                  <span>Automatic Daily Sweep</span>
                  <span className="text-amber-300">FDIC Protected</span>
                </div>
              </div>

              {/* Card 2 */}
              <div className="rounded-2xl bg-neutral-900 border border-white/[0.08] p-8 flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-blue-400/10 border border-blue-400/20 flex items-center justify-center text-blue-300">
                    <KeyRound className="w-5 h-5" />
                  </div>
                  <h3 className="mt-6 text-lg font-bold text-white">Multi-Signature Quorum Rules</h3>
                  <p className="mt-3 text-sm text-neutral-300 leading-relaxed">
                    Wire transfers exceeding custom thresholds require M-of-N dual cryptographic authorization via
                    FIDO2 hardware keys (YubiKey) or biometric executive sign-off before settlement.
                  </p>
                </div>
                <div className="mt-8 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs text-neutral-400 font-mono">
                  <span>FIPS 140-2 Level 3 HSM</span>
                  <span className="text-blue-300">Hardware Verified</span>
                </div>
              </div>

              {/* Card 3 */}
              <div className="rounded-2xl bg-neutral-900 border border-white/[0.08] p-8 flex flex-col justify-between">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center text-emerald-300">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <h3 className="mt-6 text-lg font-bold text-white">Tier-1 Capital Ratio 16.4%</h3>
                  <p className="mt-3 text-sm text-neutral-300 leading-relaxed">
                    Litchfield Heritage Trust maintains a CET1 capital adequacy ratio of 16.4%—more than double the
                    Basel III regulatory minimum of 8.0%. We hold zero speculative non-agency mortgage exposure.
                  </p>
                </div>
                <div className="mt-8 pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs text-neutral-400 font-mono">
                  <span>Independent Audit 2026</span>
                  <span className="text-emerald-300">PwC Verified</span>
                </div>
              </div>
            </div>

            {/* Certifications Ribbon */}
            <div className="mt-12 py-6 px-8 rounded-xl bg-neutral-900/60 border border-white/[0.06] flex flex-wrap items-center justify-between gap-6 text-xs text-neutral-400">
              <div className="flex items-center gap-2">
                <CircleCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>SOC 2 Type II Certified Data Infrastructure</span>
              </div>
              <div className="flex items-center gap-2">
                <CircleCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>ISO/IEC 27001 Information Security Standard</span>
              </div>
              <div className="flex items-center gap-2">
                <CircleCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>Zero-Liability Guarantee for Unauthorized Transactions</span>
              </div>
              <div className="flex items-center gap-2">
                <CircleCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>24/7 Sovereign Concierge Desk</span>
              </div>
            </div>
          </div>
        </section>

        {/* 04. MACRO SURVEILLANCE & INTELLIGENCE */}
        <section id="insights" className="py-24 border-b border-white/[0.08] relative bg-neutral-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div className="max-w-2xl">
                <p className="text-xs font-mono uppercase tracking-widest text-amber-300">
                  04. Macro Surveillance &amp; Intelligence
                </p>
                <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-white tracking-tight text-balance">
                  Global Market Insights &amp; Terminal Headlines
                </h2>
                <p className="mt-4 text-base text-neutral-400 leading-relaxed">
                  Real-time financial intelligence synthesized for institutional treasury managers, sovereign wealth
                  directors, and family offices.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 bg-neutral-900 border border-white/[0.08] px-3 py-2 rounded-lg">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span>Desk Feed: Live Synchronized</span>
                </div>
                <button
                  onClick={() => {
                    // Flash refresh
                    const el = document.getElementById('insights');
                    el?.classList.add('opacity-80');
                    setTimeout(() => el?.classList.remove('opacity-80'), 200);
                  }}
                  className="px-3.5 py-2 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-white/[0.1] rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                  title="Refresh intelligence wire"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh Wire</span>
                </button>
              </div>
            </div>

            {/* Live Market Terminal Ticker */}
            <div className="mt-10 p-3 rounded-xl bg-neutral-900/90 border border-white/[0.08] overflow-x-auto">
              <div className="flex items-center gap-6 text-xs whitespace-nowrap min-w-max px-2">
                <span className="font-mono text-[11px] text-amber-300 uppercase tracking-widest flex items-center gap-1.5 font-bold">
                  <Radio className="w-3 h-3 text-amber-300" />
                  <span>MARKET TERMINAL:</span>
                </span>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">US 10Y</span>
                  <span className="text-white font-bold tabular-nums">4.28%</span>
                  <span className="text-[11px] tabular-nums font-semibold text-emerald-400">+2.4 bps</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">DXY</span>
                  <span className="text-white font-bold tabular-nums">104.18</span>
                  <span className="text-[11px] tabular-nums font-semibold text-emerald-400">+0.22%</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">S&amp;P 500</span>
                  <span className="text-white font-bold tabular-nums">5,864.25</span>
                  <span className="text-[11px] tabular-nums font-semibold text-emerald-400">+0.38%</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">XAU/USD</span>
                  <span className="text-white font-bold tabular-nums">$2,748.50</span>
                  <span className="text-[11px] tabular-nums font-semibold text-emerald-400">+0.74%</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">BRENT</span>
                  <span className="text-white font-bold tabular-nums">$74.20/bbl</span>
                  <span className="text-[11px] tabular-nums font-semibold text-red-400">-0.85%</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">EUR/USD</span>
                  <span className="text-white font-bold tabular-nums">1.0824</span>
                  <span className="text-[11px] tabular-nums font-semibold text-red-400">-0.14%</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">SOFR</span>
                  <span className="text-white font-bold tabular-nums">4.82%</span>
                  <span className="text-[11px] tabular-nums font-semibold text-emerald-400">0.0 bps</span>
                  <span className="text-neutral-700">|</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-neutral-400 font-medium">UST 2Y/10Y</span>
                  <span className="text-white font-bold tabular-nums">+14.2 bps</span>
                  <span className="text-[11px] tabular-nums font-semibold text-emerald-400">+1.8 bps</span>
                </div>
              </div>
            </div>

            {/* Category Filter & Search Bar */}
            <div className="mt-8 flex flex-col lg:flex-row gap-4 items-center justify-between">
              <div className="flex items-center gap-1.5 p-1 bg-neutral-900 border border-white/[0.08] rounded-xl overflow-x-auto w-full lg:w-auto">
                {[
                  'All',
                  'Central Banks & Rates',
                  'Sovereign Debt & T-Bills',
                  'Currencies & FX',
                  'Private Equity & M&A',
                  'Commodities & Energy'
                ].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedInsightCategory(cat)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                      selectedInsightCategory === cat
                        ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {cat === 'All' ? 'All Intelligence' : cat}
                  </button>
                ))}
              </div>

              <div className="relative w-full lg:w-72">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  placeholder="Filter headlines, assets, sources..."
                  className="w-full pl-9 pr-4 py-2 bg-neutral-900 border border-white/[0.08] rounded-lg text-xs text-white focus:outline-none focus:border-amber-400/80"
                  type="text"
                  value={insightSearch}
                  onChange={(e) => setInsightSearch(e.target.value)}
                />
              </div>
            </div>

            {/* Headlines List */}
            <div className="mt-8 space-y-4">
              {filteredInsights.map((item) => {
                const isExpanded = expandedInsight === item.id;
                return (
                  <div
                    key={item.id}
                    className="rounded-2xl bg-neutral-900 border border-white/[0.08] p-6 hover:border-white/[0.15] transition-all"
                  >
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400 font-mono mb-2">
                          <span className="text-amber-300 font-semibold">{item.category}</span>
                          <span aria-hidden="true">·</span>
                          <span>{item.source}</span>
                          <span aria-hidden="true">·</span>
                          <span>{item.time}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-neutral-300">{item.metric}</span>
                        </div>
                        <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-snug">
                          {item.title}
                        </h3>
                        <p className="mt-3 text-sm text-neutral-300 leading-relaxed max-w-4xl">
                          {item.summary}
                        </p>

                        {/* Collapsible Deep Analysis */}
                        {isExpanded && (
                          <div className="mt-4 p-4 rounded-xl bg-neutral-950 border border-white/[0.08] text-xs text-neutral-300 space-y-2 animate-fadeIn">
                            <span className="font-mono text-amber-300 uppercase tracking-widest font-semibold block">
                              Institutional Desk Assessment:
                            </span>
                            <p className="leading-relaxed">{item.deepAnalysis}</p>
                          </div>
                        )}
                      </div>

                      <div className="flex md:flex-col items-center md:items-end justify-between md:justify-start gap-3 shrink-0">
                        <div className="text-right">
                          <span className="text-[10px] font-mono uppercase text-neutral-500 block">Institutional Impact</span>
                          <span className={`text-xs font-mono font-bold block mt-0.5 ${item.impactColor}`}>
                            {item.impact}
                          </span>
                        </div>
                        <button
                          onClick={() => setExpandedInsight(isExpanded ? null : item.id)}
                          className="px-3 py-1.5 rounded-lg bg-neutral-950 border border-white/[0.08] text-xs font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>{isExpanded ? 'Collapse' : 'Analysis'}</span>
                          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Attribution footer */}
            <div className="mt-8 pt-6 border-t border-white/[0.06] flex flex-wrap items-center gap-4 text-[11px] text-neutral-500 font-mono">
              <span>Primary Attribution Feeds:</span>
              <a href="https://www.bloomberg.com/" target="_blank" rel="noreferrer" className="hover:text-neutral-300 transition-colors flex items-center gap-1">
                <span>Bloomberg Financial Markets</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
              <a href="https://www.ft.com/" target="_blank" rel="noreferrer" className="hover:text-neutral-300 transition-colors flex items-center gap-1">
                <span>Financial Times Capital Markets</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
              <a href="https://www.reuters.com/" target="_blank" rel="noreferrer" className="hover:text-neutral-300 transition-colors flex items-center gap-1">
                <span>Reuters Institutional Macro</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
              <a href="https://www.newyorkfed.org/" target="_blank" rel="noreferrer" className="hover:text-neutral-300 transition-colors flex items-center gap-1">
                <span>Federal Reserve Bank of New York</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          </div>
        </section>

        {/* 05. SOVEREIGN SETTLEMENT HISTORY · 2019 TO 2026 */}
        <section id="settlements" className="py-24 border-b border-white/[0.08] relative bg-neutral-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div className="max-w-2xl">
                <p className="text-xs font-mono uppercase tracking-widest text-amber-300">
                  05. Sovereign Settlement History · 2019 to 2026
                </p>
                <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-white tracking-tight text-balance">
                  High-Value Institutional Movements &amp; Clearance Ledger
                </h2>
                <p className="mt-4 text-base text-neutral-400 leading-relaxed">
                  Transparent institutional audit trail recording multi-million dollar sovereign bond settlements,
                  syndicated facilities, and interbank repo sweeps across our global custody network.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={handleExportCSV}
                  className="px-3.5 py-2 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-white/[0.1] rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-amber-300" />
                  <span>Export Full Ledger (2019–2026 CSV)</span>
                </button>
              </div>
            </div>

            {/* Filter Buttons */}
            <div className="mt-10 flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
              <div className="flex items-center gap-1.5 p-1 bg-neutral-900 border border-white/[0.08] rounded-xl overflow-x-auto w-full lg:w-auto">
                <button
                  onClick={() => setSettlementYearFilter('top5')}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                    settlementYearFilter === 'top5'
                      ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Last 5 High-Value Movements
                </button>
                <button
                  onClick={() => setSettlementYearFilter('all')}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                    settlementYearFilter === 'all'
                      ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  All Years (2019–2026)
                </button>
                {[2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setSettlementYearFilter(yr)}
                    className={`px-3.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                      settlementYearFilter === yr
                        ? 'bg-amber-300 text-neutral-950 font-semibold shadow-sm'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {yr}
                  </button>
                ))}
              </div>

              <div className="relative w-full lg:w-72">
                <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  placeholder="Filter by entity, reference, rail..."
                  className="w-full pl-9 pr-4 py-2 bg-neutral-900 border border-white/[0.08] rounded-lg text-xs text-white focus:outline-none focus:border-amber-400/80"
                  type="text"
                  value={settlementSearch}
                  onChange={(e) => setSettlementSearch(e.target.value)}
                />
              </div>
            </div>

            {/* Meta indicator */}
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-neutral-400 font-mono">
              <div className="flex items-center gap-2">
                <span>Viewing:</span>
                <span className="text-amber-300 font-medium">
                  {settlementYearFilter === 'top5'
                    ? 'Last 5 High-Value Institutional Movements (2026)'
                    : settlementYearFilter === 'all'
                    ? 'All Historical Movements (2019–2026)'
                    : `Settlement Year ${settlementYearFilter}`}
                </span>
                <span>·</span>
                <span>{filteredSettlements.length} Records Cleared</span>
              </div>
              <div className="flex items-center gap-3 text-[11px]">
                <span>Clearing Standards:</span>
                <span className="text-neutral-300">ISO 20022 · Fedwire Funds · TARGET2 · CHAPS · Swiss SIC</span>
              </div>
            </div>

            {/* Table View */}
            <div className="mt-6 rounded-2xl bg-neutral-900 border border-white/[0.08] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-white/[0.08] text-neutral-400 font-mono bg-neutral-950/70">
                      <th className="py-3.5 px-4 whitespace-nowrap">Date &amp; Year</th>
                      <th className="py-3.5 px-4 whitespace-nowrap">Reference ID</th>
                      <th className="py-3.5 px-4">Institutional Movement / Syndicate</th>
                      <th className="py-3.5 px-4 whitespace-nowrap">Settlement Rail</th>
                      <th className="py-3.5 px-4 text-right whitespace-nowrap">Clearance Amount</th>
                      <th className="py-3.5 px-4 text-center whitespace-nowrap">Status</th>
                      <th className="py-3.5 px-4 text-right whitespace-nowrap">Audit Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.04]">
                    {filteredSettlements.map((tx) => (
                      <tr
                        key={tx.id}
                        className="hover:bg-neutral-800/50 transition-colors cursor-pointer group bg-neutral-900/80"
                      >
                        <td className="py-4 px-4 font-mono text-neutral-300 whitespace-nowrap">
                          <div>
                            <span className="text-white font-medium">{tx.date}</span>
                            <span className="text-neutral-500 block text-[11px] font-mono">Epoch {tx.year}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 font-mono text-amber-300/90 whitespace-nowrap">
                          {tx.reference}
                        </td>
                        <td className="py-4 px-4 max-w-sm">
                          <p className="font-semibold text-white group-hover:text-amber-300 transition-colors">
                            {tx.title}
                          </p>
                          <div className="flex items-center gap-2 text-[11px] text-neutral-400 font-mono mt-0.5">
                            <span>{tx.category}</span>
                            <span>·</span>
                            <span>{tx.hub}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 font-mono text-neutral-300 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Landmark className="w-3.5 h-3.5 text-neutral-500" />
                            <span>{tx.rail}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-right font-mono font-bold text-white text-sm tabular-nums whitespace-nowrap">
                          {tx.amountFormatted}
                        </td>
                        <td className="py-4 px-4 text-center whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono font-medium border whitespace-nowrap ${
                              tx.statusColor === 'emerald'
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                : tx.statusColor === 'blue'
                                ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                                : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                            }`}
                          >
                            <CircleCheck className="w-3.5 h-3.5 shrink-0" />
                            <span>{tx.status}</span>
                          </span>
                        </td>
                        <td className="py-4 px-4 text-right whitespace-nowrap">
                          <button
                            onClick={() => setInspectedSettlement(tx)}
                            className="px-2.5 py-1 rounded bg-neutral-950 border border-white/[0.08] text-[11px] font-mono text-neutral-300 hover:text-white hover:border-amber-300/40 transition-colors inline-flex items-center gap-1 cursor-pointer"
                          >
                            <span>Inspect</span>
                            <ChevronRight className="w-3 h-3 text-amber-300" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500 font-mono">
              <p>
                All movements cleared under direct Fedwire / TARGET2 irrevocable settlement protocols with zero
                counterparty settlement risk.
              </p>
              <div className="flex items-center gap-2 text-neutral-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Cryptographic Proof: 100% On-Record</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/[0.08] bg-neutral-950 pt-16 pb-12 text-neutral-400 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-10 pb-12 border-b border-white/[0.08]">
            {/* Col 1 & 2 */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center gap-3.5">
                <div className="h-12 px-3 py-1.5 bg-white rounded-lg flex items-center justify-center shadow-md">
                  <img
                    alt="Litchfield Heritage Trust"
                    className="h-9 w-auto object-contain"
                    src={BRAND_ASSETS.logo}
                  />
                </div>
                <div className="flex flex-col">
                  <span className="text-base font-bold tracking-tight text-white">Litchfield Heritage Trust</span>
                  <span className="text-[10px] tracking-widest text-amber-300/90 uppercase font-mono">
                    Your Trust. Our Heritage.
                  </span>
                </div>
              </div>
              <p className="text-neutral-400 text-xs leading-relaxed max-w-sm">
                Sovereign custody, automated high-yield treasury management, and global multi-currency settlements
                designed for principals, family offices, and high-growth technology enterprises.
              </p>
              <div className="text-[11px] font-mono text-neutral-500 space-y-1">
                <p>Primary Custody: 200 West Street, New York, NY</p>
                <p>European Division: Rue du Rhône 42, 1204 Genève</p>
              </div>
            </div>

            {/* Col 3: Accounts & Treasury */}
            <div>
              <h4 className="text-xs font-semibold text-white uppercase font-mono tracking-wider mb-3">
                Accounts &amp; Treasury
              </h4>
              <ul className="space-y-2">
                <li><a href="#treasury" className="hover:text-white transition-colors">Overnight Sweep (5.25% APY)</a></li>
                <li><a href="#treasury" className="hover:text-white transition-colors">Multi-Currency Global IBANs</a></li>
                <li><a href="#insights" className="text-amber-300/90 hover:text-white transition-colors">Market Surveillance Wire</a></li>
                <li><a href="#cards" className="hover:text-white transition-colors">Titanium Debit &amp; Obsidian Cards</a></li>
                <li><a href="#calculators" className="hover:text-white transition-colors">Yield Simulator</a></li>
                <li>
                  <button onClick={onOpenSignIn} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                    Client Online Banking
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 4: Private Wealth */}
            <div>
              <h4 className="text-xs font-semibold text-white uppercase font-mono tracking-wider mb-3">
                Private Wealth
              </h4>
              <ul className="space-y-2">
                <li><a href="#wealth" className="hover:text-white transition-colors">Discretionary Mandates</a></li>
                <li><a href="#wealth" className="hover:text-white transition-colors">Family Office Solutions</a></li>
                <li><a href="#wealth" className="hover:text-white transition-colors">Cross-Border Tax Advisory</a></li>
                <li><a href="#calculators" className="hover:text-white transition-colors">Private Jumbo Mortgages</a></li>
                <li>
                  <button
                    onClick={() => {
                      setMembershipSubmitted(false);
                      setMembershipModalOpen(true);
                    }}
                    className="hover:text-amber-300 transition-colors text-left cursor-pointer"
                  >
                    Membership Criteria
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 5: Security & Custody */}
            <div>
              <h4 className="text-xs font-semibold text-white uppercase font-mono tracking-wider mb-3">
                Security &amp; Custody
              </h4>
              <ul className="space-y-2">
                <li><a href="#security" className="hover:text-white transition-colors">$5M FDIC Sweep Network</a></li>
                <li><a href="#settlements" className="text-amber-300/90 hover:text-white transition-colors">Settlement Ledger (2019–2026)</a></li>
                <li><a href="#security" className="hover:text-white transition-colors">Multi-Sig Quorum Rules</a></li>
                <li><a href="#security" className="hover:text-white transition-colors">FIPS 140-2 Level 3 HSM</a></li>
                <li><a href="#security" className="hover:text-white transition-colors">Proof of Direct Reserves</a></li>
                <li><a href="#security" className="hover:text-white transition-colors">SOC-2 Type II Attestation</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 space-y-3 text-[11px] leading-relaxed text-neutral-500 font-mono">
            <p>
              Banking services provided by Litchfield Heritage Trust, Member FDIC. Deposit accounts held at Litchfield
              Heritage Trust are FDIC-insured up to $250,000 per depositor. Through the Litchfield Heritage Insured Deposit
              Sweep Program, eligible deposits in excess of $250,000 are placed into interest-bearing deposit accounts at
              a network of FDIC-insured depository institutions, providing up to $5,000,000 in aggregate FDIC insurance coverage.
            </p>
            <p>
              Treasury yields reflect the current 4-week US Treasury Bill rate net of program servicing fees as of November 2026
              and are subject to market conditions. Investment advisory services offered through Litchfield Heritage Capital Partners LLC,
              an SEC-registered investment adviser.
            </p>
            <div className="pt-4 flex flex-col sm:flex-row justify-between items-center gap-4 text-neutral-400">
              <p>© 2026 Litchfield Heritage Trust. All rights reserved. Your Trust. Our Heritage.</p>
              <div className="flex gap-6">
                <span className="hover:text-white transition-colors cursor-pointer">Privacy Policy</span>
                <span className="hover:text-white transition-colors cursor-pointer">Terms of Custody</span>
                <span className="hover:text-white transition-colors cursor-pointer">Regulatory Disclosures</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* INSPECT SETTLEMENT MODAL */}
      {inspectedSettlement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-neutral-900 border border-white/[0.12] rounded-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 text-white shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-300">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Cryptographic Clearance Certificate</h3>
                  <p className="text-xs text-neutral-400 font-mono">{inspectedSettlement.reference}</p>
                </div>
              </div>
              <button
                onClick={() => setInspectedSettlement(null)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono">
              <div className="p-4 bg-neutral-950 rounded-xl border border-white/[0.06] space-y-2">
                <div className="flex justify-between">
                  <span className="text-neutral-500">Institutional Movement:</span>
                  <span className="text-white font-sans font-semibold text-right">{inspectedSettlement.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Clearance Amount:</span>
                  <span className="text-amber-300 font-bold text-sm">{inspectedSettlement.amountFormatted}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Settlement Rail:</span>
                  <span className="text-white">{inspectedSettlement.rail}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Depository Hub:</span>
                  <span className="text-white">{inspectedSettlement.hub}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500">Clearing Agent:</span>
                  <span className="text-white">{inspectedSettlement.clearingBank}</span>
                </div>
              </div>

              <div className="p-3 bg-neutral-950 rounded-lg border border-white/[0.06] space-y-1">
                <span className="text-neutral-500 block text-[10px] uppercase">Cryptographic Ledger Hash:</span>
                <span className="text-emerald-400 break-all text-[11px] font-mono">{inspectedSettlement.hash}</span>
              </div>

              <div className="text-[11px] text-neutral-400 font-sans space-y-1">
                <span className="font-semibold text-neutral-300">Signatory Quorum:</span>
                <p>{inspectedSettlement.signatories.join(' · ')}</p>
              </div>
            </div>

            <div className="pt-4 border-t border-white/[0.08] flex justify-end">
              <button
                onClick={() => setInspectedSettlement(null)}
                className="px-5 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg"
              >
                Close Certificate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TITANIUM CARD CONTROLS MODAL */}
      {cardControlsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-neutral-900 border border-white/[0.12] rounded-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 text-white shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
              <h3 className="font-bold text-base text-white">Titanium Card Controls &amp; Limits</h3>
              <button
                onClick={() => setCardControlsOpen(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-xl overflow-hidden border border-white/[0.1] relative">
              <img
                src={BRAND_ASSETS.titaniumCard}
                alt="Titanium Card"
                className="w-full h-44 object-cover"
              />
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-neutral-950 rounded-lg flex justify-between items-center border border-white/[0.06]">
                <div>
                  <div className="font-semibold text-white">Daily POS Spending Limit</div>
                  <div className="text-neutral-500 text-[11px]">Uncapped high-net-worth authorization</div>
                </div>
                <span className="font-mono text-amber-300 font-bold">$250,000 / day</span>
              </div>

              <div className="p-3 bg-neutral-950 rounded-lg flex justify-between items-center border border-white/[0.06]">
                <div>
                  <div className="font-semibold text-white">Cashback Allocation</div>
                  <div className="text-neutral-500 text-[11px]">Auto-deposited to 5.25% treasury sweep</div>
                </div>
                <span className="font-mono text-emerald-400 font-bold">2.5% Unlimited</span>
              </div>

              <div className="p-3 bg-neutral-950 rounded-lg flex justify-between items-center border border-white/[0.06]">
                <div>
                  <div className="font-semibold text-white">Airport VIP Lounge Key</div>
                  <div className="text-neutral-500 text-[11px]">Priority Pass Select &amp; First Class Concierge</div>
                </div>
                <span className="font-mono text-white font-bold">Complimentary</span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setCardControlsOpen(false)}
                className="px-5 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MEMBERSHIP APPLICATION MODAL */}
      {membershipModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-neutral-900 border border-white/[0.12] rounded-2xl max-w-md w-full p-6 sm:p-8 space-y-6 text-white shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
              <div>
                <h3 className="font-bold text-lg text-white">Private Banking Membership</h3>
                <p className="text-xs text-neutral-400">Institutional Onboarding Consultation</p>
              </div>
              <button
                onClick={() => setMembershipModalOpen(false)}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {membershipSubmitted ? (
              <div className="text-center py-6 space-y-4">
                <CircleCheck className="w-12 h-12 text-amber-300 mx-auto" />
                <h4 className="text-lg font-bold text-white">Inquiry Received</h4>
                <p className="text-xs text-neutral-300 leading-relaxed max-w-sm mx-auto">
                  Thank you, <strong className="text-white">{memberFullName}</strong>. Your confidential inquiry has been
                  logged for our Geneva &amp; New York Fiduciary Admissions Committee. A Senior Wealth Director will reach
                  out to verify eligibility criteria.
                </p>
                <button
                  onClick={() => setMembershipModalOpen(false)}
                  className="px-6 py-2.5 bg-amber-300 text-neutral-950 font-bold text-xs rounded-lg uppercase tracking-wider"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleMembershipSubmit} className="space-y-4 text-xs">
                <div className="space-y-1">
                  <label className="text-neutral-300 uppercase font-semibold text-[11px]">Full Legal Name *</label>
                  <input
                    type="text"
                    required
                    value={memberFullName}
                    onChange={(e) => setMemberFullName(e.target.value)}
                    placeholder="e.g. Lord Alistair Vance"
                    className="w-full px-3 py-2 bg-neutral-800 border border-white/[0.1] rounded-lg text-white focus:outline-none focus:border-amber-300"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-neutral-300 uppercase font-semibold text-[11px]">Institutional Email *</label>
                  <input
                    type="email"
                    required
                    value={memberEmail}
                    onChange={(e) => setMemberEmail(e.target.value)}
                    placeholder="e.g. alistair@vance-holdings.com"
                    className="w-full px-3 py-2 bg-neutral-800 border border-white/[0.1] rounded-lg text-white focus:outline-none focus:border-amber-300"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-neutral-300 uppercase font-semibold text-[11px]">Entity Type *</label>
                  <select
                    value={memberEntityType}
                    onChange={(e) => setMemberEntityType(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-800 border border-white/[0.1] rounded-lg text-white focus:outline-none focus:border-amber-300 cursor-pointer"
                  >
                    <option value="Private Principal / Family Office">Private Principal / Family Office</option>
                    <option value="Sovereign / Fiduciary Trust">Sovereign / Fiduciary Trust</option>
                    <option value="Corporate Treasury Desk">Corporate Treasury Desk</option>
                    <option value="High-Growth Technology Enterprise">High-Growth Technology Enterprise</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-neutral-300 uppercase font-semibold text-[11px]">Target Discretionary Liquidity *</label>
                  <select
                    value={memberLiquidity}
                    onChange={(e) => setMemberLiquidity(e.target.value)}
                    className="w-full px-3 py-2 bg-neutral-800 border border-white/[0.1] rounded-lg text-white focus:outline-none focus:border-amber-300 cursor-pointer"
                  >
                    <option value="$500,000 - $1,000,000">$500,000 - $1,000,000</option>
                    <option value="$1,000,000 - $5,000,000">$1,000,000 - $5,000,000</option>
                    <option value="$5,000,000 - $25,000,000">$5,000,000 - $25,000,000</option>
                    <option value="$25,000,000+">$25,000,000+</option>
                  </select>
                </div>

                <div className="pt-3 border-t border-white/[0.08] flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setMembershipModalOpen(false)}
                    className="px-4 py-2 text-neutral-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-gradient-to-r from-amber-200 via-amber-300 to-amber-400 text-neutral-950 font-bold uppercase tracking-wider rounded-lg"
                  >
                    Submit Application
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
