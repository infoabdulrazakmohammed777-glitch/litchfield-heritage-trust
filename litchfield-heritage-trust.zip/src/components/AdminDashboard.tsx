import React, { useState, useEffect } from 'react';
import { BRAND_ASSETS } from '../assets';
import {
  LayoutDashboard,
  UserCheck,
  DollarSign,
  Receipt,
  ShieldAlert,
  Bell,
  Settings,
  LogOut,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  AlertCircle,
  Search,
  Filter,
  RefreshCw,
  Eye,
  Lock,
  ArrowUpRight,
  TrendingDown,
  Building,
  Menu,
  X
} from 'lucide-react';
import { api } from '../api';
import { AccountBalances, AccountProfile, AuditLogEntry, NotificationItem, TransactionRecord } from '../types';

interface AdminDashboardProps {
  onLogout: () => void;
}

type AdminTab =
  | 'overview'
  | 'profile'
  | 'balances'
  | 'transactions'
  | 'audit'
  | 'notifications'
  | 'settings';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Data states
  const [profile, setProfile] = useState<AccountProfile | null>(null);
  const [balances, setBalances] = useState<AccountBalances | null>(null);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [totalTransactions, setTotalTransactions] = useState(0);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Balance Form State
  const [newCurrentBalance, setNewCurrentBalance] = useState('');
  const [newLiquidity, setNewLiquidity] = useState('');
  const [balanceJustification, setBalanceJustification] = useState('');
  const [balanceModalOpen, setBalanceModalOpen] = useState(false);
  const [balanceSaving, setBalanceSaving] = useState(false);

  // Profile Form State
  const [editProfile, setEditProfile] = useState<Partial<AccountProfile>>({});
  const [profileSaving, setProfileSaving] = useState(false);

  // Transaction Manager State
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState('all');
  const [txStatusFilter, setTxStatusFilter] = useState('all');
  const [newTxModalOpen, setNewTxModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<TransactionRecord | null>(null);
  const [txFormData, setTxFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    reference: '',
    description: '',
    type: 'deposit' as any,
    amount: '',
    currency: 'USD',
    status: 'Completed' as any,
    category: 'Treasury & Reserve'
  });

  // Notification Form State
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifPriority, setNotifPriority] = useState<'routine' | 'advisory' | 'institutional'>('institutional');
  const [notifSaving, setNotifSaving] = useState(false);

  // Load all central database state
  const loadData = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [accRes, txRes, auditRes, notifRes] = await Promise.all([
        api.getAccount(),
        api.getTransactions({ limit: 100 }),
        api.getAuditLogs(),
        api.getNotifications()
      ]);

      setProfile(accRes.profile);
      setBalances(accRes.balances);
      setEditProfile(accRes.profile);
      setNewCurrentBalance(accRes.balances.currentBalance.toString());
      setNewLiquidity(accRes.balances.availableDiscretionaryLiquidity.toString());

      setTransactions(txRes.items);
      setTotalTransactions(txRes.total);
      setAuditLogs(auditRes.items);
      setNotifications(notifRes.items);
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Error synchronizing database.', type: 'error' });
    } finally {
      if (!silent) setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
    // Poll every 15s for synchronized multi-tab updates
    const interval = setInterval(() => loadData(true), 15000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    loadData(false);
  };

  // Balance Update Submission
  const handleSaveBalances = async () => {
    if (!balanceJustification.trim()) {
      setStatusMessage({ text: 'Mandatory justification required for institutional audit record.', type: 'error' });
      return;
    }

    setBalanceSaving(true);
    setStatusMessage(null);
    try {
      const currentVal = parseFloat(newCurrentBalance);
      const liquidityVal = parseFloat(newLiquidity);

      if (isNaN(currentVal) || isNaN(liquidityVal)) {
        throw new Error('Please enter valid numeric figures for balances.');
      }

      const res = await api.updateBalances(currentVal, liquidityVal, balanceJustification);
      setBalances(res.balances);
      setBalanceModalOpen(false);
      setBalanceJustification('');
      setStatusMessage({ text: 'Balances successfully calibrated and recorded in immutable audit log.', type: 'success' });
      loadData(true);
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Failed to update balances.', type: 'error' });
    } finally {
      setBalanceSaving(false);
    }
  };

  // Profile Update Submission
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSaving(true);
    setStatusMessage(null);
    try {
      const res = await api.updateProfile(editProfile);
      setProfile(res.profile);
      setStatusMessage({ text: 'Account profile updated. Changes are instantly live in Visitor Mode.', type: 'success' });
      loadData(true);
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Failed to update profile.', type: 'error' });
    } finally {
      setProfileSaving(false);
    }
  };

  // Transaction Create or Edit
  const handleSaveTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);
    try {
      const amt = parseFloat(txFormData.amount);
      if (isNaN(amt) || amt <= 0) {
        throw new Error('Please enter a valid positive transaction amount.');
      }
      if (amt > 300000) {
        throw new Error('Transaction limit constraint: demonstration records cannot exceed $300,000 USD.');
      }

      if (editingTx) {
        await api.updateTransaction(editingTx.id, {
          ...txFormData,
          amount: amt
        });
        setStatusMessage({ text: `Transaction ${txFormData.reference} updated successfully.`, type: 'success' });
      } else {
        const ref = txFormData.reference || `LHT-TXN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
        await api.createTransaction({
          ...txFormData,
          reference: ref,
          amount: amt
        });
        setStatusMessage({ text: `New demonstration transaction record established.`, type: 'success' });
      }

      setNewTxModalOpen(false);
      setEditingTx(null);
      setTxFormData({
        date: new Date().toISOString().split('T')[0],
        reference: '',
        description: '',
        type: 'deposit',
        amount: '',
        currency: 'USD',
        status: 'Completed',
        category: 'Treasury & Reserve'
      });
      loadData(true);
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Failed to save transaction.', type: 'error' });
    }
  };

  // Delete Transaction
  const handleDeleteTransaction = async (id: string, ref: string) => {
    if (!window.confirm(`Are you sure you want to remove demonstration transaction record ${ref}? This will generate an audit log entry.`)) {
      return;
    }

    try {
      await api.deleteTransaction(id);
      setStatusMessage({ text: `Transaction ${ref} deleted.`, type: 'success' });
      loadData(true);
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Failed to delete transaction.', type: 'error' });
    }
  };

  // Broadcast Notification
  const handleCreateNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotifSaving(true);
    setStatusMessage(null);
    try {
      await api.createNotification({
        title: notifTitle,
        message: notifMessage,
        priority: notifPriority,
        sender: 'Administrator Fiduciary Directorate'
      });
      setNotifTitle('');
      setNotifMessage('');
      setStatusMessage({ text: 'Institutional announcement broadcasted to Visitor Dashboard.', type: 'success' });
      loadData(true);
    } catch (err: any) {
      setStatusMessage({ text: err.message || 'Failed to broadcast announcement.', type: 'error' });
    } finally {
      setNotifSaving(false);
    }
  };

  // Filtered transactions for view
  const filteredTransactions = transactions.filter((t) => {
    const matchesSearch =
      t.description.toLowerCase().includes(txSearch.toLowerCase()) ||
      t.reference.toLowerCase().includes(txSearch.toLowerCase()) ||
      t.category.toLowerCase().includes(txSearch.toLowerCase());
    const matchesType = txTypeFilter === 'all' || t.type === txTypeFilter;
    const matchesStatus = txStatusFilter === 'all' || t.status === txStatusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#0D192B] flex flex-col">
      {/* Top Admin Notice Ribbon */}
      <div className="bg-[#08142C] text-[#C5A059] text-xs py-1.5 px-4 flex items-center justify-between border-b border-[#C5A059]/30">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-3.5 h-3.5 text-[#DFC076]" />
          <span className="font-semibold uppercase tracking-wider text-[11px]">
            Master Administrative Fiduciary Console (Role: Administrator)
          </span>
        </div>
        <div className="flex items-center gap-4 text-[11px] text-stone-300">
          <span>Auth Code: 777000</span>
          <span>•</span>
          <span className="text-[#DFC076]">Central DB Synced</span>
        </div>
      </div>

      {/* Main Administrative Navigation Header */}
      <header className="bg-[#0B1B3D] border-b border-[#C5A059]/30 text-white sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src={BRAND_ASSETS.logo}
              alt="Litchfield Heritage Trust"
              className="h-11 w-auto object-contain bg-white/10 p-1 rounded border border-[#C5A059]/30"
            />
            <div className="hidden sm:block">
              <h1 className="font-serif text-lg font-medium text-white leading-none">
                Litchfield Heritage Trust
              </h1>
              <p className="text-[10px] text-[#C5A059] tracking-widest uppercase mt-0.5">
                Executive Governance & Ledger Management
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-stone-200 text-xs rounded transition-colors cursor-pointer"
              title="Synchronize database"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-[#C5A059]' : ''}`} />
              <span className="hidden sm:inline">Sync DB</span>
            </button>

            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#C5A059] hover:bg-[#b88d36] text-[#0B1B3D] text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Desktop Tab Rail */}
        <div className="hidden lg:flex max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-auto border-t border-white/10">
          {[
            { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'profile', label: 'Account Profile', icon: UserCheck },
            { id: 'balances', label: 'Balance Management', icon: DollarSign },
            { id: 'transactions', label: 'Transaction Manager', icon: Receipt },
            { id: 'audit', label: 'Audit Log', icon: ShieldAlert },
            { id: 'notifications', label: 'Notifications', icon: Bell },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as AdminTab)}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-medium tracking-wide border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'border-[#C5A059] text-[#DFC076] bg-white/5'
                    : 'border-transparent text-stone-300 hover:text-white hover:border-[#C5A059]/40'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#08142C] border-b border-[#C5A059]/30 p-4 space-y-2 text-white">
          {[
            { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'profile', label: 'Account Profile', icon: UserCheck },
            { id: 'balances', label: 'Balance Management', icon: DollarSign },
            { id: 'transactions', label: 'Transaction Manager', icon: Receipt },
            { id: 'audit', label: 'Audit Log', icon: ShieldAlert },
            { id: 'notifications', label: 'Notifications', icon: Bell },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as AdminTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-xs text-left ${
                  active ? 'bg-[#102A5C] text-[#DFC076] font-semibold' : 'text-stone-300 hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4 text-[#C5A059]" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Status Alert Banner */}
      {statusMessage && (
        <div
          className={`max-w-7xl mx-auto px-4 mt-4 w-full p-3.5 rounded text-xs flex items-center justify-between ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMessage.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-600" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600" />
            )}
            <span>{statusMessage.text}</span>
          </div>
          <button
            onClick={() => setStatusMessage(null)}
            className="text-stone-400 hover:text-stone-700 text-xs font-semibold px-2 py-0.5"
          >
            ✕
          </button>
        </div>
      )}

      {/* MAIN CONTENT WORKSPACE */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {loading ? (
          <div className="py-20 text-center space-y-4">
            <div className="w-10 h-10 border-4 border-[#C5A059] border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-stone-500 uppercase tracking-widest font-mono">
              Loading Institutional Fiduciary Repository...
            </p>
          </div>
        ) : (
          <>
            {/* 1. DASHBOARD OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="space-y-8 animate-fadeIn">
                {/* Header Welcome & Identity */}
                <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <div className="text-xs font-semibold text-[#B88D36] uppercase tracking-widest">
                      Institutional Repository
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-serif font-semibold text-[#0B1B3D] mt-1">
                      {profile?.accountHolderName || 'Aurelian House Heritage Trust'}
                    </h2>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 mt-2">
                      <span>Account No: <strong className="font-mono text-stone-800">{profile?.accountNumber}</strong></span>
                      <span>·</span>
                      <span>Type: <strong className="text-stone-800">{profile?.accountType}</strong></span>
                      <span>·</span>
                      <span>Status: <strong className="text-emerald-700">{profile?.status}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setActiveTab('balances')}
                      className="px-4 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-2"
                    >
                      <DollarSign className="w-4 h-4" />
                      <span>Calibrate Balances</span>
                    </button>
                  </div>
                </div>

                {/* CRITICAL FINANCIAL FIGURES: CURRENT BALANCE vs AVAILABLE DISCRETIONARY LIQUIDITY */}
                {/* STRICT REQUIREMENT: MUST ALWAYS BE SEPARATE FIGURES WITH SEPARATE LABELS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Current Balance Card */}
                  <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm relative overflow-hidden">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                        Current Balance (Demonstration Display)
                      </span>
                      <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-stone-100 text-stone-600 rounded">
                        USD Currency
                      </span>
                    </div>
                    <div className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1B3D] tabular-nums tracking-tight">
                      ${balances?.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <div className="mt-4 pt-4 border-t border-stone-100 text-xs text-stone-500 flex items-center justify-between">
                      <span>Last calibrated: {new Date(balances?.lastUpdated || '').toLocaleString()}</span>
                      <button
                        onClick={() => setActiveTab('balances')}
                        className="text-[#B88D36] font-semibold hover:underline"
                      >
                        Adjust Figure →
                      </button>
                    </div>
                  </div>

                  {/* Available Discretionary Liquidity Card */}
                  <div className="bg-[#0B1B3D] text-white p-6 sm:p-8 rounded-lg border border-[#C5A059]/40 shadow-sm relative overflow-hidden">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold uppercase tracking-wider text-[#DFC076]">
                        Available Discretionary Liquidity
                      </span>
                      <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-[#102A5C] text-[#DFC076] rounded">
                        Unencumbered Facility
                      </span>
                    </div>
                    <div className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#DFC076] tabular-nums tracking-tight">
                      ${balances?.availableDiscretionaryLiquidity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <div className="mt-4 pt-4 border-t border-white/10 text-xs text-stone-300 flex items-center justify-between">
                      <span>Institutional reserve limit</span>
                      <button
                        onClick={() => setActiveTab('balances')}
                        className="text-[#DFC076] font-semibold hover:underline"
                      >
                        Adjust Figure →
                      </button>
                    </div>
                  </div>
                </div>

                {/* Recent Demonstration Activity & Quick Stats */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Left 2 Cols: Recent Transactions */}
                  <div className="lg:col-span-2 bg-white rounded-lg border border-stone-200 p-6 shadow-sm space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="font-serif text-lg font-semibold text-[#0B1B3D]">
                        Recent Demonstration Transactions
                      </h3>
                      <button
                        onClick={() => setActiveTab('transactions')}
                        className="text-xs text-[#B88D36] font-semibold hover:underline"
                      >
                        View All {totalTransactions} Records →
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-stone-50 text-stone-500 uppercase tracking-wider text-[10px]">
                          <tr>
                            <th className="py-2.5 px-3">Date</th>
                            <th className="py-2.5 px-3">Reference</th>
                            <th className="py-2.5 px-3">Description</th>
                            <th className="py-2.5 px-3 text-right">Amount</th>
                            <th className="py-2.5 px-3">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-100">
                          {transactions.slice(0, 5).map((t) => (
                            <tr key={t.id} className="hover:bg-stone-50/50">
                              <td className="py-2.5 px-3 whitespace-nowrap text-stone-600">{t.date}</td>
                              <td className="py-2.5 px-3 font-mono text-stone-500 text-[11px]">{t.reference}</td>
                              <td className="py-2.5 px-3 font-medium text-stone-800 max-w-xs truncate">{t.description}</td>
                              <td
                                className={`py-2.5 px-3 text-right font-mono font-semibold tabular-nums ${
                                  t.type === 'withdrawal' || t.type === 'payment'
                                    ? 'text-rose-700'
                                    : 'text-emerald-700'
                                }`}
                              >
                                {t.type === 'withdrawal' || t.type === 'payment' ? '-' : '+'}
                                ${t.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                              </td>
                              <td className="py-2.5 px-3">
                                <span className="text-[10px] font-medium text-stone-600 px-1.5 py-0.5 bg-stone-100 rounded">
                                  {t.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Right Col: Active Announcements & Quick Audit Status */}
                  <div className="space-y-6">
                    <div className="bg-white rounded-lg border border-stone-200 p-6 shadow-sm space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="font-serif text-base font-semibold text-[#0B1B3D]">
                          Active Announcements
                        </h3>
                        <button
                          onClick={() => setActiveTab('notifications')}
                          className="text-xs text-[#B88D36] font-semibold hover:underline"
                        >
                          Manage
                        </button>
                      </div>

                      <div className="space-y-3">
                        {notifications.slice(0, 3).map((n) => (
                          <div key={n.id} className="p-3 bg-stone-50 rounded border border-stone-100 space-y-1">
                            <div className="text-xs font-semibold text-stone-800">{n.title}</div>
                            <div className="text-[11px] text-stone-500 line-clamp-2">{n.message}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-[#FAF8F5] rounded-lg border border-stone-200 p-6 shadow-sm space-y-2">
                      <div className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                        Synchronized Database State
                      </div>
                      <p className="text-xs text-stone-600 leading-relaxed">
                        Changes committed in this console are immediately shared and visible to Visitor Mode.
                      </p>
                      <div className="pt-2 flex items-center gap-2 text-xs text-emerald-700 font-medium">
                        <CheckCircle className="w-4 h-4" />
                        <span>Central Persistence Active</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. ACCOUNT PROFILE MANAGEMENT */}
            {activeTab === 'profile' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Administrative Master Control
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-1">
                    Account Profile Settings
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    Updates made here persist in the central database and immediately synchronize to the Visitor Dashboard.
                  </p>
                </div>

                <form onSubmit={handleSaveProfile} className="space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-stone-700 uppercase">
                      Account Holder Display Name
                    </label>
                    <input
                      type="text"
                      required
                      value={editProfile.accountHolderName || ''}
                      onChange={(e) => setEditProfile({ ...editProfile, accountHolderName: e.target.value })}
                      className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">
                        Fictional Account Number Display
                      </label>
                      <input
                        type="text"
                        required
                        value={editProfile.accountNumber || ''}
                        onChange={(e) => setEditProfile({ ...editProfile, accountNumber: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">
                        Account Type Classification
                      </label>
                      <input
                        type="text"
                        required
                        value={editProfile.accountType || ''}
                        onChange={(e) => setEditProfile({ ...editProfile, accountType: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-stone-700 uppercase">
                      Account Mandate Description
                    </label>
                    <textarea
                      rows={3}
                      value={editProfile.accountDescription || ''}
                      onChange={(e) => setEditProfile({ ...editProfile, accountDescription: e.target.value })}
                      className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Currency</label>
                      <input
                        type="text"
                        value={editProfile.currency || 'USD'}
                        onChange={(e) => setEditProfile({ ...editProfile, currency: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none font-mono uppercase"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Routing Identifier</label>
                      <input
                        type="text"
                        value={editProfile.routingNumber || ''}
                        onChange={(e) => setEditProfile({ ...editProfile, routingNumber: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">SWIFT / BIC Code</label>
                      <input
                        type="text"
                        value={editProfile.swiftBic || ''}
                        onChange={(e) => setEditProfile({ ...editProfile, swiftBic: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-stone-700 uppercase">Status Description</label>
                    <input
                      type="text"
                      value={editProfile.status || ''}
                      onChange={(e) => setEditProfile({ ...editProfile, status: e.target.value })}
                      className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none"
                    />
                  </div>

                  <div className="pt-4 border-t border-stone-200 flex justify-end">
                    <button
                      type="submit"
                      disabled={profileSaving}
                      className="px-6 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors disabled:opacity-50 cursor-pointer"
                    >
                      {profileSaving ? 'Saving to Database...' : 'Save Profile Changes'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* 3. BALANCE MANAGEMENT (MANDATORY AUDIT LOG & SEPARATE FIGURES) */}
            {activeTab === 'balances' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Institutional Fiduciary Calibration
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-1">
                    Balance Management Console
                  </h2>
                  <p className="text-xs text-stone-600 mt-1">
                    Calibrate the demonstration display figures. These are simulated figures for technical evaluation.
                    Every change requires mandatory justification and generates an immutable audit log record.
                  </p>
                </div>

                {/* Section A: Current Balance Control */}
                <div className="p-5 bg-stone-50 rounded-lg border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-serif font-semibold text-[#0B1B3D] text-sm">
                      1. Current Balance
                    </h3>
                    <span className="text-xs text-stone-500 font-mono">
                      Current: ${balances?.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-stone-600 uppercase">New Displayed Value ($ USD)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={newCurrentBalance}
                      onChange={(e) => setNewCurrentBalance(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                    />
                  </div>
                </div>

                {/* Section B: Available Discretionary Liquidity Control */}
                <div className="p-5 bg-stone-50 rounded-lg border border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-serif font-semibold text-[#0B1B3D] text-sm">
                      2. Available Discretionary Liquidity
                    </h3>
                    <span className="text-xs text-stone-500 font-mono">
                      Current: ${balances?.availableDiscretionaryLiquidity.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-stone-600 uppercase">New Displayed Value ($ USD)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={newLiquidity}
                      onChange={(e) => setNewLiquidity(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                    />
                  </div>
                </div>

                {/* Section C: Mandatory Justification */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-stone-700 uppercase flex items-center justify-between">
                    <span>Mandatory Fiduciary Justification *</span>
                    <span className="text-[11px] text-[#B88D36] lowercase font-normal">(Recorded in permanent audit log)</span>
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={balanceJustification}
                    onChange={(e) => setBalanceJustification(e.target.value)}
                    placeholder="Provide explicit operational rationale for this demonstration balance adjustment..."
                    className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:bg-white focus:outline-none resize-none"
                  />
                </div>

                <div className="pt-4 border-t border-stone-200 flex items-center justify-between">
                  <span className="text-[11px] text-stone-500 italic">
                    Both figures will update synchronously in Visitor Mode.
                  </span>
                  <button
                    type="button"
                    onClick={() => setBalanceModalOpen(true)}
                    disabled={!balanceJustification.trim()}
                    className="px-6 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Review & Calibrate Balances
                  </button>
                </div>

                {/* Confirmation Modal */}
                {balanceModalOpen && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                    <div className="bg-white rounded-lg p-6 max-w-md w-full border border-stone-200 shadow-2xl space-y-4">
                      <h3 className="font-serif text-lg font-semibold text-[#0B1B3D]">
                        Confirm Balance Recalibration
                      </h3>
                      <p className="text-xs text-stone-600 leading-relaxed">
                        You are about to commit the following demonstration figures to the central database:
                      </p>

                      <div className="bg-stone-50 p-3 rounded border border-stone-200 text-xs space-y-1.5 font-mono">
                        <div>
                          <span className="text-stone-500">Current Balance:</span>{' '}
                          <strong className="text-stone-900">${parseFloat(newCurrentBalance).toLocaleString()}</strong>
                        </div>
                        <div>
                          <span className="text-stone-500">Discretionary Liquidity:</span>{' '}
                          <strong className="text-stone-900">${parseFloat(newLiquidity).toLocaleString()}</strong>
                        </div>
                        <div className="pt-1 text-[11px] text-stone-600 font-sans">
                          <strong>Justification:</strong> {balanceJustification}
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-3">
                        <button
                          type="button"
                          onClick={() => setBalanceModalOpen(false)}
                          className="px-4 py-2 text-xs font-medium text-stone-600 hover:text-stone-900"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={handleSaveBalances}
                          disabled={balanceSaving}
                          className="px-5 py-2 bg-[#0B1B3D] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded"
                        >
                          {balanceSaving ? 'Recording Audit...' : 'Confirm & Persist'}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 4. TRANSACTION MANAGER */}
            {activeTab === 'transactions' && (
              <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                      Ledger Management
                    </span>
                    <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                      Transaction Manager
                    </h2>
                    <p className="text-xs text-stone-500">
                      Total {totalTransactions} demonstration transactions covering Jan 2020 through Nov 2026.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setEditingTx(null);
                      setTxFormData({
                        date: new Date().toISOString().split('T')[0],
                        reference: `LHT-TXN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
                        description: '',
                        type: 'deposit',
                        amount: '',
                        currency: 'USD',
                        status: 'Completed',
                        category: 'Treasury & Reserve'
                      });
                      setNewTxModalOpen(true);
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors cursor-pointer self-start sm:self-auto"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create Demonstration Record</span>
                  </button>
                </div>

                {/* Search & Filters */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                  <div className="relative">
                    <input
                      type="text"
                      value={txSearch}
                      onChange={(e) => setTxSearch(e.target.value)}
                      placeholder="Search description, reference, or category..."
                      className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    />
                    <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  </div>

                  <div>
                    <select
                      value={txTypeFilter}
                      onChange={(e) => setTxTypeFilter(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    >
                      <option value="all">All Transaction Types</option>
                      <option value="deposit">Deposits</option>
                      <option value="withdrawal">Withdrawals</option>
                      <option value="transfer_in">Transfers In</option>
                      <option value="transfer_out">Transfers Out</option>
                      <option value="payment">Payments</option>
                      <option value="adjustment">Adjustments</option>
                    </select>
                  </div>

                  <div>
                    <select
                      value={txStatusFilter}
                      onChange={(e) => setTxStatusFilter(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    >
                      <option value="all">All Statuses</option>
                      <option value="Completed">Completed</option>
                      <option value="Settled">Settled</option>
                      <option value="Processed">Processed</option>
                      <option value="Cleared">Cleared</option>
                    </select>
                  </div>
                </div>

                {/* Table View */}
                <div className="overflow-x-auto border border-stone-200 rounded-lg">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-stone-50 text-stone-600 uppercase tracking-wider text-[11px] border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3">Date</th>
                        <th className="py-3 px-3">Reference</th>
                        <th className="py-3 px-3">Description</th>
                        <th className="py-3 px-3">Type</th>
                        <th className="py-3 px-3 text-right">Amount</th>
                        <th className="py-3 px-3">Status</th>
                        <th className="py-3 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {filteredTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-stone-400">
                            No matching demonstration transactions found.
                          </td>
                        </tr>
                      ) : (
                        filteredTransactions.map((tx) => (
                          <tr key={tx.id} className="hover:bg-stone-50/70 transition-colors">
                            <td className="py-2.5 px-3 whitespace-nowrap text-stone-600 font-mono text-[11px]">{tx.date}</td>
                            <td className="py-2.5 px-3 font-mono text-stone-500 text-[11px]">{tx.reference}</td>
                            <td className="py-2.5 px-3 font-medium text-stone-900 max-w-xs truncate">{tx.description}</td>
                            <td className="py-2.5 px-3">
                              <span className="capitalize text-stone-600 text-[11px]">{tx.type.replace('_', ' ')}</span>
                            </td>
                            <td
                              className={`py-2.5 px-3 text-right font-mono font-semibold tabular-nums ${
                                tx.type === 'withdrawal' || tx.type === 'payment'
                                  ? 'text-rose-700'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {tx.type === 'withdrawal' || tx.type === 'payment' ? '-' : '+'}
                              ${tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="text-[10px] font-medium text-stone-600 px-1.5 py-0.5 bg-stone-100 rounded">
                                {tx.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right space-x-1 whitespace-nowrap">
                              <button
                                onClick={() => {
                                  setEditingTx(tx);
                                  setTxFormData({
                                    date: tx.date,
                                    reference: tx.reference,
                                    description: tx.description,
                                    type: tx.type,
                                    amount: tx.amount.toString(),
                                    currency: tx.currency,
                                    status: tx.status,
                                    category: tx.category || 'Treasury & Reserve'
                                  });
                                  setNewTxModalOpen(true);
                                }}
                                className="p-1 text-stone-400 hover:text-stone-800"
                                title="Edit Record"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteTransaction(tx.id, tx.reference)}
                                className="p-1 text-stone-400 hover:text-rose-600"
                                title="Delete Record"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Create/Edit Modal */}
                {newTxModalOpen && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                    <div className="bg-white rounded-lg p-6 max-w-lg w-full border border-stone-200 shadow-2xl space-y-4">
                      <div className="flex items-center justify-between border-b pb-3 border-stone-100">
                        <h3 className="font-serif text-lg font-semibold text-[#0B1B3D]">
                          {editingTx ? 'Edit Transaction Record' : 'Create Demonstration Transaction'}
                        </h3>
                        <button onClick={() => setNewTxModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                          ✕
                        </button>
                      </div>

                      <form onSubmit={handleSaveTransaction} className="space-y-4">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-stone-600 uppercase">Date</label>
                            <input
                              type="date"
                              required
                              value={txFormData.date}
                              onChange={(e) => setTxFormData({ ...txFormData, date: e.target.value })}
                              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-stone-600 uppercase">Reference</label>
                            <input
                              type="text"
                              required
                              value={txFormData.reference}
                              onChange={(e) => setTxFormData({ ...txFormData, reference: e.target.value })}
                              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none font-mono"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] font-semibold text-stone-600 uppercase">Description</label>
                          <input
                            type="text"
                            required
                            value={txFormData.description}
                            onChange={(e) => setTxFormData({ ...txFormData, description: e.target.value })}
                            placeholder="e.g. Discretionary Treasury Coupon Allocation"
                            className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-stone-600 uppercase">Transaction Type</label>
                            <select
                              value={txFormData.type}
                              onChange={(e) => setTxFormData({ ...txFormData, type: e.target.value as any })}
                              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none"
                            >
                              <option value="deposit">Deposit</option>
                              <option value="withdrawal">Withdrawal</option>
                              <option value="transfer_in">Transfer In</option>
                              <option value="transfer_out">Transfer Out</option>
                              <option value="payment">Payment</option>
                              <option value="adjustment">Adjustment</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-stone-600 uppercase">
                              Amount (Max $300,000)
                            </label>
                            <input
                              type="number"
                              step="0.01"
                              max="300000"
                              required
                              value={txFormData.amount}
                              onChange={(e) => setTxFormData({ ...txFormData, amount: e.target.value })}
                              placeholder="0.00"
                              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none font-mono"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-stone-600 uppercase">Category</label>
                            <input
                              type="text"
                              value={txFormData.category}
                              onChange={(e) => setTxFormData({ ...txFormData, category: e.target.value })}
                              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] font-semibold text-stone-600 uppercase">Status</label>
                            <select
                              value={txFormData.status}
                              onChange={(e) => setTxFormData({ ...txFormData, status: e.target.value as any })}
                              className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none"
                            >
                              <option value="Completed">Completed</option>
                              <option value="Settled">Settled</option>
                              <option value="Processed">Processed</option>
                              <option value="Cleared">Cleared</option>
                            </select>
                          </div>
                        </div>

                        <div className="pt-3 border-t border-stone-100 flex justify-end gap-3">
                          <button
                            type="button"
                            onClick={() => setNewTxModalOpen(false)}
                            className="px-4 py-2 text-xs text-stone-600"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-5 py-2 bg-[#0B1B3D] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded"
                          >
                            {editingTx ? 'Save Updates' : 'Create Record'}
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 5. AUDIT LOG (IMMUTABLE RECORD) */}
            {activeTab === 'audit' && (
              <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                      Compliance & Oversight
                    </span>
                    <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                      Immutable Audit Log
                    </h2>
                    <p className="text-xs text-stone-500">
                      Every administrative balance change, profile amendment, and transaction update is permanently cataloged.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-stone-600 font-mono">
                    <Lock className="w-3.5 h-3.5 text-[#B88D36]" />
                    <span>Append-Only Protection</span>
                  </div>
                </div>

                <div className="overflow-x-auto border border-stone-200 rounded-lg">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-stone-50 text-stone-600 uppercase tracking-wider text-[11px] border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3">Timestamp</th>
                        <th className="py-3 px-3">Action</th>
                        <th className="py-3 px-3">Administrator</th>
                        <th className="py-3 px-3">Previous Value</th>
                        <th className="py-3 px-3">New Value</th>
                        <th className="py-3 px-3">Mandatory Reason</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {auditLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-stone-50/70 transition-colors">
                          <td className="py-2.5 px-3 whitespace-nowrap text-stone-500 font-mono text-[11px]">
                            {new Date(log.timestamp).toLocaleString()}
                          </td>
                          <td className="py-2.5 px-3 font-semibold text-[#0B1B3D]">{log.action}</td>
                          <td className="py-2.5 px-3 text-stone-600">{log.administrator}</td>
                          <td className="py-2.5 px-3 text-stone-500 font-mono text-[11px] max-w-xs truncate">
                            {log.previousValue}
                          </td>
                          <td className="py-2.5 px-3 text-stone-800 font-mono text-[11px] font-medium max-w-xs truncate">
                            {log.newValue}
                          </td>
                          <td className="py-2.5 px-3 text-stone-600 max-w-xs truncate">{log.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 6. NOTIFICATIONS (ADMIN ANNOUNCEMENTS) */}
            {activeTab === 'notifications' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Broadcast Console
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-1">
                    Administrator Announcements
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    Broadcast institutional notifications. Announcements will immediately appear on the Visitor Dashboard.
                  </p>
                </div>

                <form onSubmit={handleCreateNotification} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-stone-700 uppercase">Announcement Title *</label>
                    <input
                      type="text"
                      required
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      placeholder="e.g. Scheduled Fiduciary Maintenance Window"
                      className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-stone-700 uppercase">Notification Priority</label>
                    <select
                      value={notifPriority}
                      onChange={(e) => setNotifPriority(e.target.value as any)}
                      className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    >
                      <option value="routine">Routine Notification</option>
                      <option value="advisory">Advisory Alert</option>
                      <option value="institutional">Institutional Directive</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-stone-700 uppercase">Message Body *</label>
                    <textarea
                      rows={3}
                      required
                      value={notifMessage}
                      onChange={(e) => setNotifMessage(e.target.value)}
                      placeholder="Enter the broadcast notification message..."
                      className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none resize-none"
                    />
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="submit"
                      disabled={notifSaving}
                      className="px-6 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors disabled:opacity-50 cursor-pointer"
                    >
                      {notifSaving ? 'Broadcasting...' : 'Broadcast to Visitor Dashboard'}
                    </button>
                  </div>
                </form>

                <div className="pt-6 border-t border-stone-200 space-y-4">
                  <h3 className="font-serif text-base font-semibold text-[#0B1B3D]">
                    Currently Broadcasted Announcements
                  </h3>
                  <div className="space-y-3">
                    {notifications.map((n) => (
                      <div key={n.id} className="p-4 bg-stone-50 rounded-lg border border-stone-200 flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-stone-900">{n.title}</span>
                            <span className="text-[10px] font-mono text-stone-400">· {new Date(n.date).toLocaleDateString()}</span>
                          </div>
                          <p className="text-xs text-stone-600 leading-relaxed">{n.message}</p>
                          <div className="text-[10px] text-[#B88D36] font-medium">Broadcast by: {n.sender}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 7. SETTINGS */}
            {activeTab === 'settings' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Environment Preferences
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-1">
                    Administrator Interface Settings
                  </h2>
                  <p className="text-xs text-stone-500 mt-1">
                    System configuration and security parameters for this demonstration session.
                  </p>
                </div>

                <div className="space-y-4 text-xs text-stone-700 divide-y divide-stone-100">
                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Prototype Authentication Mode</div>
                      <div className="text-stone-500">Dual-code verification active on unified login</div>
                    </div>
                    <span className="px-2.5 py-1 bg-stone-100 text-stone-700 rounded font-mono">Code: 777000</span>
                  </div>

                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Database Storage Tier</div>
                      <div className="text-stone-500">Atomic disk persistence with memory mirror</div>
                    </div>
                    <span className="px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded font-medium">Active (data/database.json)</span>
                  </div>

                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Demonstration Ledger Limit</div>
                      <div className="text-stone-500">Strict cap: No transaction exceeds $300,000 USD</div>
                    </div>
                    <span className="px-2.5 py-1 bg-stone-100 text-stone-700 rounded font-mono">$300,000 Cap Enforced</span>
                  </div>

                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Transfer Simulation Lock</div>
                      <div className="text-stone-500">All outbound transfer requests strictly terminate as failed</div>
                    </div>
                    <span className="px-2.5 py-1 bg-amber-50 text-amber-800 rounded font-medium">Mandatory Fail Protocol</span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};
