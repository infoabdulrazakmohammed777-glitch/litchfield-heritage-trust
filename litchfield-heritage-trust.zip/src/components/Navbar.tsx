import React, { useState } from 'react';
import { BRAND_ASSETS } from '../assets';
import { Menu, X, ShieldCheck, Lock } from 'lucide-react';

interface NavbarProps {
  onOpenSignIn: () => void;
  activeSection: string;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSignIn, activeSection, onNavigateSection }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'hero', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'services', label: 'Our Services' },
    { id: 'investment', label: 'Investment Services' },
    { id: 'resources', label: 'Resources' },
    { id: 'contact', label: 'Contact Us' },
  ];

  const handleLinkClick = (id: string) => {
    onNavigateSection(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0B1B3D]/95 backdrop-blur-md border-b border-[#C5A059]/30 text-white transition-all duration-200">
      {/* Top Banner Notice */}
      <div className="bg-[#08142C] text-[#C5A059] text-[11px] py-1 px-4 text-center border-b border-[#C5A059]/20 font-medium tracking-wider">
        <span className="inline-flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
          <span>INSTITUTIONAL DEMONSTRATION PLATFORM — ALL ACCOUNTS & BALANCES ARE SIMULATED</span>
        </span>
      </div>

      {/* Main 3-Zone Navigation Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Official Brand Logo & Monogram */}
        <button
          onClick={() => handleLinkClick('hero')}
          className="flex items-center gap-3.5 group text-left cursor-pointer focus:outline-none"
        >
          <img
            src={BRAND_ASSETS.logo}
            alt="Litchfield Heritage Trust Logo"
            className="h-12 w-auto object-contain transition-transform duration-200 group-hover:scale-105 drop-shadow-sm"
          />
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-7 text-[13px] font-medium tracking-wide">
          {navLinks.map((item) => (
            <button
              key={item.id}
              onClick={() => handleLinkClick(item.id)}
              className={`whitespace-nowrap transition-colors duration-150 py-1 border-b-2 cursor-pointer ${
                activeSection === item.id
                  ? 'text-[#C5A059] border-[#C5A059]'
                  : 'text-stone-300 border-transparent hover:text-white hover:border-[#C5A059]/60'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Action - Online Banking */}
        <div className="hidden sm:flex items-center gap-4 shrink-0">
          <button
            onClick={onOpenSignIn}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#C5A059] hover:bg-[#b88d36] text-[#0B1B3D] text-xs font-semibold uppercase tracking-wider rounded transition-all duration-200 shadow-sm hover:shadow-md cursor-pointer whitespace-nowrap active:translate-y-0.5"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Online Banking / Sign In</span>
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex lg:hidden items-center gap-2">
          <button
            onClick={onOpenSignIn}
            className="sm:hidden inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#C5A059] text-[#0B1B3D] text-[11px] font-semibold uppercase tracking-wider rounded"
          >
            <Lock className="w-3 h-3" />
            <span>Sign In</span>
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-stone-300 hover:text-white hover:bg-[#102A5C] rounded transition-colors focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#08142C] border-b border-[#C5A059]/30 px-6 py-6 space-y-4 animate-fadeIn">
          <div className="flex flex-col space-y-3">
            {navLinks.map((item) => (
              <button
                key={item.id}
                onClick={() => handleLinkClick(item.id)}
                className={`text-left text-sm py-2 px-3 rounded transition-colors ${
                  activeSection === item.id
                    ? 'bg-[#102A5C] text-[#C5A059] font-medium'
                    : 'text-stone-300 hover:text-white hover:bg-[#102A5C]/60'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="pt-4 border-t border-[#C5A059]/20">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSignIn();
              }}
              className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-[#C5A059] hover:bg-[#b88d36] text-[#0B1B3D] text-xs font-semibold uppercase tracking-wider rounded"
            >
              <Lock className="w-4 h-4" />
              <span>Access Online Banking</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
