import React, { useState, useEffect } from 'react';
import { BRAND_ASSETS } from '../assets';
import {
  LayoutDashboard,
  Wallet,
  Receipt,
  ArrowRightLeft,
  Globe,
  Users,
  FileText,
  ShieldCheck,
  Bell,
  Settings,
  LogOut,
  Eye,
  EyeOff,
  Search,
  Filter,
  CheckCircle,
  AlertCircle,
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
  Printer,
  Download,
  Calendar,
  Building,
  Menu,
  X,
  Plus,
  Trash2,
  Edit2,
  ChevronRight,
  Info,
  FastForward,
  XCircle
} from 'lucide-react';
import { api } from '../api';
import { AccountBalances, AccountProfile, Beneficiary, NotificationItem, TransactionRecord } from '../types';

interface VisitorDashboardProps {
  onLogout: () => void;
}

type VisitorTab =
  | 'overview'
  | 'accounts'
  | 'transactions'
  | 'domestic'
  | 'international'
  | 'beneficiaries'
  | 'statements'
  | 'details'
  | 'notifications'
  | 'settings';

export const VisitorDashboard: React.FC<VisitorDashboardProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState<VisitorTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Central Database States (Shared with Admin)
  const [profile, setProfile] = useState<AccountProfile | null>(null);
  const [balances, setBalances] = useState<AccountBalances | null>(null);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Balance Visibility Toggle
  const [balancesVisible, setBalancesVisible] = useState(true);

  // Transaction History Filter & Pagination States
  const [txSearch, setTxSearch] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState('all');
  const [txStatusFilter, setTxStatusFilter] = useState('all');
  const [txStartDate, setTxStartDate] = useState('');
  const [txEndDate, setTxEndDate] = useState('');
  const [selectedTx, setSelectedTx] = useState<TransactionRecord | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  // Beneficiary Management States
  const [newBenModalOpen, setNewBenModalOpen] = useState(false);
  const [editingBen, setEditingBen] = useState<Beneficiary | null>(null);
  const [benFormData, setBenFormData] = useState({
    fullName: '',
    bankName: '',
    bankAddress: '',
    accountNumberOrIban: '',
    swiftBic: '',
    country: 'United Arab Emirates',
    currency: 'USD',
    notes: ''
  });

  // Domestic Transfer Form & Simulation States
  const [domRecipientName, setDomRecipientName] = useState('');
  const [domRecipientAccount, setDomRecipientAccount] = useState('');
  const [domBankName, setDomBankName] = useState('');
  const [domAmount, setDomAmount] = useState('');
  const [domCurrency, setDomCurrency] = useState('USD');
  const [domDescription, setDomDescription] = useState('');
  const [domReference, setDomReference] = useState('');
  const [domStage, setDomStage] = useState<'form' | 'review' | 'processing' | 'failed'>('form');
  const [domTimer, setDomTimer] = useState(300); // 5 minutes (300s)
  const [domFailDetails, setDomFailDetails] = useState<{ reference: string; timestamp: string } | null>(null);

  // International Wire Form & Simulation States
  const [wireBeneficiaryName, setWireBeneficiaryName] = useState('');
  const [wireBankName, setWireBankName] = useState('');
  const [wireBankAddress, setWireBankAddress] = useState('');
  const [wireIban, setWireIban] = useState('');
  const [wireSwift, setWireSwift] = useState('');
  const [wireCountry, setWireCountry] = useState('United Arab Emirates');
  const [wireCurrency, setWireCurrency] = useState('USD');
  const [wireAmount, setWireAmount] = useState('');
  const [wirePurpose, setWirePurpose] = useState('');
  const [wireRemarks, setWireRemarks] = useState('');
  const [wireStage, setWireStage] = useState<'form' | 'review' | 'processing' | 'failed'>('form');
  const [wireTimer, setWireTimer] = useState(300); // 5 minutes (300s)
  const [wireFailDetails, setWireFailDetails] = useState<{ reference: string; timestamp: string } | null>(null);

  // Statements Date Range Filter
  const [stmtStartDate, setStmtStartDate] = useState('2025-01-01');
  const [stmtEndDate, setStmtEndDate] = useState('2026-11-03');
  const [generatedStatement, setGeneratedStatement] = useState<TransactionRecord[] | null>(null);

  // Load live data from shared database
  const loadData = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [accRes, txRes, benRes, notifRes] = await Promise.all([
        api.getAccount(),
        api.getTransactions({ limit: 120 }),
        api.getBeneficiaries(),
        api.getNotifications()
      ]);

      setProfile(accRes.profile);
      setBalances(accRes.balances);
      setTransactions(txRes.items);
      setBeneficiaries(benRes.items);
      setNotifications(notifRes.items);
    } catch (err) {
      console.error('Failed to load shared visitor data:', err);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // Poll every 10s to ensure real-time synchronization with Administrator updates
    const interval = setInterval(() => loadData(true), 10000);
    return () => clearInterval(interval);
  }, []);

  // 5-Minute Domestic Transfer Processing Timer
  useEffect(() => {
    if (domStage !== 'processing') return;

    const timer = setInterval(() => {
      setDomTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          triggerDomesticFailure();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [domStage]);

  const triggerDomesticFailure = () => {
    setDomFailDetails({
      reference: `LHT-DOM-FAIL-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: new Date().toISOString()
    });
    setDomStage('failed');
  };

  // 5-Minute International Wire Processing Timer
  useEffect(() => {
    if (wireStage !== 'processing') return;

    const timer = setInterval(() => {
      setWireTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          triggerWireFailure();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [wireStage]);

  const triggerWireFailure = () => {
    setWireFailDetails({
      reference: `LHT-WIRE-FAIL-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: new Date().toISOString()
    });
    setWireStage('failed');
  };

  // Beneficiary Management Handlers
  const handleSaveBeneficiary = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingBen) {
        await api.updateBeneficiary(editingBen.id, benFormData);
      } else {
        await api.addBeneficiary(benFormData);
      }
      setNewBenModalOpen(false);
      setEditingBen(null);
      setBenFormData({
        fullName: '',
        bankName: '',
        bankAddress: '',
        accountNumberOrIban: '',
        swiftBic: '',
        country: 'United Arab Emirates',
        currency: 'USD',
        notes: ''
      });
      loadData(true);
    } catch (err) {
      alert('Failed to save beneficiary.');
    }
  };

  const handleDeleteBeneficiary = async (id: string, name: string) => {
    if (!window.confirm(`Remove demonstration beneficiary ${name}?`)) return;
    try {
      await api.deleteBeneficiary(id);
      loadData(true);
    } catch (err) {
      alert('Failed to remove beneficiary.');
    }
  };

  const handleMarkNotifRead = async (id: string) => {
    await api.markNotificationRead(id);
    loadData(true);
  };

  // Generate Statement
  const handleGenerateStatement = () => {
    const filtered = transactions.filter(
      (t) => t.date >= stmtStartDate && t.date <= stmtEndDate
    );
    setGeneratedStatement(filtered);
  };

  // Filtered transactions for Transaction History tab
  const filteredTransactions = transactions.filter((t) => {
    const matchesSearch =
      t.description.toLowerCase().includes(txSearch.toLowerCase()) ||
      t.reference.toLowerCase().includes(txSearch.toLowerCase()) ||
      t.category.toLowerCase().includes(txSearch.toLowerCase());
    const matchesType = txTypeFilter === 'all' || t.type === txTypeFilter;
    const matchesStatus = txStatusFilter === 'all' || t.status === txStatusFilter;
    const matchesStart = !txStartDate || t.date >= txStartDate;
    const matchesEnd = !txEndDate || t.date <= txEndDate;
    return matchesSearch && matchesType && matchesStatus && matchesStart && matchesEnd;
  });

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage) || 1;
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Compute calculated statistics for overview
  const totalDeposits = transactions
    .filter((t) => t.type === 'deposit' || t.type === 'transfer_in')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalWithdrawals = transactions
    .filter((t) => t.type === 'withdrawal' || t.type === 'payment')
    .reduce((sum, t) => sum + t.amount, 0);

  const countriesList = [
    'United Arab Emirates (Dubai / Abu Dhabi)',
    'Saudi Arabia',
    'Oman',
    'Kuwait',
    'Qatar',
    'Bahrain',
    'United Kingdom',
    'Switzerland',
    'United States',
    'Singapore',
    'Germany',
    'Luxembourg'
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#0D192B] flex flex-col">
      {/* Top Demonstration Watermark Ribbon */}
      <div className="bg-[#08142C] text-[#C5A059] text-xs py-1.5 px-4 flex items-center justify-between border-b border-[#C5A059]/30">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 text-[#DFC076]" />
          <span className="font-semibold uppercase tracking-wider text-[11px]">
            Private Banking Demonstration Environment (Visitor Mode)
          </span>
        </div>
        <div className="flex items-center gap-4 text-[11px] text-stone-300">
          <span>Auth Code: EBSN98765</span>
          <span>•</span>
          <span className="text-[#DFC076]">Demonstration Balances Active</span>
        </div>
      </div>

      {/* Main Visitor Navigation Header */}
      <header className="bg-[#0B1B3D] border-b border-[#C5A059]/30 text-white sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src={BRAND_ASSETS.logo}
              alt="Litchfield Heritage Trust"
              className="h-11 w-auto object-contain bg-white/10 p-1 rounded border border-[#C5A059]/30"
            />
            <div className="hidden sm:block">
              <h1 className="font-serif text-lg font-medium text-white leading-none">
                Litchfield Heritage Trust
              </h1>
              <p className="text-[10px] text-[#C5A059] tracking-widest uppercase mt-0.5">
                Private Wealth & Discretionary Banking
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Balance Visibility Toggle */}
            <button
              onClick={() => setBalancesVisible(!balancesVisible)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-stone-200 text-xs rounded transition-colors cursor-pointer"
              title="Toggle financial figures visibility"
            >
              {balancesVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{balancesVisible ? 'Hide Balances' : 'Show Balances'}</span>
            </button>

            {/* Notifications Indicator */}
            <button
              onClick={() => setActiveTab('notifications')}
              className="relative p-2 text-stone-300 hover:text-white transition-colors cursor-pointer"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {notifications.some((n) => !n.isRead) && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#C5A059]" />
              )}
            </button>

            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#C5A059] hover:bg-[#b88d36] text-[#0B1B3D] text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-stone-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Desktop Tab Rail (10 Core Navigation Tabs) */}
        <div className="hidden lg:flex max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-x-auto border-t border-white/10">
          {[
            { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'accounts', label: 'My Accounts', icon: Wallet },
            { id: 'transactions', label: 'Transaction History', icon: Receipt },
            { id: 'domestic', label: 'Domestic Transfers', icon: ArrowRightLeft },
            { id: 'international', label: 'International Wire', icon: Globe },
            { id: 'beneficiaries', label: 'Beneficiaries', icon: Users },
            { id: 'statements', label: 'Statements', icon: FileText },
            { id: 'details', label: 'Account Details', icon: ShieldCheck },
            { id: 'notifications', label: 'Notifications', icon: Bell },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as VisitorTab)}
                className={`flex items-center gap-2 py-3 px-3 text-xs font-medium tracking-wide border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'border-[#C5A059] text-[#DFC076] bg-white/5'
                    : 'border-transparent text-stone-300 hover:text-white hover:border-[#C5A059]/40'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#08142C] border-b border-[#C5A059]/30 p-4 space-y-2 text-white">
          {[
            { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'accounts', label: 'My Accounts', icon: Wallet },
            { id: 'transactions', label: 'Transaction History', icon: Receipt },
            { id: 'domestic', label: 'Domestic Transfers', icon: ArrowRightLeft },
            { id: 'international', label: 'International Wire', icon: Globe },
            { id: 'beneficiaries', label: 'Beneficiaries', icon: Users },
            { id: 'statements', label: 'Statements', icon: FileText },
            { id: 'details', label: 'Account Details', icon: ShieldCheck },
            { id: 'notifications', label: 'Notifications', icon: Bell },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as VisitorTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded text-xs text-left ${
                  active ? 'bg-[#102A5C] text-[#DFC076] font-semibold' : 'text-stone-300 hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4 text-[#C5A059]" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* MAIN VISITOR WORKSPACE */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {loading ? (
          <div className="py-20 text-center space-y-4">
            <div className="w-10 h-10 border-4 border-[#C5A059] border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-stone-500 uppercase tracking-widest font-mono">
              Loading Fiduciary Portfolio Records...
            </p>
          </div>
        ) : (
          <>
            {/* 1. VISITOR OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div className="space-y-8 animate-fadeIn">
                {/* Account Header Identification */}
                <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <div className="text-xs font-semibold text-[#B88D36] uppercase tracking-widest">
                      Designated Demonstration Trust
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-serif font-semibold text-[#0B1B3D] mt-1">
                      {profile?.accountHolderName || 'Aurelian House Heritage Trust'}
                    </h2>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 mt-2">
                      <span>Account: <strong className="font-mono text-stone-800">{profile?.accountNumber}</strong></span>
                      <span>·</span>
                      <span>Classification: <strong className="text-stone-800">{profile?.accountType}</strong></span>
                      <span>·</span>
                      <span>Status: <strong className="text-emerald-700">{profile?.status}</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setActiveTab('domestic')}
                      className="px-4 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-2"
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                      <span>Domestic Transfer</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('international')}
                      className="px-4 py-2.5 bg-[#C5A059] hover:bg-[#b88d36] text-[#0B1B3D] text-xs font-bold rounded uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-2"
                    >
                      <Globe className="w-4 h-4" />
                      <span>International Wire</span>
                    </button>
                  </div>
                </div>

                {/* CRITICAL SEPARATE FINANCIAL FIGURES: CURRENT BALANCE vs AVAILABLE DISCRETIONARY LIQUIDITY */}
                {/* STRICT MANDATE: MUST ALWAYS BE SEPARATE FIGURES WITH SEPARATE LABELS. NEVER MERGE THEM. */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Current Balance Display */}
                  <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm relative overflow-hidden">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">
                        Current Balance (Demonstration Display)
                      </span>
                      <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-stone-100 text-stone-600 rounded">
                        USD Currency
                      </span>
                    </div>
                    <div className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B1B3D] tabular-nums tracking-tight">
                      {balancesVisible
                        ? `$${balances?.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                        : '••••••••••••'}
                    </div>
                    <div className="mt-4 pt-4 border-t border-stone-100 text-xs text-stone-500 flex items-center justify-between">
                      <span>Synchronized institutional ledger</span>
                      <button
                        onClick={() => setActiveTab('transactions')}
                        className="text-[#B88D36] font-semibold hover:underline"
                      >
                        Inspect Transactions →
                      </button>
                    </div>
                  </div>

                  {/* Available Discretionary Liquidity Display */}
                  <div className="bg-[#0B1B3D] text-white p-6 sm:p-8 rounded-lg border border-[#C5A059]/40 shadow-sm relative overflow-hidden">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold uppercase tracking-wider text-[#DFC076]">
                        Available Discretionary Liquidity
                      </span>
                      <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-[#102A5C] text-[#DFC076] rounded">
                        Discretionary Facility
                      </span>
                    </div>
                    <div className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#DFC076] tabular-nums tracking-tight">
                      {balancesVisible
                        ? `$${balances?.availableDiscretionaryLiquidity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                        : '••••••••••••'}
                    </div>
                    <div className="mt-4 pt-4 border-t border-white/10 text-xs text-stone-300 flex items-center justify-between">
                      <span>Unencumbered immediate liquidity buffer</span>
                      <button
                        onClick={() => setActiveTab('details')}
                        className="text-[#DFC076] font-semibold hover:underline"
                      >
                        Facility Details →
                      </button>
                    </div>
                  </div>
                </div>

                {/* Secondary Financial KPI Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm space-y-1">
                    <div className="text-[11px] uppercase tracking-wider text-stone-500">
                      Total Demonstration Deposits
                    </div>
                    <div className="text-lg font-bold text-emerald-700 font-mono tabular-nums">
                      {balancesVisible
                        ? `+$${totalDeposits.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                        : '••••••'}
                    </div>
                    <div className="text-[10px] text-stone-400">Cumulative demonstration inflows</div>
                  </div>

                  <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm space-y-1">
                    <div className="text-[11px] uppercase tracking-wider text-stone-500">
                      Total Demonstration Withdrawals
                    </div>
                    <div className="text-lg font-bold text-rose-700 font-mono tabular-nums">
                      {balancesVisible
                        ? `-$${totalWithdrawals.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
                        : '••••••'}
                    </div>
                    <div className="text-[10px] text-stone-400">6 planned fiduciary outlays</div>
                  </div>

                  <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm space-y-1">
                    <div className="text-[11px] uppercase tracking-wider text-stone-500">
                      Demonstration Beneficiaries
                    </div>
                    <div className="text-lg font-bold text-[#0B1B3D] font-mono tabular-nums">
                      {beneficiaries.length} Verified
                    </div>
                    <div className="text-[10px] text-stone-400">UAE, Swiss, UK, Saudi repositories</div>
                  </div>

                  <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm space-y-1">
                    <div className="text-[11px] uppercase tracking-wider text-stone-500">
                      Ledger Integrity
                    </div>
                    <div className="text-lg font-bold text-emerald-700 font-mono tabular-nums">
                      100% Balanced
                    </div>
                    <div className="text-[10px] text-stone-400">Synchronized central database</div>
                  </div>
                </div>

                {/* Recent Demonstration Activity Table */}
                <div className="bg-white rounded-lg border border-stone-200 p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-serif text-lg font-semibold text-[#0B1B3D]">
                        Recent Demonstration Transactions
                      </h3>
                      <p className="text-xs text-stone-500">
                        Demonstration ledger records covering Jan 2020 through Nov 2026.
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab('transactions')}
                      className="text-xs text-[#B88D36] font-semibold hover:underline"
                    >
                      View All {transactions.length} Records →
                    </button>
                  </div>

                  {/* Desktop Table View */}
                  <div className="hidden md:block overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-stone-50 text-stone-600 uppercase tracking-wider text-[10px]">
                        <tr>
                          <th className="py-2.5 px-3">Date</th>
                          <th className="py-2.5 px-3">Reference</th>
                          <th className="py-2.5 px-3">Description</th>
                          <th className="py-2.5 px-3">Category</th>
                          <th className="py-2.5 px-3 text-right">Amount (USD)</th>
                          <th className="py-2.5 px-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        {transactions.slice(0, 6).map((t) => (
                          <tr
                            key={t.id}
                            onClick={() => setSelectedTx(t)}
                            className="hover:bg-stone-50/70 transition-colors cursor-pointer"
                          >
                            <td className="py-2.5 px-3 whitespace-nowrap text-stone-600 font-mono text-[11px]">{t.date}</td>
                            <td className="py-2.5 px-3 font-mono text-stone-500 text-[11px]">{t.reference}</td>
                            <td className="py-2.5 px-3 font-medium text-stone-900">{t.description}</td>
                            <td className="py-2.5 px-3 text-stone-500">{t.category}</td>
                            <td
                              className={`py-2.5 px-3 text-right font-mono font-semibold tabular-nums ${
                                t.type === 'withdrawal' || t.type === 'payment'
                                  ? 'text-rose-700'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {t.type === 'withdrawal' || t.type === 'payment' ? '-' : '+'}
                              ${t.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="text-[10px] font-medium text-stone-600 px-1.5 py-0.5 bg-stone-100 rounded">
                                {t.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Mobile Activity Card List (No Horizontal Scroll as required) */}
                  <div className="md:hidden space-y-3">
                    {transactions.slice(0, 5).map((t) => (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTx(t)}
                        className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 space-y-2 cursor-pointer"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-mono text-stone-500 text-[11px]">{t.date}</span>
                          <span className="text-[10px] font-medium px-1.5 py-0.5 bg-white border border-stone-200 rounded text-stone-600">
                            {t.status}
                          </span>
                        </div>
                        <div className="font-medium text-stone-900 text-xs">{t.description}</div>
                        <div className="flex items-center justify-between pt-1 border-t border-stone-200/60">
                          <span className="text-[10px] text-stone-500 font-mono">{t.reference}</span>
                          <span
                            className={`font-mono font-semibold text-xs tabular-nums ${
                              t.type === 'withdrawal' || t.type === 'payment'
                                ? 'text-rose-700'
                                : 'text-emerald-700'
                            }`}
                          >
                            {t.type === 'withdrawal' || t.type === 'payment' ? '-' : '+'}
                            ${t.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 2. MY ACCOUNTS TAB */}
            {activeTab === 'accounts' && (
              <div className="space-y-6 animate-fadeIn">
                <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                      Institutional Custody
                    </span>
                    <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                      My Segregated Accounts
                    </h2>
                    <p className="text-xs text-stone-500">
                      Overview of designated wealth repositories under the Litchfield Heritage Trust master covenant.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Primary Reserve Account Card */}
                    <div className="p-6 rounded-lg bg-stone-50 border border-stone-200 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold uppercase tracking-wider text-[#0B1B3D]">
                          Primary Capital Reserve
                        </span>
                        <span className="text-[10px] px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-medium">
                          Active Custody
                        </span>
                      </div>
                      <div className="text-xs text-stone-500 font-mono">
                        Account No: {profile?.accountNumber}
                      </div>
                      <div className="space-y-1">
                        <span className="text-[11px] text-stone-500 uppercase font-semibold">Current Balance</span>
                        <div className="font-serif text-2xl font-bold text-[#0B1B3D] tabular-nums">
                          ${balances?.currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div className="pt-3 border-t border-stone-200 text-xs text-stone-600 space-y-1">
                        <div>Jurisdiction: <span className="font-medium text-stone-800">Master Institutional Trust</span></div>
                        <div>Currency: <span className="font-mono text-stone-800">USD</span></div>
                        <div>Routing: <span className="font-mono text-stone-800">{profile?.routingNumber}</span></div>
                      </div>
                    </div>

                    {/* Discretionary Liquidity Sub-Facility Card */}
                    <div className="p-6 rounded-lg bg-[#0B1B3D] text-white border border-[#C5A059]/40 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold uppercase tracking-wider text-[#DFC076]">
                          Discretionary Liquidity Facility
                        </span>
                        <span className="text-[10px] px-2 py-0.5 bg-[#102A5C] text-[#DFC076] rounded font-medium">
                          Unencumbered
                        </span>
                      </div>
                      <div className="text-xs text-stone-400 font-mono">
                        Facility ID: LHT-FAC-LIQ-0992
                      </div>
                      <div className="space-y-1">
                        <span className="text-[11px] text-stone-300 uppercase font-semibold">Available Liquidity</span>
                        <div className="font-serif text-2xl font-bold text-[#DFC076] tabular-nums">
                          ${balances?.availableDiscretionaryLiquidity.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </div>
                      </div>
                      <div className="pt-3 border-t border-white/10 text-xs text-stone-300 space-y-1">
                        <div>Facility Mandate: <span className="font-medium text-white">Discretionary Drawdown Reserve</span></div>
                        <div>Settlement Speed: <span className="text-[#DFC076]">Immediate Clearing Demonstration</span></div>
                        <div>Supervisory Desk: <span className="text-stone-300">Treasury & Risk Desk</span></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. TRANSACTION HISTORY (APPROXIMATELY 100 RECORDS, JAN 2020 - NOV 2026) */}
            {activeTab === 'transactions' && (
              <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Historical Ledger
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    Demonstration Transaction History
                  </h2>
                  <p className="text-xs text-stone-500">
                    Displaying ~100 demonstration transaction records from January 2020 through November 2026. All figures are simulated.
                  </p>
                </div>

                {/* Filter Toolbar */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
                  <div className="lg:col-span-2 relative">
                    <input
                      type="text"
                      value={txSearch}
                      onChange={(e) => {
                        setTxSearch(e.target.value);
                        setCurrentPage(1);
                      }}
                      placeholder="Search description, reference, category..."
                      className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    />
                    <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  </div>

                  <div>
                    <select
                      value={txTypeFilter}
                      onChange={(e) => {
                        setTxTypeFilter(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                    >
                      <option value="all">All Types</option>
                      <option value="deposit">Deposits</option>
                      <option value="withdrawal">Withdrawals</option>
                      <option value="transfer_in">Transfers In</option>
                      <option value="transfer_out">Transfers Out</option>
                      <option value="payment">Payments</option>
                      <option value="adjustment">Adjustments</option>
                    </select>
                  </div>

                  <div>
                    <input
                      type="date"
                      value={txStartDate}
                      onChange={(e) => {
                        setTxStartDate(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="w-full px-2.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none text-stone-600"
                      title="Start Date"
                    />
                  </div>

                  <div>
                    <input
                      type="date"
                      value={txEndDate}
                      onChange={(e) => {
                        setTxEndDate(e.target.value);
                        setCurrentPage(1);
                      }}
                      className="w-full px-2.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:outline-none text-stone-600"
                      title="End Date"
                    />
                  </div>
                </div>

                {/* Table View (Desktop) */}
                <div className="hidden md:block overflow-x-auto border border-stone-200 rounded-lg">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-stone-50 text-stone-600 uppercase tracking-wider text-[11px] border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-3">Date</th>
                        <th className="py-3 px-3">Reference</th>
                        <th className="py-3 px-3">Description</th>
                        <th className="py-3 px-3">Category</th>
                        <th className="py-3 px-3">Type</th>
                        <th className="py-3 px-3 text-right">Amount (USD)</th>
                        <th className="py-3 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {paginatedTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-stone-400">
                            No matching demonstration transactions in this filter criteria.
                          </td>
                        </tr>
                      ) : (
                        paginatedTransactions.map((tx) => (
                          <tr
                            key={tx.id}
                            onClick={() => setSelectedTx(tx)}
                            className="hover:bg-stone-50/80 transition-colors cursor-pointer"
                          >
                            <td className="py-2.5 px-3 whitespace-nowrap text-stone-600 font-mono text-[11px]">{tx.date}</td>
                            <td className="py-2.5 px-3 font-mono text-stone-500 text-[11px]">{tx.reference}</td>
                            <td className="py-2.5 px-3 font-medium text-stone-900 max-w-xs truncate">{tx.description}</td>
                            <td className="py-2.5 px-3 text-stone-500">{tx.category}</td>
                            <td className="py-2.5 px-3 capitalize text-stone-600 text-[11px]">{tx.type.replace('_', ' ')}</td>
                            <td
                              className={`py-2.5 px-3 text-right font-mono font-semibold tabular-nums ${
                                tx.type === 'withdrawal' || tx.type === 'payment'
                                  ? 'text-rose-700'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {tx.type === 'withdrawal' || tx.type === 'payment' ? '-' : '+'}
                              ${tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="text-[10px] font-medium text-stone-600 px-1.5 py-0.5 bg-stone-100 rounded">
                                {tx.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Mobile View (Card List) */}
                <div className="md:hidden space-y-3">
                  {paginatedTransactions.map((tx) => (
                    <div
                      key={tx.id}
                      onClick={() => setSelectedTx(tx)}
                      className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 space-y-2 cursor-pointer"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono text-stone-500 text-[11px]">{tx.date}</span>
                        <span className="text-[10px] font-medium px-1.5 py-0.5 bg-white border border-stone-200 rounded text-stone-600">
                          {tx.status}
                        </span>
                      </div>
                      <div className="font-medium text-stone-900 text-xs">{tx.description}</div>
                      <div className="flex items-center justify-between text-[11px] text-stone-500">
                        <span>Category: {tx.category}</span>
                        <span className="capitalize">{tx.type.replace('_', ' ')}</span>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-stone-200/60">
                        <span className="text-[10px] text-stone-400 font-mono">{tx.reference}</span>
                        <span
                          className={`font-mono font-semibold text-xs tabular-nums ${
                            tx.type === 'withdrawal' || tx.type === 'payment'
                              ? 'text-rose-700'
                              : 'text-emerald-700'
                          }`}
                        >
                          {tx.type === 'withdrawal' || tx.type === 'payment' ? '-' : '+'}
                          ${tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination Controls */}
                <div className="flex items-center justify-between pt-4 border-t border-stone-200 text-xs text-stone-600">
                  <div>
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{' '}
                    {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} of {filteredTransactions.length} records
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-1 bg-stone-100 hover:bg-stone-200 rounded disabled:opacity-40 cursor-pointer"
                    >
                      Previous
                    </button>
                    <span className="font-mono">
                      {currentPage} / {totalPages}
                    </span>
                    <button
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1 bg-stone-100 hover:bg-stone-200 rounded disabled:opacity-40 cursor-pointer"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 4. DOMESTIC TRANSFERS (STRICT PROTOCOL: 5-MIN SIMULATION -> TRANSACTION FAILED) */}
            {activeTab === 'domestic' && (
              <div className="max-w-2xl mx-auto bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Domestic Clearing Facility
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    Domestic Fund Transfer Demonstration
                  </h2>
                  <p className="text-xs text-stone-500">
                    Execute a simulated domestic transfer. All operations in this environment are for institutional demonstration.
                  </p>
                </div>

                {/* Stage 1: Form */}
                {domStage === 'form' && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      setDomStage('review');
                    }}
                    className="space-y-4"
                  >
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Recipient Full Name *</label>
                      <input
                        type="text"
                        required
                        value={domRecipientName}
                        onChange={(e) => setDomRecipientName(e.target.value)}
                        placeholder="e.g. Lord Sterling Fiduciary Trust"
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Recipient Account Number *</label>
                        <input
                          type="text"
                          required
                          value={domRecipientAccount}
                          onChange={(e) => setDomRecipientAccount(e.target.value)}
                          placeholder="e.g. 02100008912345"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Receiving Institution *</label>
                        <input
                          type="text"
                          required
                          value={domBankName}
                          onChange={(e) => setDomBankName(e.target.value)}
                          placeholder="e.g. JPMorgan Chase Institutional"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Transfer Amount ($ USD) *</label>
                        <input
                          type="number"
                          step="0.01"
                          max="300000"
                          required
                          value={domAmount}
                          onChange={(e) => setDomAmount(e.target.value)}
                          placeholder="e.g. 75000.00"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Currency</label>
                        <input
                          type="text"
                          disabled
                          value="USD - United States Dollar"
                          className="w-full px-3.5 py-2 text-xs bg-stone-100 border border-stone-300 rounded font-mono text-stone-600"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Payment Description *</label>
                      <input
                        type="text"
                        required
                        value={domDescription}
                        onChange={(e) => setDomDescription(e.target.value)}
                        placeholder="e.g. Quarterly Advisory Fee Settlement"
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Reference or Remarks</label>
                      <input
                        type="text"
                        value={domReference}
                        onChange={(e) => setDomReference(e.target.value)}
                        placeholder="Optional internal remarks"
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                      />
                    </div>

                    <div className="pt-4 border-t border-stone-200 flex justify-end">
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors cursor-pointer"
                      >
                        Review Transfer Summary →
                      </button>
                    </div>
                  </form>
                )}

                {/* Stage 2: Review Screen */}
                {domStage === 'review' && (
                  <div className="space-y-5 animate-fadeIn">
                    <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-3 text-xs">
                      <h3 className="font-serif font-semibold text-stone-800 text-sm">
                        Transfer Summary & Review
                      </h3>
                      <div className="grid grid-cols-2 gap-2 text-stone-600">
                        <div>Recipient Name:</div>
                        <div className="font-semibold text-stone-900">{domRecipientName}</div>

                        <div>Account Number:</div>
                        <div className="font-mono text-stone-900">{domRecipientAccount}</div>

                        <div>Receiving Institution:</div>
                        <div className="font-semibold text-stone-900">{domBankName}</div>

                        <div>Amount:</div>
                        <div className="font-mono font-bold text-stone-900">${parseFloat(domAmount).toLocaleString()} USD</div>

                        <div>Description:</div>
                        <div className="text-stone-900">{domDescription}</div>
                      </div>
                    </div>

                    <div className="p-3 bg-amber-50 rounded border border-amber-200 text-[11px] text-amber-800">
                      <strong>Demonstration Environment Notice:</strong> Submitting will initiate a simulated 5-minute
                      clearing presentation. Real transfers are disabled; no actual funds will be transferred.
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <button
                        type="button"
                        onClick={() => setDomStage('form')}
                        className="px-4 py-2 text-xs text-stone-600 hover:text-stone-900"
                      >
                        ← Modify Details
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setDomStage('processing');
                          setDomTimer(300); // 5 minutes
                        }}
                        className="px-6 py-2.5 bg-[#0B1B3D] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded"
                      >
                        Confirm & Submit Transfer
                      </button>
                    </div>
                  </div>
                )}

                {/* Stage 3: 5-Minute Demonstration Processing Presentation */}
                {domStage === 'processing' && (
                  <div className="py-12 px-6 text-center space-y-6 bg-[#0B1B3D] text-white rounded-lg border border-[#C5A059]/40 animate-fadeIn">
                    <div className="flex justify-center">
                      <img
                        src={BRAND_ASSETS.logo}
                        alt="LHT"
                        className="h-12 w-auto bg-white/10 p-1.5 rounded border border-[#C5A059]/30"
                      />
                    </div>

                    <div className="space-y-1">
                      <h3 className="font-serif text-xl font-medium text-[#DFC076]">
                        Transfer Processing Simulation
                      </h3>
                      <p className="text-xs text-stone-300">
                        Simulating domestic ACH / wire routing sequence through correspondent depository...
                      </p>
                    </div>

                    {/* Circular Animated Dots (No numbers inside dots as instructed) */}
                    <div className="flex items-center justify-center gap-3 my-4">
                      <div className="w-3.5 h-3.5 rounded-full bg-[#C5A059] animate-bounce [animation-delay:0ms]" />
                      <div className="w-3.5 h-3.5 rounded-full bg-[#DFC076] animate-bounce [animation-delay:150ms]" />
                      <div className="w-3.5 h-3.5 rounded-full bg-stone-300 animate-bounce [animation-delay:300ms]" />
                      <div className="w-3.5 h-3.5 rounded-full bg-[#C5A059] animate-bounce [animation-delay:450ms]" />
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-mono text-stone-300 tabular-nums">
                        Demonstration Timer: {Math.floor(domTimer / 60)}m {domTimer % 60}s remaining
                      </div>
                      <p className="text-[11px] text-stone-400 italic">
                        Clearly stated: This processing display is strictly simulated. No actual banking network processing occurs.
                      </p>
                    </div>

                    {/* Accelerate demonstration button for evaluator convenience */}
                    <div className="pt-4 border-t border-white/10 flex justify-center">
                      <button
                        type="button"
                        onClick={triggerDomesticFailure}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-[#DFC076] text-xs font-medium rounded transition-colors"
                      >
                        <FastForward className="w-3.5 h-3.5" />
                        <span>Accelerate Demonstration (Conclude Simulation)</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Stage 4: Transaction Failed (EXACT REQUIRED TERMINOLOGY) */}
                {domStage === 'failed' && (
                  <div className="p-8 bg-rose-50 rounded-lg border border-rose-200 space-y-6 text-center animate-fadeIn">
                    <XCircle className="w-12 h-12 text-rose-600 mx-auto" />
                    <div>
                      {/* Heading strictly as specified */}
                      <h3 className="font-serif text-2xl font-bold text-rose-900">
                        Transaction Failed
                      </h3>
                      {/* Exact text strictly as specified */}
                      <p className="text-sm text-stone-800 max-w-md mx-auto mt-2 leading-relaxed font-medium">
                        Your transfer could not be completed in this demonstration environment. No funds have been transferred or deducted from your displayed account balance.
                      </p>
                    </div>

                    <div className="bg-white p-4 rounded border border-rose-200 max-w-sm mx-auto text-xs text-left space-y-1.5 font-mono">
                      <div>
                        <span className="text-stone-500">Demonstration Reference:</span>{' '}
                        <strong className="text-stone-800">{domFailDetails?.reference}</strong>
                      </div>
                      <div>
                        <span className="text-stone-500">Timestamp:</span>{' '}
                        <strong className="text-stone-800">{new Date(domFailDetails?.timestamp || '').toLocaleString()}</strong>
                      </div>
                      <div className="text-[11px] text-stone-500 font-sans pt-1">
                        <strong>Reason:</strong> Fiduciary demonstration environment safety protocol active. Real banking transactions are strictly prohibited.
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-4 pt-2">
                      <button
                        onClick={() => {
                          setDomStage('form');
                          setDomAmount('');
                          setDomRecipientName('');
                        }}
                        className="px-5 py-2.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold rounded uppercase tracking-wider"
                      >
                        Try Again
                      </button>
                      <button
                        onClick={() => setActiveTab('overview')}
                        className="px-5 py-2.5 bg-[#0B1B3D] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded"
                      >
                        Return to Dashboard
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 5. INTERNATIONAL WIRE TRANSFERS (STRICT PROTOCOL: 5-MIN SIMULATION -> TRANSACTION FAILED) */}
            {activeTab === 'international' && (
              <div className="max-w-2xl mx-auto bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Global Settlement Facility
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    International Wire Transfer Demonstration
                  </h2>
                  <p className="text-xs text-stone-500">
                    Searchable cross-border wire demonstration. Covers UAE (Dubai / Abu Dhabi), Saudi Arabia, Oman, Qatar, Kuwait, Bahrain, and global destinations.
                  </p>
                </div>

                {/* Form Stage */}
                {wireStage === 'form' && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      setWireStage('review');
                    }}
                    className="space-y-4"
                  >
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Beneficiary Full Legal Name *</label>
                      <input
                        type="text"
                        required
                        value={wireBeneficiaryName}
                        onChange={(e) => setWireBeneficiaryName(e.target.value)}
                        placeholder="e.g. Aurelian Middle East Fiduciary S.P.C."
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Beneficiary Bank Name *</label>
                        <input
                          type="text"
                          required
                          value={wireBankName}
                          onChange={(e) => setWireBankName(e.target.value)}
                          placeholder="e.g. Emirates NBD Bank PJSC"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Bank City & Address *</label>
                        <input
                          type="text"
                          required
                          value={wireBankAddress}
                          onChange={(e) => setWireBankAddress(e.target.value)}
                          placeholder="e.g. Baniyas Road, Deira, Dubai, UAE"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Account Number or IBAN *</label>
                        <input
                          type="text"
                          required
                          value={wireIban}
                          onChange={(e) => setWireIban(e.target.value)}
                          placeholder="e.g. AE290260001001234567890"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">SWIFT / BIC Code *</label>
                        <input
                          type="text"
                          required
                          value={wireSwift}
                          onChange={(e) => setWireSwift(e.target.value)}
                          placeholder="e.g. EBILAEADXXX"
                          className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono uppercase"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Destination Country *</label>
                        <select
                          value={wireCountry}
                          onChange={(e) => setWireCountry(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                        >
                          {countriesList.map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-semibold text-stone-700 uppercase">Transfer Currency *</label>
                        <select
                          value={wireCurrency}
                          onChange={(e) => setWireCurrency(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                        >
                          <option value="USD">USD - US Dollar</option>
                          <option value="AED">AED - UAE Dirham</option>
                          <option value="SAR">SAR - Saudi Riyal</option>
                          <option value="OMR">OMR - Omani Rial</option>
                          <option value="KWD">KWD - Kuwaiti Dinar</option>
                          <option value="QAR">QAR - Qatari Riyal</option>
                          <option value="BHD">BHD - Bahraini Dinar</option>
                          <option value="GBP">GBP - British Pound</option>
                          <option value="EUR">EUR - Euro</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Wire Amount * (Max $300,000 equiv)</label>
                      <input
                        type="number"
                        step="0.01"
                        max="300000"
                        required
                        value={wireAmount}
                        onChange={(e) => setWireAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Payment Purpose *</label>
                      <input
                        type="text"
                        required
                        value={wirePurpose}
                        onChange={(e) => setWirePurpose(e.target.value)}
                        placeholder="e.g. Fiduciary Custodial Management Deposit"
                        className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded focus:border-[#C5A059] focus:outline-none"
                      />
                    </div>

                    <div className="pt-4 border-t border-stone-200 flex justify-end">
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors cursor-pointer"
                      >
                        Review Wire Summary →
                      </button>
                    </div>
                  </form>
                )}

                {/* Review Stage */}
                {wireStage === 'review' && (
                  <div className="space-y-5 animate-fadeIn">
                    <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 space-y-3 text-xs">
                      <h3 className="font-serif font-semibold text-stone-800 text-sm">
                        International Wire Transfer Summary
                      </h3>
                      <div className="grid grid-cols-2 gap-2 text-stone-600">
                        <div>Beneficiary:</div>
                        <div className="font-semibold text-stone-900">{wireBeneficiaryName}</div>

                        <div>Bank & Address:</div>
                        <div className="text-stone-900">{wireBankName}, {wireBankAddress}</div>

                        <div>IBAN / Account:</div>
                        <div className="font-mono text-stone-900">{wireIban}</div>

                        <div>SWIFT / BIC:</div>
                        <div className="font-mono text-stone-900">{wireSwift}</div>

                        <div>Country:</div>
                        <div className="text-stone-900">{wireCountry}</div>

                        <div>Amount:</div>
                        <div className="font-mono font-bold text-stone-900">
                          {parseFloat(wireAmount).toLocaleString()} {wireCurrency}
                        </div>

                        <div>Purpose:</div>
                        <div className="text-stone-900">{wirePurpose}</div>
                      </div>
                    </div>

                    <div className="p-3 bg-amber-50 rounded border border-amber-200 text-[11px] text-amber-800">
                      <strong>Demonstration Environment Notice:</strong> International wire transfers are disabled in this
                      demonstration environment. No funds will be transferred and no live foreign-exchange or cross-border settlement exists.
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <button
                        type="button"
                        onClick={() => setWireStage('form')}
                        className="px-4 py-2 text-xs text-stone-600 hover:text-stone-900"
                      >
                        ← Modify Details
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setWireStage('processing');
                          setWireTimer(300); // 5 minutes
                        }}
                        className="px-6 py-2.5 bg-[#0B1B3D] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded"
                      >
                        Confirm & Transmit Wire
                      </button>
                    </div>
                  </div>
                )}

                {/* 5-Minute Processing Stage */}
                {wireStage === 'processing' && (
                  <div className="py-12 px-6 text-center space-y-6 bg-[#0B1B3D] text-white rounded-lg border border-[#C5A059]/40 animate-fadeIn">
                    <div className="flex justify-center">
                      <img
                        src={BRAND_ASSETS.logo}
                        alt="LHT"
                        className="h-12 w-auto bg-white/10 p-1.5 rounded border border-[#C5A059]/30"
                      />
                    </div>

                    <div className="space-y-1">
                      <h3 className="font-serif text-xl font-medium text-[#DFC076]">
                        International Wire Processing Simulation
                      </h3>
                      <p className="text-xs text-stone-300">
                        Initiating simulated correspondent SWIFT key exchange to {wireCountry}...
                      </p>
                    </div>

                    {/* Circular Animated Dots (No numbers inside dots) */}
                    <div className="flex items-center justify-center gap-3 my-4">
                      <div className="w-3.5 h-3.5 rounded-full bg-[#C5A059] animate-bounce [animation-delay:0ms]" />
                      <div className="w-3.5 h-3.5 rounded-full bg-[#DFC076] animate-bounce [animation-delay:150ms]" />
                      <div className="w-3.5 h-3.5 rounded-full bg-stone-300 animate-bounce [animation-delay:300ms]" />
                      <div className="w-3.5 h-3.5 rounded-full bg-[#C5A059] animate-bounce [animation-delay:450ms]" />
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-mono text-stone-300 tabular-nums">
                        Demonstration Timer: {Math.floor(wireTimer / 60)}m {wireTimer % 60}s remaining
                      </div>
                      <p className="text-[11px] text-stone-400 italic">
                        Clearly stated: This processing display is simulated. No actual wire instruction is transmitted.
                      </p>
                    </div>

                    <div className="pt-4 border-t border-white/10 flex justify-center">
                      <button
                        type="button"
                        onClick={triggerWireFailure}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-[#DFC076] text-xs font-medium rounded transition-colors"
                      >
                        <FastForward className="w-3.5 h-3.5" />
                        <span>Accelerate Demonstration (Conclude Simulation)</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Failed Result Screen (Exact wording) */}
                {wireStage === 'failed' && (
                  <div className="p-8 bg-rose-50 rounded-lg border border-rose-200 space-y-6 text-center animate-fadeIn">
                    <XCircle className="w-12 h-12 text-rose-600 mx-auto" />
                    <div>
                      <h3 className="font-serif text-2xl font-bold text-rose-900">
                        Transaction Failed
                      </h3>
                      <p className="text-sm text-stone-800 max-w-md mx-auto mt-2 leading-relaxed font-medium">
                        Your transfer could not be completed in this demonstration environment. No funds have been transferred or deducted from your displayed account balance.
                      </p>
                    </div>

                    <div className="bg-white p-4 rounded border border-rose-200 max-w-sm mx-auto text-xs text-left space-y-1.5 font-mono">
                      <div>
                        <span className="text-stone-500">Demonstration Reference:</span>{' '}
                        <strong className="text-stone-800">{wireFailDetails?.reference}</strong>
                      </div>
                      <div>
                        <span className="text-stone-500">Timestamp:</span>{' '}
                        <strong className="text-stone-800">{new Date(wireFailDetails?.timestamp || '').toLocaleString()}</strong>
                      </div>
                      <div className="text-[11px] text-stone-500 font-sans pt-1">
                        <strong>Explanation:</strong> International wire transfers are disabled in this demonstration environment. No funds have been transferred, no displayed balance has been deducted, and no actual wire instruction has been sent.
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-4 pt-2">
                      <button
                        onClick={() => {
                          setWireStage('form');
                          setWireAmount('');
                          setWireBeneficiaryName('');
                        }}
                        className="px-5 py-2.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold rounded uppercase tracking-wider"
                      >
                        Try Again
                      </button>
                      <button
                        onClick={() => setActiveTab('overview')}
                        className="px-5 py-2.5 bg-[#0B1B3D] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded"
                      >
                        Return to Dashboard
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 6. BENEFICIARIES MANAGEMENT */}
            {activeTab === 'beneficiaries' && (
              <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                      Fiduciary Payees
                    </span>
                    <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                      Permitted Demonstration Beneficiaries
                    </h2>
                    <p className="text-xs text-stone-500">
                      Manage registered demonstration beneficiaries. Adding a beneficiary does not enable real payments or transfers.
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      setEditingBen(null);
                      setBenFormData({
                        fullName: '',
                        bankName: '',
                        bankAddress: '',
                        accountNumberOrIban: '',
                        swiftBic: '',
                        country: 'United Arab Emirates',
                        currency: 'USD',
                        notes: ''
                      });
                      setNewBenModalOpen(true);
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors self-start sm:self-auto cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Demonstration Beneficiary</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  {beneficiaries.map((b) => (
                    <div key={b.id} className="p-5 bg-stone-50 rounded-lg border border-stone-200 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-serif font-semibold text-[#0B1B3D] text-base">{b.fullName}</h4>
                          <p className="text-xs text-stone-500">{b.bankName} · {b.country}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingBen(b);
                              setBenFormData({
                                fullName: b.fullName,
                                bankName: b.bankName,
                                bankAddress: b.bankAddress || '',
                                accountNumberOrIban: b.accountNumberOrIban,
                                swiftBic: b.swiftBic,
                                country: b.country,
                                currency: b.currency,
                                notes: b.notes || ''
                              });
                              setNewBenModalOpen(true);
                            }}
                            className="p-1 text-stone-400 hover:text-stone-800"
                            title="Edit"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteBeneficiary(b.id, b.fullName)}
                            className="p-1 text-stone-400 hover:text-rose-600"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-stone-200 text-xs space-y-1 font-mono text-stone-600">
                        <div>IBAN: <span className="text-stone-900 font-medium">{b.accountNumberOrIban}</span></div>
                        <div>SWIFT: <span className="text-stone-900 font-medium">{b.swiftBic}</span></div>
                        {b.notes && <div className="text-[11px] font-sans text-stone-500 italic mt-1">{b.notes}</div>}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Beneficiary Modal */}
                {newBenModalOpen && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                    <div className="bg-white rounded-lg p-6 max-w-lg w-full border border-stone-200 shadow-2xl space-y-4">
                      <div className="flex items-center justify-between border-b pb-3 border-stone-100">
                        <h3 className="font-serif text-lg font-semibold text-[#0B1B3D]">
                          {editingBen ? 'Edit Beneficiary Details' : 'Add Demonstration Beneficiary'}
                        </h3>
                        <button onClick={() => setNewBenModalOpen(false)} className="text-stone-400 hover:text-stone-700">
                          ✕
                        </button>
                      </div>

                      <form onSubmit={handleSaveBeneficiary} className="space-y-3.5 text-xs">
                        <div className="space-y-1">
                          <label className="font-semibold text-stone-700 uppercase">Beneficiary Legal Name *</label>
                          <input
                            type="text"
                            required
                            value={benFormData.fullName}
                            onChange={(e) => setBenFormData({ ...benFormData, fullName: e.target.value })}
                            className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="font-semibold text-stone-700 uppercase">Bank Name *</label>
                            <input
                              type="text"
                              required
                              value={benFormData.bankName}
                              onChange={(e) => setBenFormData({ ...benFormData, bankName: e.target.value })}
                              className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="font-semibold text-stone-700 uppercase">Destination Country *</label>
                            <select
                              value={benFormData.country}
                              onChange={(e) => setBenFormData({ ...benFormData, country: e.target.value })}
                              className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none"
                            >
                              {countriesList.map((c) => (
                                <option key={c} value={c}>{c}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="font-semibold text-stone-700 uppercase">IBAN / Account Number *</label>
                            <input
                              type="text"
                              required
                              value={benFormData.accountNumberOrIban}
                              onChange={(e) => setBenFormData({ ...benFormData, accountNumberOrIban: e.target.value })}
                              className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none font-mono"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="font-semibold text-stone-700 uppercase">SWIFT / BIC Code *</label>
                            <input
                              type="text"
                              required
                              value={benFormData.swiftBic}
                              onChange={(e) => setBenFormData({ ...benFormData, swiftBic: e.target.value })}
                              className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none font-mono uppercase"
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="font-semibold text-stone-700 uppercase">Bank Address</label>
                          <input
                            type="text"
                            value={benFormData.bankAddress}
                            onChange={(e) => setBenFormData({ ...benFormData, bankAddress: e.target.value })}
                            className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="font-semibold text-stone-700 uppercase">Fiduciary Remarks / Notes</label>
                          <input
                            type="text"
                            value={benFormData.notes}
                            onChange={(e) => setBenFormData({ ...benFormData, notes: e.target.value })}
                            className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded focus:outline-none"
                          />
                        </div>

                        <div className="pt-3 border-t border-stone-100 flex justify-end gap-3">
                          <button
                            type="button"
                            onClick={() => setNewBenModalOpen(false)}
                            className="px-4 py-2 text-stone-600"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-5 py-2 bg-[#0B1B3D] text-[#DFC076] font-bold uppercase tracking-wider rounded"
                          >
                            Save Beneficiary
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 7. STATEMENTS GENERATOR (MANDATORY DISCLAIMER BANNER) */}
            {activeTab === 'statements' && (
              <div className="bg-white p-6 sm:p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Archival Reporting
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    Demonstration Statement Generator
                  </h2>
                  <p className="text-xs text-stone-500">
                    Generate and download filtered demonstration statements from historical demonstration records.
                  </p>
                </div>

                {/* Date Filter & Generator */}
                <div className="p-5 bg-stone-50 rounded-lg border border-stone-200 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 flex-1">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Statement Period Start</label>
                      <input
                        type="date"
                        value={stmtStartDate}
                        onChange={(e) => setStmtStartDate(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded focus:outline-none text-stone-700 font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-stone-700 uppercase">Statement Period End</label>
                      <input
                        type="date"
                        value={stmtEndDate}
                        onChange={(e) => setStmtEndDate(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded focus:outline-none text-stone-700 font-mono"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleGenerateStatement}
                    className="px-5 py-2.5 bg-[#0B1B3D] hover:bg-[#102A5C] text-[#DFC076] text-xs font-bold uppercase tracking-wider rounded transition-colors flex items-center justify-center gap-2 cursor-pointer self-stretch sm:self-auto"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Generate Statement</span>
                  </button>
                </div>

                {/* Rendered Statement Preview */}
                {generatedStatement && (
                  <div className="p-8 border-2 border-dashed border-[#C5A059]/40 rounded-xl space-y-6 bg-[#FAF8F5]">
                    {/* MANDATORY PROMINENT DISCLAIMER */}
                    <div className="p-3.5 bg-rose-900 text-white font-serif font-bold text-center tracking-widest text-sm rounded shadow-sm">
                      DEMONSTRATION STATEMENT — NOT A VALID BANK STATEMENT.
                    </div>

                    {/* Statement Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-stone-300 gap-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={BRAND_ASSETS.logo}
                          alt="LHT"
                          className="h-12 w-auto object-contain bg-white p-1 rounded border border-stone-300"
                        />
                        <div>
                          <h3 className="font-serif text-lg font-bold text-[#0B1B3D]">
                            Litchfield Heritage Trust
                          </h3>
                          <p className="text-[11px] text-stone-500 font-serif italic">
                            Your Trust. Our Heritage.
                          </p>
                        </div>
                      </div>

                      <div className="text-right text-xs text-stone-600 space-y-0.5">
                        <div>Period: <strong className="font-mono">{stmtStartDate}</strong> to <strong className="font-mono">{stmtEndDate}</strong></div>
                        <div>Generated: <span className="font-mono">{new Date().toLocaleDateString()}</span></div>
                        <div className="text-[11px] text-[#B88D36] font-semibold">Simulated Technical Record</div>
                      </div>
                    </div>

                    {/* Account Particulars */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-stone-700">
                      <div>
                        <div className="text-stone-400 uppercase text-[10px]">Account Holder</div>
                        <div className="font-semibold text-stone-900">{profile?.accountHolderName}</div>
                      </div>
                      <div>
                        <div className="text-stone-400 uppercase text-[10px]">Account Number</div>
                        <div className="font-mono font-medium text-stone-900">{profile?.accountNumber}</div>
                      </div>
                      <div>
                        <div className="text-stone-400 uppercase text-[10px]">Current Balance</div>
                        <div className="font-mono font-bold text-[#0B1B3D]">${balances?.currentBalance.toLocaleString()} USD</div>
                      </div>
                      <div>
                        <div className="text-stone-400 uppercase text-[10px]">Discretionary Liquidity</div>
                        <div className="font-mono font-bold text-[#B88D36]">${balances?.availableDiscretionaryLiquidity.toLocaleString()} USD</div>
                      </div>
                    </div>

                    {/* Statement Items Table */}
                    <div className="overflow-x-auto border border-stone-300 rounded">
                      <table className="w-full text-xs text-left bg-white">
                        <thead className="bg-stone-100 text-stone-600 uppercase tracking-wider text-[10px] border-b border-stone-200">
                          <tr>
                            <th className="py-2.5 px-3">Date</th>
                            <th className="py-2.5 px-3">Reference</th>
                            <th className="py-2.5 px-3">Description</th>
                            <th className="py-2.5 px-3 text-right">Amount (USD)</th>
                            <th className="py-2.5 px-3">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-100">
                          {generatedStatement.length === 0 ? (
                            <tr>
                              <td colSpan={5} className="py-6 text-center text-stone-400">
                                No demonstration transactions recorded in the selected date window.
                              </td>
                            </tr>
                          ) : (
                            generatedStatement.map((t) => (
                              <tr key={t.id}>
                                <td className="py-2 px-3 whitespace-nowrap font-mono text-[11px] text-stone-600">{t.date}</td>
                                <td className="py-2 px-3 font-mono text-stone-500 text-[11px]">{t.reference}</td>
                                <td className="py-2 px-3 font-medium text-stone-900">{t.description}</td>
                                <td
                                  className={`py-2 px-3 text-right font-mono font-semibold tabular-nums ${
                                    t.type === 'withdrawal' || t.type === 'payment'
                                      ? 'text-rose-700'
                                      : 'text-emerald-700'
                                  }`}
                                >
                                  {t.type === 'withdrawal' || t.type === 'payment' ? '-' : '+'}
                                  ${t.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </td>
                                <td className="py-2 px-3 text-stone-600 text-[11px]">{t.status}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <span className="text-[11px] text-stone-500 italic">
                        Notice: This document cannot be utilized as proof of funds or ownership.
                      </span>
                      <button
                        onClick={() => window.print()}
                        className="px-4 py-2 bg-[#0B1B3D] text-[#DFC076] text-xs font-semibold rounded uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print / Save Statement PDF</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 8. ACCOUNT DETAILS (NON-EDITABLE BY VISITOR) */}
            {activeTab === 'details' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Mandate Particulars
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    Account Details & Fiduciary Profile
                  </h2>
                  <p className="text-xs text-stone-500">
                    Protected account parameters. In accordance with fiduciary security, account details can only be altered by the Administrator.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs text-stone-700 divide-y sm:divide-y-0 sm:divide-x divide-stone-100">
                  <div className="space-y-4">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Account Holder Name</div>
                      <div className="text-base font-serif font-semibold text-[#0B1B3D] mt-0.5">{profile?.accountHolderName}</div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Demonstration Account Number</div>
                      <div className="font-mono text-sm font-semibold text-stone-900 mt-0.5">{profile?.accountNumber}</div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Account Classification</div>
                      <div className="text-stone-900 font-medium mt-0.5">{profile?.accountType}</div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Base Currency</div>
                      <div className="font-mono text-stone-900 font-medium mt-0.5">{profile?.currency}</div>
                    </div>
                  </div>

                  <div className="space-y-4 sm:pl-5 pt-4 sm:pt-0">
                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Fiduciary Account Status</div>
                      <div className="text-emerald-700 font-semibold mt-0.5">{profile?.status}</div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Routing Identifier</div>
                      <div className="font-mono text-stone-900 font-medium mt-0.5">{profile?.routingNumber}</div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">SWIFT / BIC Code</div>
                      <div className="font-mono text-stone-900 font-medium mt-0.5">{profile?.swiftBic}</div>
                    </div>

                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Account Description</div>
                      <div className="text-stone-600 mt-0.5 leading-relaxed">{profile?.accountDescription}</div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-stone-50 rounded border border-stone-200 text-xs text-stone-600 flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-[#B88D36] shrink-0 mt-0.5" />
                  <div>
                    <strong>Fiduciary Governance Standard:</strong> Account holder display names, currency codes, and routing designations are locked under dual-signature administrative protection.
                  </div>
                </div>
              </div>
            )}

            {/* 9. NOTIFICATIONS TAB */}
            {activeTab === 'notifications' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Institutional Communications
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    Announcements & Advisory Alerts
                  </h2>
                  <p className="text-xs text-stone-500">
                    Direct announcements broadcasted by the Litchfield Heritage Trust Administrator Directorate.
                  </p>
                </div>

                <div className="space-y-3">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`p-4 rounded-lg border transition-all ${
                        n.isRead
                          ? 'bg-stone-50/70 border-stone-200'
                          : 'bg-white border-[#C5A059] shadow-sm'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-[#0B1B3D]">{n.title}</span>
                            {!n.isRead && (
                              <span className="text-[10px] px-2 py-0.5 bg-[#C5A059]/20 text-[#B88D36] font-semibold uppercase rounded">
                                New Announcement
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-stone-600 leading-relaxed">{n.message}</p>
                          <div className="text-[10px] text-stone-400 flex items-center gap-3 pt-1">
                            <span>From: {n.sender}</span>
                            <span>·</span>
                            <span>{new Date(n.date).toLocaleString()}</span>
                          </div>
                        </div>

                        {!n.isRead && (
                          <button
                            onClick={() => handleMarkNotifRead(n.id)}
                            className="text-xs text-[#B88D36] hover:underline whitespace-nowrap cursor-pointer"
                          >
                            Mark Read
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 10. VISITOR SETTINGS */}
            {activeTab === 'settings' && (
              <div className="max-w-3xl mx-auto bg-white p-8 rounded-lg border border-stone-200 shadow-sm space-y-6 animate-fadeIn">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-[#B88D36]">
                    Preferences
                  </span>
                  <h2 className="text-2xl font-serif font-semibold text-[#0B1B3D] mt-0.5">
                    Visitor Display & Privacy Settings
                  </h2>
                  <p className="text-xs text-stone-500">
                    Configure your personal demonstration session display preferences.
                  </p>
                </div>

                <div className="space-y-4 text-xs divide-y divide-stone-100">
                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Mask Financial Balances</div>
                      <div className="text-stone-500">Conceal numerical balances on the dashboard</div>
                    </div>
                    <button
                      onClick={() => setBalancesVisible(!balancesVisible)}
                      className={`px-3 py-1.5 rounded text-xs font-semibold cursor-pointer ${
                        !balancesVisible
                          ? 'bg-[#0B1B3D] text-[#DFC076]'
                          : 'bg-stone-100 text-stone-700'
                      }`}
                    >
                      {!balancesVisible ? 'Masked' : 'Visible'}
                    </button>
                  </div>

                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Session Security Token</div>
                      <div className="text-stone-500">Bearer session established with backend</div>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-800 font-mono text-[11px] rounded">
                      Encrypted Handshake Active
                    </span>
                  </div>

                  <div className="pt-3 flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-stone-900">Administrative Boundary</div>
                      <div className="text-stone-500">Administrative tools and balance calibrations are restricted to Admin role</div>
                    </div>
                    <span className="px-2 py-0.5 bg-stone-100 text-stone-700 font-mono text-[11px] rounded">
                      Protected (Visitor Access)
                    </span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Transaction Details Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-3 border-stone-100">
              <h3 className="font-serif text-lg font-semibold text-[#0B1B3D]">
                Transaction Record Details
              </h3>
              <button onClick={() => setSelectedTx(null)} className="text-stone-400 hover:text-stone-700">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-stone-700">
              <div>
                <div className="text-[10px] text-stone-400 uppercase">Description</div>
                <div className="font-semibold text-stone-900 text-sm mt-0.5">{selectedTx.description}</div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <div className="text-[10px] text-stone-400 uppercase font-sans">Reference</div>
                  <div className="text-stone-800">{selectedTx.reference}</div>
                </div>
                <div>
                  <div className="text-[10px] text-stone-400 uppercase font-sans">Date</div>
                  <div className="text-stone-800">{selectedTx.date}</div>
                </div>
                <div>
                  <div className="text-[10px] text-stone-400 uppercase font-sans">Amount</div>
                  <div className="font-bold text-[#0B1B3D] text-sm">
                    ${selectedTx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })} {selectedTx.currency}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-stone-400 uppercase font-sans">Status</div>
                  <div className="text-emerald-700 font-sans font-medium">{selectedTx.status}</div>
                </div>
              </div>

              {selectedTx.counterparty && (
                <div>
                  <div className="text-[10px] text-stone-400 uppercase">Counterparty</div>
                  <div className="text-stone-800 font-medium">{selectedTx.counterparty}</div>
                </div>
              )}

              {selectedTx.notes && (
                <div>
                  <div className="text-[10px] text-stone-400 uppercase">Audit Note</div>
                  <div className="text-stone-600 italic">{selectedTx.notes}</div>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-stone-100 flex justify-end">
              <button
                onClick={() => setSelectedTx(null)}
                className="px-4 py-2 bg-[#0B1B3D] text-[#DFC076] text-xs font-semibold rounded uppercase tracking-wider"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
